# Coding standards

## TypeScript

- Strict mode; `any` is forbidden (`unknown` + narrowing instead).
- Public contracts are `interface`s with `readonly` fields.
- Expected failures return `Result<T>`; exceptions are for bugs only.
- No unchecked casts (`as`) on inferred router/query values.

## React

- Function components, hooks only; one component per file.
- Props typed via an exported `interface XProps`.
- Context is consumed through a dedicated hook that throws when the provider is missing.
- Keep components small and presentational; IO belongs in services.

## Styling

- Semantic tokens only — never `text-white`, `bg-black` or `bg-[#hex]` in components.
- New visual treatments become tokens or component variants in `src/styles.css` / `button.tsx`.
- All colors are `oklch`.

## Naming

- Files: `kebab-case.tsx`; components: `PascalCase`; hooks: `useThing`; services: `thingService`.
- Feature folders are nouns (`knowledge-base`, `website-sync`).

## Accessibility

- Landmarks, one `h1` per page, labelled controls, visible focus rings, skip link, keyboard operability, AA contrast.

## Performance

- Route-level code splitting (never export route components).
- Lazy-load below-the-fold images; memoize expensive derivations.

## Principles

SOLID · DRY · KISS. Every non-obvious file starts with a short comment explaining its purpose.
