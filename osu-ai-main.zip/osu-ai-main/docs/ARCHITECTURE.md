# Architecture

## Layers

```
routes/          URL + head metadata + composition only
layouts/         page chrome (public shell, admin console)
features/*/      self-contained domain slices
  components/    feature UI
  hooks/         feature state
  services/      IO boundary (returns Result<T>)
  types/         feature contracts
providers/       global context (theme, i18n, auth)
lib/             pure cross-cutting utilities
config/          all configuration, single source of truth
types/           shared domain + primitive types
```

Dependency rule: `routes → layouts/features → providers/lib/config/types`. Features never import each other's internals; share through `types/`, `lib/` or a service.

## RAG pipeline (target)

```
Source (web | pdf | docx | xlsx | media)
  → DocumentService.upload  → storage + document row
  → KnowledgeService.chunkDocument → chunks (1000 tokens / 150 overlap)
  → AIService.embedText → pgvector embeddings
Question
  → sanitize + rate limit
  → LanguageService.detect
  → KnowledgeService.retrieve (top-K, min score)
  → refuse if no chunk clears the threshold
  → AIService.ask → grounded answer + citations
  → persist message + citations + analytics event
```

## Data model (future migrations)

`users/profiles`, `user_roles` (separate table, security-definer `has_role`), `conversations`, `messages`, `knowledge_documents`, `knowledge_chunks`, `embeddings`, `website_pages`, `analytics_events`, `settings`, `ai_providers`, `logs`, `feedback`, `languages`. Contracts live in `src/types/domain.types.ts`.

Every table ships with explicit GRANTs, RLS enabled and least-privilege policies.

## Security

- Auth + role checks server-side only; roles never in profile rows or client storage.
- Input validated with Zod and sanitized (`src/lib/validation.ts`).
- Client-side rate limiter for UX, edge-enforced limits for real protection.
- Secrets only in backend secret storage; never in the repo or client bundle.
- XSS: no `dangerouslySetInnerHTML`; URLs whitelisted to http/https.
- SQL injection: parameterized queries / PostgREST only.

## State management

Context API today (theme, i18n, auth) + TanStack Query for server state. Contexts are consumed only through hooks, so swapping in Zustand or Redux later touches the provider, not the screens.

## Error handling & logging

Root `errorComponent` + `notFoundComponent` in `src/routes/__root.tsx`; `logger` (`src/lib/logger.ts`) supports debug/info/warn/error with pluggable transports (console now, database later).

## PWA

`public/manifest.webmanifest`, icons in `public/icons/`, and an `/offline` fallback route. A guarded, generated service worker is added in the offline phase — service workers must never register in preview/dev contexts.

## Extension points

- New AI vendor: implement `AIProvider`, register in `provider-registry.ts`.
- New language: add a dictionary in `src/features/i18n/locales/` + `appConfig.supportedLanguages`.
- New page: add a route file + a `navigation.config.ts` entry.
- New source type: extend `DocumentKind` and the ingestion service.
