# Development roadmap

## Phase 1 — Foundation (complete)

Design system, feature-based structure, routing, layouts, providers (theme / i18n / auth), typed service and AI-provider contracts, domain models, logging, validation, rate limiting, PWA manifest, SEO, documentation.

## Phase 2 — Backend enablement

Enable Lovable Cloud; migrations for all tables with GRANTs + RLS; `user_roles` + `has_role`; storage buckets; auth (email/password + Google); real `AuthService`.

## Phase 3 — Knowledge ingestion

Document upload and parsing (PDF/DOCX/XLSX), chunking, embeddings into pgvector, admin document library, re-index jobs.

## Phase 4 — Retrieval & chat

Retrieval with scoring thresholds, grounded answering with citations, refusal behaviour, streaming responses, conversation persistence, feedback capture.

## Phase 5 — Website synchronization

Scheduled crawler for osu.edu.et, content hashing, incremental re-index, page inventory UI.

## Phase 6 — Multilingual & voice

Language detection, translation across English / Afaan Oromoo / Amharic, speech-to-text and text-to-speech.

## Phase 7 — Analytics & governance

Usage dashboards, knowledge-gap tracking, quality evaluation suite, audit logs, retention policies.

## Phase 8 — Offline PWA & hardening

Guarded generated service worker, offline caching, install prompt, load testing, security review, accessibility audit.
