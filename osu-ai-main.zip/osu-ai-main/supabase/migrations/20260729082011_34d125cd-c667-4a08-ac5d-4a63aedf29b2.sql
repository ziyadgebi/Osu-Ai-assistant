
-- WEBSITES
CREATE TABLE public.websites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  base_url text NOT NULL UNIQUE,
  logo_url text,
  description text,
  status text NOT NULL DEFAULT 'active',
  language text NOT NULL DEFAULT 'en',
  owner_id uuid,
  frequency text NOT NULL DEFAULT 'daily',
  cron_expression text,
  last_crawl_at timestamptz,
  next_crawl_at timestamptz,
  total_pages integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.websites TO authenticated;
GRANT ALL ON public.websites TO service_role;
ALTER TABLE public.websites ENABLE ROW LEVEL SECURITY;
CREATE POLICY web_select ON public.websites FOR SELECT TO authenticated USING (true);
CREATE POLICY web_write ON public.websites FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER websites_touch BEFORE UPDATE ON public.websites FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- CRAWL SETTINGS
CREATE TABLE public.crawl_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL UNIQUE REFERENCES public.websites(id) ON DELETE CASCADE,
  max_depth integer NOT NULL DEFAULT 3,
  max_pages integer NOT NULL DEFAULT 200,
  max_concurrency integer NOT NULL DEFAULT 4,
  retry_count integer NOT NULL DEFAULT 2,
  timeout_ms integer NOT NULL DEFAULT 15000,
  delay_ms integer NOT NULL DEFAULT 300,
  respect_robots boolean NOT NULL DEFAULT true,
  respect_sitemap boolean NOT NULL DEFAULT true,
  follow_redirects boolean NOT NULL DEFAULT true,
  allow_pdf boolean NOT NULL DEFAULT true,
  allow_images boolean NOT NULL DEFAULT false,
  allow_videos boolean NOT NULL DEFAULT false,
  allow_external boolean NOT NULL DEFAULT false,
  allowed_domains text[] NOT NULL DEFAULT '{}',
  ignored_urls text[] NOT NULL DEFAULT '{}',
  ignored_extensions text[] NOT NULL DEFAULT '{".css",".js",".png",".jpg",".jpeg",".gif",".svg",".ico",".woff",".woff2"}',
  ignored_patterns text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crawl_settings TO authenticated;
GRANT ALL ON public.crawl_settings TO service_role;
ALTER TABLE public.crawl_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY cs_select ON public.crawl_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY cs_write ON public.crawl_settings FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER crawl_settings_touch BEFORE UPDATE ON public.crawl_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- WEBSITE PAGES
CREATE TABLE public.website_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES public.websites(id) ON DELETE CASCADE,
  url text NOT NULL,
  canonical_url text,
  title text,
  description text,
  language text,
  page_type text NOT NULL DEFAULT 'general',
  category text,
  department text,
  status text NOT NULL DEFAULT 'discovered',
  http_status integer,
  content_hash text,
  raw_html text,
  extracted_content text,
  clean_content text,
  word_count integer NOT NULL DEFAULT 0,
  headings jsonb NOT NULL DEFAULT '[]'::jsonb,
  links jsonb NOT NULL DEFAULT '[]'::jsonb,
  files jsonb NOT NULL DEFAULT '[]'::jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  depth integer NOT NULL DEFAULT 0,
  version integer NOT NULL DEFAULT 1,
  is_duplicate boolean NOT NULL DEFAULT false,
  duplicate_of uuid,
  error text,
  document_id uuid,
  last_crawled_at timestamptz,
  last_modified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  UNIQUE (website_id, url)
);
CREATE INDEX website_pages_website_idx ON public.website_pages(website_id);
CREATE INDEX website_pages_status_idx ON public.website_pages(status);
CREATE INDEX website_pages_hash_idx ON public.website_pages(content_hash);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.website_pages TO authenticated;
GRANT ALL ON public.website_pages TO service_role;
ALTER TABLE public.website_pages ENABLE ROW LEVEL SECURITY;
CREATE POLICY wp_select ON public.website_pages FOR SELECT TO authenticated USING (true);
CREATE POLICY wp_write ON public.website_pages FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER website_pages_touch BEFORE UPDATE ON public.website_pages FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- WEBSITE VERSIONS
CREATE TABLE public.website_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NOT NULL REFERENCES public.website_pages(id) ON DELETE CASCADE,
  version integer NOT NULL,
  title text,
  clean_content text,
  content_hash text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  diff_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (page_id, version)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.website_versions TO authenticated;
GRANT ALL ON public.website_versions TO service_role;
ALTER TABLE public.website_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY wv_select ON public.website_versions FOR SELECT TO authenticated USING (true);
CREATE POLICY wv_write ON public.website_versions FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

-- CRAWL JOBS
CREATE TABLE public.crawl_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES public.websites(id) ON DELETE CASCADE,
  mode text NOT NULL DEFAULT 'manual',
  status text NOT NULL DEFAULT 'pending',
  pages_discovered integer NOT NULL DEFAULT 0,
  pages_crawled integer NOT NULL DEFAULT 0,
  pages_updated integer NOT NULL DEFAULT 0,
  pages_failed integer NOT NULL DEFAULT 0,
  pages_skipped integer NOT NULL DEFAULT 0,
  files_found integer NOT NULL DEFAULT 0,
  error text,
  started_at timestamptz,
  finished_at timestamptz,
  duration_ms integer,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX crawl_jobs_website_idx ON public.crawl_jobs(website_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crawl_jobs TO authenticated;
GRANT ALL ON public.crawl_jobs TO service_role;
ALTER TABLE public.crawl_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY cj_select ON public.crawl_jobs FOR SELECT TO authenticated USING (true);
CREATE POLICY cj_write ON public.crawl_jobs FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER crawl_jobs_touch BEFORE UPDATE ON public.crawl_jobs FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- CRAWL QUEUE
CREATE TABLE public.crawl_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES public.websites(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.crawl_jobs(id) ON DELETE CASCADE,
  url text NOT NULL,
  depth integer NOT NULL DEFAULT 0,
  priority integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  attempts integer NOT NULL DEFAULT 0,
  error text,
  source text NOT NULL DEFAULT 'link',
  processed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX crawl_queue_job_idx ON public.crawl_queue(job_id);
CREATE INDEX crawl_queue_status_idx ON public.crawl_queue(status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crawl_queue TO authenticated;
GRANT ALL ON public.crawl_queue TO service_role;
ALTER TABLE public.crawl_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY cq_select ON public.crawl_queue FOR SELECT TO authenticated USING (true);
CREATE POLICY cq_write ON public.crawl_queue FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER crawl_queue_touch BEFORE UPDATE ON public.crawl_queue FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- CRAWL LOGS
CREATE TABLE public.crawl_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid REFERENCES public.websites(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.crawl_jobs(id) ON DELETE CASCADE,
  page_id uuid,
  step text NOT NULL,
  level text NOT NULL DEFAULT 'info',
  message text NOT NULL,
  url text,
  duration_ms integer,
  context jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX crawl_logs_job_idx ON public.crawl_logs(job_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.crawl_logs TO authenticated;
GRANT ALL ON public.crawl_logs TO service_role;
ALTER TABLE public.crawl_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY cl_select ON public.crawl_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY cl_write ON public.crawl_logs FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

-- WEBSITE METADATA
CREATE TABLE public.website_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES public.websites(id) ON DELETE CASCADE,
  key text NOT NULL,
  value text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (website_id, key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.website_metadata TO authenticated;
GRANT ALL ON public.website_metadata TO service_role;
ALTER TABLE public.website_metadata ENABLE ROW LEVEL SECURITY;
CREATE POLICY wm_select ON public.website_metadata FOR SELECT TO authenticated USING (true);
CREATE POLICY wm_write ON public.website_metadata FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE TRIGGER website_metadata_touch BEFORE UPDATE ON public.website_metadata FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
