
REVOKE EXECUTE ON FUNCTION public.search_knowledge_chunks_text(text, integer, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.match_knowledge_chunks(vector, integer, double precision, uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.search_knowledge_chunks_text(text, integer, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.match_knowledge_chunks(vector, integer, double precision, uuid, text) TO authenticated, service_role;
