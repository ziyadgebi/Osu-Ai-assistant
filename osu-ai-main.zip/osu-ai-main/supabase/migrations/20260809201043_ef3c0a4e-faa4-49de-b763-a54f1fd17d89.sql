CREATE TABLE IF NOT EXISTS public.unanswered_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  language text NOT NULL DEFAULT 'en',
  user_id uuid,
  conversation_id uuid,
  confidence numeric,
  status text NOT NULL DEFAULT 'open',
  answer text,
  answered_by uuid,
  answered_at timestamptz,
  ask_count integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.unanswered_questions TO authenticated;
GRANT ALL ON public.unanswered_questions TO service_role;

ALTER TABLE public.unanswered_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins manage unanswered questions" ON public.unanswered_questions;
CREATE POLICY "Admins manage unanswered questions"
ON public.unanswered_questions FOR ALL TO authenticated
USING (public.is_admin(auth.uid()))
WITH CHECK (public.is_admin(auth.uid()));

CREATE INDEX IF NOT EXISTS unanswered_questions_status_idx ON public.unanswered_questions (status, created_at DESC);