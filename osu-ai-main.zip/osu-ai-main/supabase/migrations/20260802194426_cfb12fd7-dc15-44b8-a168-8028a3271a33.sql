insert into public.user_roles (user_id, role)
values ('56367e19-e502-44cc-988b-fc759470c0ed','admin'::app_role), ('56367e19-e502-44cc-988b-fc759470c0ed','super_admin'::app_role)
on conflict (user_id, role) do nothing;

insert into public.profiles (id, email, full_name)
values ('56367e19-e502-44cc-988b-fc759470c0ed','admin@osu.edu.et','OSU Demo Admin')
on conflict (id) do nothing;

insert into public.websites (id, name, base_url, status, language, frequency)
values ('11111111-1111-4111-8111-111111111111','Oromia State University','https://osu.edu.et','active','en','daily')
on conflict (id) do nothing;

insert into public.crawl_settings (website_id, max_depth, max_pages, allowed_domains)
values ('11111111-1111-4111-8111-111111111111', 3, 300, array['osu.edu.et'])
on conflict do nothing;