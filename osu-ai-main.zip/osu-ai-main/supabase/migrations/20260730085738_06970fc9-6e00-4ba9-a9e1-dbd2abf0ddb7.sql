
-- CONVERSATIONS
CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'New conversation',
  language text NOT NULL DEFAULT 'en',
  provider_id text NOT NULL DEFAULT 'gemini',
  model text,
  memory_summary text,
  message_count integer NOT NULL DEFAULT 0,
  is_pinned boolean NOT NULL DEFAULT false,
  is_archived boolean NOT NULL DEFAULT false,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_conversations_user ON public.conversations(user_id, updated_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own conversations" ON public.conversations FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admins read conversations" ON public.conversations FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- MESSAGES
CREATE TABLE public.conversation_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user','assistant','system')),
  content text NOT NULL DEFAULT '',
  citations jsonb NOT NULL DEFAULT '[]'::jsonb,
  retrieval jsonb NOT NULL DEFAULT '{}'::jsonb,
  confidence numeric,
  language text,
  provider_id text,
  model text,
  prompt_tokens integer,
  completion_tokens integer,
  latency_ms integer,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_conversation ON public.conversation_messages(conversation_id, created_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_messages TO authenticated;
GRANT ALL ON public.conversation_messages TO service_role;
ALTER TABLE public.conversation_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own messages" ON public.conversation_messages FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.user_id = auth.uid()));
CREATE POLICY "admins read messages" ON public.conversation_messages FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- AI USAGE
CREATE TABLE public.ai_usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  conversation_id uuid REFERENCES public.conversations(id) ON DELETE SET NULL,
  kind text NOT NULL DEFAULT 'chat',
  provider_id text NOT NULL,
  model text NOT NULL,
  prompt_tokens integer NOT NULL DEFAULT 0,
  completion_tokens integer NOT NULL DEFAULT 0,
  duration_ms integer NOT NULL DEFAULT 0,
  success boolean NOT NULL DEFAULT true,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_usage_created ON public.ai_usage_events(created_at DESC);

GRANT SELECT ON public.ai_usage_events TO authenticated;
GRANT ALL ON public.ai_usage_events TO service_role;
ALTER TABLE public.ai_usage_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read usage" ON public.ai_usage_events FOR SELECT TO authenticated
  USING (public.is_admin(auth.uid()));

-- AI SETTINGS (single row)
CREATE TABLE public.ai_settings (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  active_provider text NOT NULL DEFAULT 'gemini',
  chat_model text NOT NULL DEFAULT 'google/gemini-2.5-flash',
  embedding_model text NOT NULL DEFAULT 'google/text-embedding-004',
  temperature numeric NOT NULL DEFAULT 0.2,
  max_tokens integer NOT NULL DEFAULT 1200,
  top_k integer NOT NULL DEFAULT 8,
  min_score numeric NOT NULL DEFAULT 0.35,
  enable_query_rewrite boolean NOT NULL DEFAULT true,
  enable_hybrid_search boolean NOT NULL DEFAULT true,
  refuse_without_sources boolean NOT NULL DEFAULT true,
  system_prompt text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ai_settings TO authenticated, anon;
GRANT ALL ON public.ai_settings TO service_role;
ALTER TABLE public.ai_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "everyone reads ai settings" ON public.ai_settings FOR SELECT TO authenticated, anon USING (true);
CREATE POLICY "admins write ai settings" ON public.ai_settings FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

INSERT INTO public.ai_settings (id) VALUES (true);

CREATE TRIGGER trg_conversations_updated BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- KEYWORD SEARCH over chunks (hybrid retrieval companion to match_knowledge_chunks)
CREATE INDEX IF NOT EXISTS idx_chunks_content_fts ON public.knowledge_chunks
  USING gin (to_tsvector('simple', content));

CREATE OR REPLACE FUNCTION public.search_knowledge_chunks_text(
  query_text text,
  match_count integer DEFAULT 8,
  filter_language text DEFAULT NULL
)
RETURNS TABLE(
  id uuid, document_id uuid, chunk_index integer, content text,
  page_number integer, section text, language text,
  document_title text, score double precision
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT c.id, c.document_id, c.chunk_index, c.content, c.page_number, c.section, c.language,
         d.title AS document_title,
         ts_rank(to_tsvector('simple', c.content), plainto_tsquery('simple', query_text))::double precision AS score
  FROM public.knowledge_chunks c
  JOIN public.knowledge_documents d ON d.id = c.document_id
  WHERE d.deleted_at IS NULL
    AND (filter_language IS NULL OR c.language = filter_language)
    AND to_tsvector('simple', c.content) @@ plainto_tsquery('simple', query_text)
  ORDER BY score DESC
  LIMIT match_count;
$$;
