/**
 * OSU AI Assistant embeddable widget.
 *
 * Usage on any website:
 *   <script src="https://osu-ai.lovable.app/widget.js" defer></script>
 * Optional attributes: data-title, data-color, data-position="left|right".
 */
(function () {
  if (window.__osuAssistantWidgetLoaded) return;
  window.__osuAssistantWidgetLoaded = true;

  var script = document.currentScript;
  var origin = new URL(script.src).origin;
  var color = script.getAttribute("data-color") || "#123a7a";
  var position = script.getAttribute("data-position") === "left" ? "left" : "right";
  var label = script.getAttribute("data-title") || "Ask OSU AI";

  var style = document.createElement("style");
  style.textContent =
    ".osu-aw-btn{position:fixed;bottom:20px;" + position + ":20px;z-index:2147483000;display:flex;align-items:center;gap:8px;" +
    "border:none;border-radius:999px;padding:12px 18px;cursor:pointer;color:#fff;font:600 14px/1 system-ui,sans-serif;" +
    "background:" + color + ";box-shadow:0 10px 30px rgba(0,0,0,.25);transition:transform .15s ease}" +
    ".osu-aw-btn:hover{transform:translateY(-2px)}" +
    ".osu-aw-panel{position:fixed;bottom:84px;" + position + ":20px;z-index:2147483000;width:390px;max-width:calc(100vw - 32px);" +
    "height:600px;max-height:calc(100vh - 120px);border:none;border-radius:16px;overflow:hidden;background:#fff;" +
    "box-shadow:0 24px 60px rgba(0,0,0,.3);display:none}" +
    ".osu-aw-panel.open{display:block}" +
    "@media(max-width:480px){.osu-aw-panel{width:calc(100vw - 24px);height:70vh;bottom:76px;" + position + ":12px}}";
  document.head.appendChild(style);

  var button = document.createElement("button");
  button.className = "osu-aw-btn";
  button.type = "button";
  button.setAttribute("aria-label", label);
  button.innerHTML =
    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>' +
    "<span>" + label + "</span>";

  var frame = document.createElement("iframe");
  frame.className = "osu-aw-panel";
  frame.title = label;
  frame.setAttribute("allow", "microphone");

  button.addEventListener("click", function () {
    var open = frame.classList.toggle("open");
    if (open && !frame.src) frame.src = origin + "/embed";
    button.setAttribute("aria-expanded", String(open));
  });

  document.body.appendChild(button);
  document.body.appendChild(frame);
})();
