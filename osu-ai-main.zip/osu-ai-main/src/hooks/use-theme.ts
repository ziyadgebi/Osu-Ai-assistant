import { useContext } from "react";
import { ThemeContext, type ThemeContextValue } from "@/providers/theme-provider";

/** Access the current theme. Throws when used outside <ThemeProvider>. */
export function useTheme(): ThemeContextValue {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within a ThemeProvider");
  return context;
}
