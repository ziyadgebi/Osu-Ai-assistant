import { useContext } from "react";
import { I18nContext } from "@/providers/i18n-provider";
import type { I18nContextValue } from "@/types/i18n.types";

/** Access translations and the active language. */
export function useTranslation(): I18nContextValue {
  const context = useContext(I18nContext);
  if (!context) throw new Error("useTranslation must be used within an I18nProvider");
  return context;
}
