/**
 * Centralized application configuration.
 * Never scatter configuration across features — extend this file instead.
 */

import type { LanguageCode } from "@/types/i18n.types";

export interface AppConfig {
  readonly name: string;
  readonly shortName: string;
  readonly organization: string;
  readonly organizationUrl: string;
  readonly description: string;
  readonly supportEmail: string;
  readonly defaultLanguage: LanguageCode;
  readonly supportedLanguages: readonly LanguageCode[];
  readonly features: Readonly<Record<FeatureFlag, boolean>>;
  readonly rag: {
    readonly chunkSize: number;
    readonly chunkOverlap: number;
    readonly topK: number;
    readonly minimumScore: number;
    readonly embeddingDimensions: number;
  };
  readonly limits: {
    readonly maxUploadMb: number;
    readonly maxMessagesPerMinute: number;
    readonly maxMessageLength: number;
  };
}

export type FeatureFlag =
  | "chat"
  | "voice"
  | "multilingual"
  | "websiteSync"
  | "analytics"
  | "offlineMode"
  | "feedback";

export const appConfig: AppConfig = {
  name: "OSU AI Assistant",
  shortName: "OSU AI",
  organization: "Oromia State University",
  organizationUrl: "https://osu.edu.et",
  description:
    "The official AI assistant of Oromia State University — grounded answers with citations from official university sources.",
  supportEmail: "info@osu.edu.et",
  defaultLanguage: "en",
  supportedLanguages: ["en", "om", "am"],
  features: {
    chat: false, // Chat engine is intentionally not implemented yet (architecture phase).
    voice: false,
    multilingual: true,
    websiteSync: false,
    analytics: false,
    offlineMode: true,
    feedback: false,
  },
  rag: {
    chunkSize: 1000,
    chunkOverlap: 150,
    topK: 6,
    minimumScore: 0.72,
    embeddingDimensions: 768,
  },
  limits: {
    maxUploadMb: 50,
    maxMessagesPerMinute: 20,
    maxMessageLength: 4000,
  },
};

export const isFeatureEnabled = (flag: FeatureFlag): boolean => appConfig.features[flag];
