/**
 * Environment access layer.
 *
 * Rules:
 *  - Browser-visible values MUST be prefixed with VITE_ and read from import.meta.env.
 *  - Server-only secrets (provider API keys) are NEVER read here; they are read inside
 *    server function handlers via process.env at call time.
 *  - Nothing in this file may contain a literal secret.
 */

export interface PublicEnv {
  readonly supabaseUrl: string;
  readonly supabaseAnonKey: string;
  readonly appUrl: string;
  readonly isProduction: boolean;
}

const read = (key: string): string => {
  const value = (import.meta.env as Record<string, string | undefined>)[key];
  return typeof value === "string" ? value : "";
};

export const publicEnv: PublicEnv = {
  supabaseUrl: read("VITE_SUPABASE_URL"),
  supabaseAnonKey: read("VITE_SUPABASE_PUBLISHABLE_KEY") || read("VITE_SUPABASE_ANON_KEY"),
  appUrl: read("VITE_APP_URL") || "https://osu-ai-assistant.lovable.app",
  isProduction: import.meta.env.PROD,
};

/**
 * Server-only secret names. Values are resolved inside server handlers:
 *   const key = process.env.OPENROUTER_API_KEY
 * Listing the names here keeps configuration centralized and documented.
 */
export const serverSecretNames = [
  "SUPABASE_URL",
  "SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "OPENROUTER_API_KEY",
  "GOOGLE_API_KEY",
  "ADDIS_AI_KEY",
  "OLLAMA_URL",
  "VECTOR_DATABASE",
] as const;

export type ServerSecretName = (typeof serverSecretNames)[number];

export const isBackendConfigured = (): boolean =>
  publicEnv.supabaseUrl.length > 0 && publicEnv.supabaseAnonKey.length > 0;
