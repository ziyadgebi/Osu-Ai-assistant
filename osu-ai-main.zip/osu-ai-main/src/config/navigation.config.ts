/**
 * Navigation configuration for the public shell and the admin console.
 * Adding a page = add a route file + one entry here.
 */

import type { LucideIcon } from "lucide-react";
import { Bot, Globe, Home, MessageSquare, Settings, Sparkles } from "lucide-react";

export interface NavItem {
  readonly label: string;
  readonly to: string;
  readonly icon: LucideIcon;
  readonly description?: string;
}

export const publicNavigation: readonly NavItem[] = [
  { label: "Home", to: "/", icon: Home },
  { label: "Chat", to: "/chat", icon: MessageSquare, description: "Ask the assistant" },
];

export const adminNavigation: readonly NavItem[] = [
  { label: "Training", to: "/admin/training", icon: Sparkles },
  { label: "Website Sync", to: "/admin/website-sync", icon: Globe },
  { label: "AI Providers", to: "/admin/ai-providers", icon: Bot },
  { label: "Settings", to: "/admin/settings", icon: Settings },
];
