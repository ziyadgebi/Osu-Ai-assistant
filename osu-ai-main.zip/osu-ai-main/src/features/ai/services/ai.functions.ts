/**
 * Server functions for AI debugging (admin only): retrieval inspection and
 * a one-shot playground call that bypasses conversation persistence.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const DebugInput = z.object({
  query: z.string().min(2).max(500),
  topK: z.number().int().min(1).max(20).optional(),
  minScore: z.number().min(0).max(1).optional(),
  hybrid: z.boolean().optional(),
});

const PlaygroundInput = z.object({
  question: z.string().min(2).max(2000),
  model: z.string().min(2).max(80).optional(),
  temperature: z.number().min(0).max(2).optional(),
  useRetrieval: z.boolean().optional(),
});

export const debugRetrieval = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => DebugInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { hybridRetrieve, scoreConfidence } = await import("@/features/ai/lib/retrieval.server");

    const result = await hybridRetrieve(supabaseAdmin, {
      query: data.query,
      topK: data.topK ?? 8,
      minScore: data.minScore ?? 0.35,
      hybrid: data.hybrid ?? true,
    });

    return {
      confidence: scoreConfidence(result.chunks),
      vectorCount: result.vectorCount,
      keywordCount: result.keywordCount,
      durationMs: result.durationMs,
      embeddingFailed: result.embeddingFailed,
      chunks: result.chunks.map((chunk) => ({
        id: chunk.id,
        documentId: chunk.documentId,
        documentTitle: chunk.documentTitle,
        chunkIndex: chunk.chunkIndex,
        pageNumber: chunk.pageNumber,
        section: chunk.section,
        language: chunk.language,
        score: chunk.score,
        vectorScore: chunk.vectorScore,
        keywordScore: chunk.keywordScore,
        sourceUrl: chunk.sourceUrl,
        content: chunk.content.slice(0, 1200),
      })),
    };
  });

export const runPlayground = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PlaygroundInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");

    const started = Date.now();
    const { generateText } = await import("ai");
    const { createLovableAiGatewayProvider, getLovableApiKey } = await import("@/lib/ai-gateway.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { hybridRetrieve, buildContextBlock, toCitations, scoreConfidence } = await import(
      "@/features/ai/lib/retrieval.server"
    );
    const { buildSystemPrompt } = await import("@/features/ai/lib/prompts.server");
    const { detectLanguage } = await import("@/features/ai/lib/language");

    const useRetrieval = data.useRetrieval ?? true;
    const retrieval = useRetrieval
      ? await hybridRetrieve(supabaseAdmin, { query: data.question, topK: 8, minScore: 0.35 })
      : null;

    const gateway = createLovableAiGatewayProvider(getLovableApiKey());
    const model = data.model ?? "google/gemini-2.5-flash";
    const language = detectLanguage(data.question);

    const { text, usage } = await generateText({
      model: gateway(model),
      instructions: `${buildSystemPrompt({
        language,
        hasSources: (retrieval?.chunks.length ?? 0) > 0,
        refuseWithoutSources: useRetrieval,
      })}${retrieval ? `\n\n${buildContextBlock(retrieval.chunks)}` : ""}`,
      messages: [{ role: "user" as const, content: data.question }],
      temperature: data.temperature ?? 0.2,
    });

    const durationMs = Date.now() - started;

    await supabaseAdmin.from("ai_usage_events").insert({
      user_id: context.userId,
      kind: "playground",
      provider_id: "gemini",
      model,
      prompt_tokens: usage?.inputTokens ?? 0,
      completion_tokens: usage?.outputTokens ?? 0,
      duration_ms: durationMs,
      success: true,
    });

    return {
      answer: text,
      language,
      model,
      durationMs,
      promptTokens: usage?.inputTokens ?? 0,
      completionTokens: usage?.outputTokens ?? 0,
      confidence: retrieval ? scoreConfidence(retrieval.chunks) : 0,
      citations: retrieval ? toCitations(retrieval.chunks) : [],
    };
  });
