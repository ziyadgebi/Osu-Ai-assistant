/**
 * AIService — client-facing facade over settings, analytics and the provider catalog.
 * Model calls themselves happen server-side (/api/chat, ai.functions.ts).
 */

import { supabase } from "@/integrations/supabase/client";
import { fail, ok, type Result } from "@/types/common.types";
import type { AIProviderId } from "@/types/domain.types";
import { getProvider, providerCatalog } from "../providers/provider-registry";

export interface AISettings {
  readonly activeProvider: string;
  readonly chatModel: string;
  readonly embeddingModel: string;
  readonly temperature: number;
  readonly maxTokens: number;
  readonly topK: number;
  readonly minScore: number;
  readonly enableQueryRewrite: boolean;
  readonly enableHybridSearch: boolean;
  readonly refuseWithoutSources: boolean;
  readonly systemPrompt: string | null;
}

export interface AIUsageSummary {
  readonly requests: number;
  readonly promptTokens: number;
  readonly completionTokens: number;
  readonly averageLatencyMs: number;
  readonly failures: number;
}

export const aiService = {
  listProviders: () => providerCatalog,
  getActiveProvider: (id: AIProviderId) => getProvider(id),

  async getSettings(): Promise<Result<AISettings>> {
    const { data, error } = await supabase.from("ai_settings").select("*").maybeSingle();
    if (error) return fail("AI_SETTINGS_LOAD_FAILED", error.message);
    if (!data) return fail("AI_SETTINGS_MISSING", "AI settings row not found.");
    return ok({
      activeProvider: data.active_provider,
      chatModel: data.chat_model,
      embeddingModel: data.embedding_model,
      temperature: Number(data.temperature),
      maxTokens: data.max_tokens,
      topK: data.top_k,
      minScore: Number(data.min_score),
      enableQueryRewrite: data.enable_query_rewrite,
      enableHybridSearch: data.enable_hybrid_search,
      refuseWithoutSources: data.refuse_without_sources,
      systemPrompt: data.system_prompt,
    });
  },

  async updateSettings(patch: Partial<AISettings>): Promise<Result<void>> {
    const { error } = await supabase
      .from("ai_settings")
      .update({
        ...(patch.activeProvider !== undefined ? { active_provider: patch.activeProvider } : {}),
        ...(patch.chatModel !== undefined ? { chat_model: patch.chatModel } : {}),
        ...(patch.temperature !== undefined ? { temperature: patch.temperature } : {}),
        ...(patch.maxTokens !== undefined ? { max_tokens: patch.maxTokens } : {}),
        ...(patch.topK !== undefined ? { top_k: patch.topK } : {}),
        ...(patch.minScore !== undefined ? { min_score: patch.minScore } : {}),
        ...(patch.enableQueryRewrite !== undefined ? { enable_query_rewrite: patch.enableQueryRewrite } : {}),
        ...(patch.enableHybridSearch !== undefined ? { enable_hybrid_search: patch.enableHybridSearch } : {}),
        ...(patch.refuseWithoutSources !== undefined ? { refuse_without_sources: patch.refuseWithoutSources } : {}),
        ...(patch.systemPrompt !== undefined ? { system_prompt: patch.systemPrompt } : {}),
        updated_at: new Date().toISOString(),
      })
      .eq("id", true);
    return error ? fail("AI_SETTINGS_UPDATE_FAILED", error.message) : ok(undefined);
  },

  /** Token + latency roll-up for the AI analytics dashboard (admin only by RLS). */
  async usageSummary(sinceDays = 30): Promise<Result<AIUsageSummary>> {
    const since = new Date(Date.now() - sinceDays * 86_400_000).toISOString();
    const { data, error } = await supabase
      .from("ai_usage_events")
      .select("prompt_tokens, completion_tokens, duration_ms, success")
      .gte("created_at", since)
      .limit(1000);
    if (error) return fail("AI_USAGE_FAILED", error.message);
    const rows = data ?? [];
    const requests = rows.length;
    return ok({
      requests,
      promptTokens: rows.reduce((sum, row) => sum + (row.prompt_tokens ?? 0), 0),
      completionTokens: rows.reduce((sum, row) => sum + (row.completion_tokens ?? 0), 0),
      averageLatencyMs: requests
        ? Math.round(rows.reduce((sum, row) => sum + (row.duration_ms ?? 0), 0) / requests)
        : 0,
      failures: rows.filter((row) => !row.success).length,
    });
  },
};
