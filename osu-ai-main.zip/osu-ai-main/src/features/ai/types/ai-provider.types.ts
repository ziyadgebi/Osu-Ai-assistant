/**
 * AIProvider — the single interface every model vendor must implement.
 * Adding a provider = implement this interface, register it in the registry.
 * No vendor SDK is imported during the architecture phase.
 */

import type { AIProviderId } from "@/types/domain.types";
import type { LanguageCode } from "@/types/i18n.types";
import type { Result } from "@/types/common.types";

export interface ChatMessageInput {
  readonly role: "user" | "assistant" | "system";
  readonly content: string;
}

export interface ChatRequest {
  readonly messages: readonly ChatMessageInput[];
  readonly model?: string;
  readonly temperature?: number;
  readonly maxTokens?: number;
}

export interface ChatResponse {
  readonly content: string;
  readonly model: string;
  readonly tokensUsed: number;
}

export interface EmbedRequest {
  readonly input: readonly string[];
  readonly model?: string;
}

export interface EmbedResponse {
  readonly vectors: readonly (readonly number[])[];
  readonly dimensions: number;
}

export interface TranslateRequest {
  readonly text: string;
  readonly from: LanguageCode | "auto";
  readonly to: LanguageCode;
}

export interface SpeechRequest {
  readonly kind: "tts" | "stt";
  readonly text?: string;
  readonly audio?: Blob;
  readonly language: LanguageCode;
}

export interface SpeechResponse {
  readonly text?: string;
  readonly audioUrl?: string;
}

export interface AIProviderCapabilities {
  readonly chat: boolean;
  readonly embed: boolean;
  readonly translate: boolean;
  readonly speech: boolean;
}

export interface AIProvider {
  readonly id: AIProviderId;
  readonly label: string;
  readonly capabilities: AIProviderCapabilities;
  chat(request: ChatRequest): Promise<Result<ChatResponse>>;
  embed(request: EmbedRequest): Promise<Result<EmbedResponse>>;
  translate(request: TranslateRequest): Promise<Result<string>>;
  speech(request: SpeechRequest): Promise<Result<SpeechResponse>>;
}
