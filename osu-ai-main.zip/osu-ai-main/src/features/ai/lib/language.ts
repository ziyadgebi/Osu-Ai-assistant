/**
 * Lightweight language detection for English, Afaan Oromoo and Amharic.
 * Deterministic and dependency-free so it can run on the server and client.
 */

import type { LanguageCode } from "@/types/i18n.types";

const ETHIOPIC = /[\u1200-\u137F]/;

const OROMO_MARKERS = [
  "akkam",
  "barattoota",
  "yunivarsiitii",
  "mootummaa",
  "oromiyaa",
  "barnoota",
  "galmee",
  "gaafadhu",
  "maali",
  "eessa",
  "hojii",
  "kaffaltii",
  "jira",
  "keessa",
  "waa'ee",
  "fi ",
  "ykn",
];

export function detectLanguage(text: string): LanguageCode {
  const value = text.trim();
  if (!value) return "en";
  if (ETHIOPIC.test(value)) return "am";

  const lower = ` ${value.toLowerCase()} `;
  const hits = OROMO_MARKERS.reduce((count, marker) => (lower.includes(marker) ? count + 1 : count), 0);
  return hits >= 2 ? "om" : "en";
}

export const languageNames: Readonly<Record<LanguageCode, string>> = {
  en: "English",
  om: "Afaan Oromoo",
  am: "Amharic (አማርኛ)",
};
