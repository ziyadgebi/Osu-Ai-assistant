/**
 * Prompt-injection detection and input sanitisation.
 * Runs before any user text reaches a model provider.
 */

const INJECTION_PATTERNS: readonly { id: string; pattern: RegExp }[] = [
  { id: "ignore-instructions", pattern: /ignore\s+(all\s+)?(previous|prior|above)\s+(instructions|prompts|rules)/i },
  { id: "reveal-prompt", pattern: /(reveal|show|print|repeat)\s+(me\s+)?(your\s+)?(system\s+)?(prompt|instructions)/i },
  { id: "role-override", pattern: /you\s+are\s+now\s+(a|an|the)\b/i },
  { id: "developer-mode", pattern: /\b(developer|dan|jailbreak|god)\s+mode\b/i },
  { id: "pretend", pattern: /\b(pretend|act as if)\b.{0,40}\b(no\s+rules|unrestricted|without\s+restrictions)\b/i },
  { id: "exfiltrate-secrets", pattern: /\b(api[_\s-]?key|service[_\s-]?role|password|secret)\b.{0,30}\b(show|give|print|leak)\b/i },
  { id: "fake-system", pattern: /<\|?(system|im_start|im_end)\|?>/i },
];

export interface InjectionScan {
  readonly flagged: boolean;
  readonly matched: readonly string[];
}

export function detectPromptInjection(text: string): InjectionScan {
  const matched = INJECTION_PATTERNS.filter(({ pattern }) => pattern.test(text)).map(({ id }) => id);
  return { flagged: matched.length > 0, matched };
}

/** Strips control characters, collapses whitespace and caps the length. */
export function sanitizeUserInput(text: string, maxLength = 4000): string {
  return text
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
    .replace(/\s{3,}/g, "  ")
    .trim()
    .slice(0, maxLength);
}

/** Retrieved context is untrusted too — neutralise instruction-like markers. */
export function neutralizeContext(text: string): string {
  return text.replace(/<\|?(system|im_start|im_end)\|?>/gi, "[markup]").slice(0, 6000);
}
