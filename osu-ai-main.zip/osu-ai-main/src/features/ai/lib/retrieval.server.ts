/**
 * Hybrid retrieval engine: pgvector similarity + keyword full-text, fused with
 * reciprocal rank fusion, then turned into a grounded context block + citations.
 */

import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/integrations/supabase/types";
import type { Citation } from "@/types/domain.types";
import { embedQuery } from "@/lib/ai-gateway.server";
import { neutralizeContext } from "./security.server";

type Client = SupabaseClient<Database>;

export interface RetrievedChunk {
  readonly id: string;
  readonly documentId: string;
  readonly documentTitle: string;
  readonly chunkIndex: number;
  readonly content: string;
  readonly pageNumber: number | null;
  readonly section: string | null;
  readonly language: string | null;
  readonly vectorScore: number | null;
  readonly keywordScore: number | null;
  readonly score: number;
  readonly sourceUrl: string | null;
}

export interface RetrievalOptions {
  readonly query: string;
  readonly topK?: number;
  readonly minScore?: number;
  readonly language?: string | null;
  readonly hybrid?: boolean;
}

export interface RetrievalResult {
  readonly chunks: readonly RetrievedChunk[];
  readonly vectorCount: number;
  readonly keywordCount: number;
  readonly durationMs: number;
  readonly embeddingFailed: boolean;
}

const RRF_K = 60;

export async function hybridRetrieve(supabase: Client, options: RetrievalOptions): Promise<RetrievalResult> {
  const started = Date.now();
  const topK = options.topK ?? 8;
  const minScore = options.minScore ?? 0.35;
  const poolSize = Math.max(topK * 3, 12);

  const embedding = await embedQuery(options.query);
  const vectorRows = embedding
    ? await runVectorSearch(supabase, embedding, poolSize, minScore, options.language ?? null)
    : [];
  const keywordRows =
    options.hybrid === false ? [] : await runKeywordSearch(supabase, options.query, poolSize, options.language ?? null);

  const merged = new Map<string, RetrievedChunk & { rrf: number }>();

  vectorRows.forEach((row, index) => {
    merged.set(row.id, {
      ...toChunk(row),
      vectorScore: row.score,
      keywordScore: null,
      rrf: 1 / (RRF_K + index + 1),
    });
  });

  keywordRows.forEach((row, index) => {
    const existing = merged.get(row.id);
    const rrf = 1 / (RRF_K + index + 1);
    if (existing) {
      merged.set(row.id, { ...existing, keywordScore: row.score, rrf: existing.rrf + rrf });
    } else {
      merged.set(row.id, { ...toChunk(row), vectorScore: null, keywordScore: row.score, rrf });
    }
  });

  const ranked = Array.from(merged.values())
    .map((chunk) => ({
      ...chunk,
      // Prefer the semantic score when present; RRF only breaks ties / lifts keyword-only hits.
      score: chunk.vectorScore ?? Math.min(0.99, 0.3 + chunk.rrf * 20),
    }))
    .sort((a, b) => b.rrf - a.rrf || b.score - a.score)
    .slice(0, topK);

  const withUrls = await attachSourceUrls(supabase, ranked);

  return {
    chunks: withUrls,
    vectorCount: vectorRows.length,
    keywordCount: keywordRows.length,
    durationMs: Date.now() - started,
    embeddingFailed: embedding === null,
  };
}

interface RawRow {
  id: string;
  document_id: string;
  document_title: string;
  chunk_index: number;
  content: string;
  page_number: number | null;
  section: string | null;
  language: string | null;
  score: number;
}

function toChunk(row: RawRow): RetrievedChunk {
  return {
    id: row.id,
    documentId: row.document_id,
    documentTitle: row.document_title,
    chunkIndex: row.chunk_index,
    content: row.content,
    pageNumber: row.page_number,
    section: row.section,
    language: row.language,
    vectorScore: null,
    keywordScore: null,
    score: row.score,
    sourceUrl: null,
  };
}

async function runVectorSearch(
  supabase: Client,
  embedding: readonly number[],
  matchCount: number,
  minScore: number,
  language: string | null,
): Promise<RawRow[]> {
  const { data, error } = await supabase.rpc("match_knowledge_chunks", {
    query_embedding: JSON.stringify(embedding),
    match_count: matchCount,
    min_score: minScore,
    ...(language ? { filter_language: language } : {}),
  });
  if (error) {
    console.error("[retrieval] vector search failed", error.message);
    return [];
  }
  return (data ?? []) as unknown as RawRow[];
}

async function runKeywordSearch(
  supabase: Client,
  query: string,
  matchCount: number,
  language: string | null,
): Promise<RawRow[]> {
  const { data, error } = await supabase.rpc("search_knowledge_chunks_text", {
    query_text: query,
    match_count: matchCount,
    ...(language ? { filter_language: language } : {}),
  } as never);
  if (error) {
    console.error("[retrieval] keyword search failed", error.message);
    return [];
  }
  return (data ?? []) as unknown as RawRow[];
}

async function attachSourceUrls(supabase: Client, chunks: RetrievedChunk[]): Promise<RetrievedChunk[]> {
  const ids = Array.from(new Set(chunks.map((chunk) => chunk.documentId)));
  if (ids.length === 0) return chunks;

  const { data } = await supabase.from("knowledge_documents").select("id, source_url").in("id", ids);
  const urls = new Map((data ?? []).map((row) => [row.id, row.source_url ?? null]));
  return chunks.map((chunk) => ({ ...chunk, sourceUrl: urls.get(chunk.documentId) ?? null }));
}

/** Numbered, injection-neutralised context block handed to the model. */
export function buildContextBlock(chunks: readonly RetrievedChunk[]): string {
  if (chunks.length === 0) return "SOURCES: (none retrieved)";
  return [
    "SOURCES (use only these; cite as [n]):",
    ...chunks.map((chunk, index) => {
      const location = [chunk.section, chunk.pageNumber ? `page ${chunk.pageNumber}` : null]
        .filter(Boolean)
        .join(" · ");
      const header = `[${index + 1}] ${chunk.documentTitle}${location ? ` — ${location}` : ""}`;
      return `${header}\n${neutralizeContext(chunk.content)}`;
    }),
  ].join("\n\n");
}

export function toCitations(chunks: readonly RetrievedChunk[]): Citation[] {
  return chunks.map((chunk) => ({
    sourceId: chunk.documentId,
    title: chunk.documentTitle,
    url: chunk.sourceUrl,
    page: chunk.pageNumber,
    snippet: chunk.content.slice(0, 320),
    score: Number(chunk.score.toFixed(4)),
  }));
}

/** 0–1 confidence from the best score, agreement between sources and coverage. */
export function scoreConfidence(chunks: readonly RetrievedChunk[]): number {
  if (chunks.length === 0) return 0;
  const top = chunks[0]?.score ?? 0;
  const mean = chunks.reduce((sum, chunk) => sum + chunk.score, 0) / chunks.length;
  const coverage = Math.min(chunks.length / 4, 1);
  return Number(Math.max(0, Math.min(1, top * 0.55 + mean * 0.25 + coverage * 0.2)).toFixed(3));
}
