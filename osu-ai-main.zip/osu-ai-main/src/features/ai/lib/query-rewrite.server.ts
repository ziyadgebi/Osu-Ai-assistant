/**
 * Query understanding: history-aware rewriting + follow-up suggestions.
 * Uses a small, fast model — failures degrade to the original query.
 */

import { generateText } from "ai";

import { createLovableAiGatewayProvider, getLovableApiKey } from "@/lib/ai-gateway.server";
import type { LanguageCode } from "@/types/i18n.types";

const FAST_MODEL = "google/gemini-2.5-flash-lite";

export interface HistoryTurn {
  readonly role: "user" | "assistant";
  readonly content: string;
}

/** Turns a follow-up ("and the fees?") into a standalone retrieval query. */
export async function rewriteQuery(question: string, history: readonly HistoryTurn[]): Promise<string> {
  if (history.length === 0) return question;
  try {
    const gateway = createLovableAiGatewayProvider(getLovableApiKey());
    const transcript = history
      .slice(-6)
      .map((turn) => `${turn.role === "user" ? "User" : "Assistant"}: ${turn.content.slice(0, 500)}`)
      .join("\n");

    const { text } = await generateText({
      model: gateway(FAST_MODEL),
      instructions:
        "Rewrite the user's latest question into a single standalone search query for a university knowledge base. Keep the original language. Return only the query, no quotes, no explanation.",
      prompt: `Conversation so far:\n${transcript}\n\nLatest question: ${question}\n\nStandalone query:`,
      abortSignal: AbortSignal.timeout(12_000),
    });

    const rewritten = text.trim().replace(/^["']|["']$/g, "");
    return rewritten.length > 3 && rewritten.length < 400 ? rewritten : question;
  } catch (error) {
    console.error("[query-rewrite] failed", error);
    return question;
  }
}

/** Three short follow-up questions grounded in the answer that was just given. */
export async function suggestFollowUps(
  question: string,
  answer: string,
  language: LanguageCode,
): Promise<string[]> {
  if (!answer.trim()) return [];
  try {
    const gateway = createLovableAiGatewayProvider(getLovableApiKey());
    const { text } = await generateText({
      model: gateway(FAST_MODEL),
      instructions: `Suggest exactly 3 short follow-up questions a student might ask next. Write them in the same language as the answer (${language}). Return one question per line, no numbering, no extra text.`,
      prompt: `Question: ${question}\n\nAnswer: ${answer.slice(0, 2000)}`,
      abortSignal: AbortSignal.timeout(12_000),
    });
    return text
      .split("\n")
      .map((line) => line.replace(/^[\s\-*\d.)]+/, "").trim())
      .filter((line) => line.length > 5)
      .slice(0, 3);
  } catch (error) {
    console.error("[follow-ups] failed", error);
    return [];
  }
}

/** Rolling long-term memory: compress the conversation into a short summary. */
export async function summarizeMemory(
  previousSummary: string | null,
  turns: readonly HistoryTurn[],
): Promise<string | null> {
  if (turns.length === 0) return previousSummary;
  try {
    const gateway = createLovableAiGatewayProvider(getLovableApiKey());
    const { text } = await generateText({
      model: gateway(FAST_MODEL),
      instructions:
        "Maintain a compact memory of a university assistant conversation: the user's goals, programme/department of interest, and facts already established. Max 120 words. Return only the memory text.",
      prompt: `Existing memory:\n${previousSummary ?? "(none)"}\n\nNew turns:\n${turns
        .map((turn) => `${turn.role}: ${turn.content.slice(0, 600)}`)
        .join("\n")}`,
      abortSignal: AbortSignal.timeout(12_000),
    });
    return text.trim().slice(0, 1200) || previousSummary;
  } catch (error) {
    console.error("[memory] failed", error);
    return previousSummary;
  }
}

/**
 * Cross-language retrieval: the knowledge base may only hold a fact in one
 * language, so search with the question translated into all supported ones.
 */
export async function translateQueryVariants(query: string): Promise<string[]> {
  const base = query.trim();
  if (!base) return [];
  try {
    const gateway = createLovableAiGatewayProvider(getLovableApiKey());
    const { text } = await generateText({
      model: gateway(FAST_MODEL),
      instructions:
        "Translate the given university search query into English, Afaan Oromoo and Amharic. Return exactly three lines, one translation per line, no labels, no numbering.",
      prompt: base,
      abortSignal: AbortSignal.timeout(12_000),
    });
    const lines = text
      .split("\n")
      .map((line) => line.replace(/^[\s\-*\d.)]+/, "").trim())
      .filter((line) => line.length > 2 && line.length < 400);
    return Array.from(new Set([base, ...lines])).slice(0, 4);
  } catch (error) {
    console.error("[query-translate] failed", error);
    return [base];
  }
}
