/**
 * Provider registry — the only place that knows which vendors exist.
 * Concrete API calls are added later; today each entry is a declarative stub.
 */

import type { AIProviderConfig, AIProviderId } from "@/types/domain.types";
import { BaseAIProvider } from "./base.provider";
import type { AIProviderCapabilities } from "../types/ai-provider.types";

class StubProvider extends BaseAIProvider {
  constructor(
    readonly id: AIProviderId,
    readonly label: string,
    readonly capabilities: AIProviderCapabilities,
  ) {
    super();
  }
}

export const providerCatalog: readonly AIProviderConfig[] = [
  {
    id: "gemini",
    label: "Google Gemini (Lovable AI)",
    enabled: true,
    chatModel: "google/gemini-2.5-flash",
    embeddingModel: "google/gemini-embedding-001",
    supportsSpeech: true,
    supportsTranslation: true,
    secretName: "GOOGLE_API_KEY",
  },
  {
    id: "addis-ai",
    label: "Addis AI",
    enabled: false,
    chatModel: "addis-chat",
    embeddingModel: null,
    supportsSpeech: true,
    supportsTranslation: true,
    secretName: "ADDIS_AI_KEY",
  },
  {
    id: "openrouter",
    label: "OpenRouter",
    enabled: false,
    chatModel: "auto",
    embeddingModel: null,
    supportsSpeech: false,
    supportsTranslation: true,
    secretName: "OPENROUTER_API_KEY",
  },
  {
    id: "ollama",
    label: "Ollama (self-hosted)",
    enabled: false,
    chatModel: "llama3.1",
    embeddingModel: "nomic-embed-text",
    supportsSpeech: false,
    supportsTranslation: false,
    secretName: "OLLAMA_URL",
  },
  {
    id: "openai",
    label: "OpenAI",
    enabled: false,
    chatModel: "gpt-4.1",
    embeddingModel: "text-embedding-3-small",
    supportsSpeech: true,
    supportsTranslation: true,
    secretName: "OPENAI_API_KEY",
  },
  {
    id: "claude",
    label: "Anthropic Claude",
    enabled: false,
    chatModel: "claude-sonnet-4",
    embeddingModel: null,
    supportsSpeech: false,
    supportsTranslation: true,
    secretName: "ANTHROPIC_API_KEY",
  },
  {
    id: "deepseek",
    label: "DeepSeek",
    enabled: false,
    chatModel: "deepseek-chat",
    embeddingModel: null,
    supportsSpeech: false,
    supportsTranslation: true,
    secretName: "DEEPSEEK_API_KEY",
  },
];

const registry = new Map(
  providerCatalog.map((config) => [
    config.id,
    new StubProvider(config.id, config.label, {
      chat: true,
      embed: config.embeddingModel !== null,
      translate: config.supportsTranslation,
      speech: config.supportsSpeech,
    }),
  ]),
);

export const getProvider = (id: AIProviderId) => registry.get(id) ?? null;
export const listProviders = () => Array.from(registry.values());
