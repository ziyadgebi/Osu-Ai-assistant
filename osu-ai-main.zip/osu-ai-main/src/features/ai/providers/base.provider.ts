/**
 * Base class implementing the AIProvider contract with "not implemented" stubs.
 * Concrete providers override only what they support (Liskov-safe).
 */

import { notImplemented, type Result } from "@/types/common.types";
import type { AIProviderId } from "@/types/domain.types";
import type {
  AIProvider,
  AIProviderCapabilities,
  ChatRequest,
  ChatResponse,
  EmbedRequest,
  EmbedResponse,
  SpeechRequest,
  SpeechResponse,
  TranslateRequest,
} from "../types/ai-provider.types";

export abstract class BaseAIProvider implements AIProvider {
  abstract readonly id: AIProviderId;
  abstract readonly label: string;
  abstract readonly capabilities: AIProviderCapabilities;

  async chat(_request: ChatRequest): Promise<Result<ChatResponse>> {
    return notImplemented<ChatResponse>(`${this.constructor.name}.chat`);
  }

  async embed(_request: EmbedRequest): Promise<Result<EmbedResponse>> {
    return notImplemented<EmbedResponse>(`${this.constructor.name}.embed`);
  }

  async translate(_request: TranslateRequest): Promise<Result<string>> {
    return notImplemented<string>(`${this.constructor.name}.translate`);
  }

  async speech(_request: SpeechRequest): Promise<Result<SpeechResponse>> {
    return notImplemented<SpeechResponse>(`${this.constructor.name}.speech`);
  }
}
