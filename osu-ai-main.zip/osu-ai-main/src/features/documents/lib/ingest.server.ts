/**
 * Document ingestion (server-only): clean -> chunk -> embed -> persist to pgvector.
 * Shared by the admin upload flow and the re-index action.
 */

import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/integrations/supabase/types";
import { chunkText } from "@/features/website-sync/lib/chunker.server";
import { embedTexts, EMBEDDING_MODEL } from "@/lib/ai-gateway.server";
import { detectLanguage } from "@/features/ai/lib/language";

type Client = SupabaseClient<Database>;

export interface IngestInput {
  readonly documentId: string;
  readonly text: string;
  readonly language?: string | null;
  readonly sourceUrl?: string | null;
}

export interface IngestResult {
  readonly documentId: string;
  readonly chunks: number;
  readonly embedded: number;
}

export function cleanDocumentText(raw: string): string {
  return raw
    .replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Chunks + embeds the document text and replaces its vectors. */
export async function indexDocument(supabase: Client, input: IngestInput): Promise<IngestResult> {
  const clean = cleanDocumentText(input.text);
  const language = input.language ?? detectLanguage(clean);

  await supabase.from("knowledge_chunks").delete().eq("document_id", input.documentId);

  const chunks = chunkText(clean);
  if (chunks.length === 0) {
    await supabase
      .from("knowledge_documents")
      .update({ chunk_count: 0, embedding_status: "pending", training_status: "untrained" })
      .eq("id", input.documentId);
    return { documentId: input.documentId, chunks: 0, embedded: 0 };
  }

  // Embed in modest batches so a large file never blows the gateway payload.
  const vectors: (readonly number[] | null)[] = [];
  for (let start = 0; start < chunks.length; start += 24) {
    const slice = chunks.slice(start, start + 24).map((chunk) => chunk.content);
    const { vectors: batch } = await embedTexts(slice);
    vectors.push(...batch);
  }

  const rows = chunks.map((chunk, index) => ({
    document_id: input.documentId,
    chunk_index: chunk.index,
    content: chunk.content,
    token_count: chunk.tokenCount,
    section: chunk.section,
    language,
    keywords: [],
    embedding: vectors[index] ? JSON.stringify(vectors[index]) : null,
    embedding_model: vectors[index] ? EMBEDDING_MODEL : null,
    metadata: { source_url: input.sourceUrl ?? null } as never,
  }));

  for (let start = 0; start < rows.length; start += 50) {
    await supabase.from("knowledge_chunks").insert(rows.slice(start, start + 50) as never);
  }

  const embedded = vectors.filter(Boolean).length;
  await supabase
    .from("knowledge_documents")
    .update({
      language,
      clean_text: clean.slice(0, 500_000),
      chunk_count: chunks.length,
      processing_status: "completed",
      embedding_status: embedded === chunks.length ? "completed" : embedded > 0 ? "partial" : "pending",
      training_status: embedded > 0 ? "trained" : "untrained",
    })
    .eq("id", input.documentId);

  return { documentId: input.documentId, chunks: chunks.length, embedded };
}
