/**
 * Browser-side text extraction for admin training uploads.
 * Heavy parsers are imported lazily so they never enter the initial bundle.
 */

export interface ExtractedFile {
  readonly text: string;
  readonly kind: string;
  readonly needsOcr: boolean;
}

const decoder = new TextDecoder();

export const SUPPORTED_EXTENSIONS = [
  "pdf",
  "docx",
  "doc",
  "pptx",
  "xlsx",
  "xls",
  "csv",
  "txt",
  "md",
  "html",
  "htm",
  "json",
  "png",
  "jpg",
  "jpeg",
  "webp",
] as const;

export const extensionOf = (name: string): string => name.split(".").pop()?.toLowerCase() ?? "";

export async function fileToBase64(file: Blob): Promise<string> {
  const buffer = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (let index = 0; index < buffer.length; index += 8192) {
    binary += String.fromCharCode(...buffer.subarray(index, index + 8192));
  }
  return btoa(binary);
}

function stripHtml(html: string): string {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("script, style, noscript").forEach((node) => node.remove());
  return (doc.body?.textContent ?? "").replace(/\n{3,}/g, "\n\n");
}

async function extractPdf(file: File): Promise<string> {
  const pdfjs = await import("pdfjs-dist");
  const worker = await import("pdfjs-dist/build/pdf.worker.mjs?url");
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;

  const task = pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) });
  const document = await task.promise;
  const pages: string[] = [];
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent();
    const text = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (text) pages.push(`## Page ${pageNumber}\n\n${text}`);
  }
  return pages.join("\n\n");
}

async function extractDocx(file: File): Promise<string> {
  const mammoth = await import("mammoth/mammoth.browser.js");
  const result = await (mammoth as unknown as {
    extractRawText: (input: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string }>;
  }).extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return result.value;
}

async function extractPptx(file: File): Promise<string> {
  const JSZip = (await import("jszip")).default;
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const slideNames = Object.keys(zip.files)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a, b) => Number(a.match(/\d+/)?.[0]) - Number(b.match(/\d+/)?.[0]));

  const slides: string[] = [];
  for (const [index, name] of slideNames.entries()) {
    const xml = await zip.files[name].async("string");
    const text = Array.from(xml.matchAll(/<a:t>([^<]*)<\/a:t>/g))
      .map((match) => match[1])
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    if (text) slides.push(`## Slide ${index + 1}\n\n${text}`);
  }
  return slides.join("\n\n");
}

async function extractSpreadsheet(file: File): Promise<string> {
  const XLSX = await import("xlsx");
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
  return workbook.SheetNames.map((name) => {
    const csv = XLSX.utils.sheet_to_csv(workbook.Sheets[name]);
    return csv.trim() ? `## Sheet: ${name}\n\n${csv.trim()}` : "";
  })
    .filter(Boolean)
    .join("\n\n");
}

/** Returns plain text for a file, or flags that server-side OCR is required. */
export async function extractTextFromFile(file: File): Promise<ExtractedFile> {
  const extension = extensionOf(file.name);

  if (extension === "pdf") {
    const text = await extractPdf(file);
    return { text, kind: "pdf", needsOcr: text.trim().length < 40 };
  }
  if (extension === "docx" || extension === "doc") {
    return { text: await extractDocx(file), kind: "word", needsOcr: false };
  }
  if (extension === "pptx") {
    return { text: await extractPptx(file), kind: "slides", needsOcr: false };
  }
  if (extension === "xlsx" || extension === "xls") {
    return { text: await extractSpreadsheet(file), kind: "spreadsheet", needsOcr: false };
  }
  if (extension === "html" || extension === "htm") {
    return { text: stripHtml(decoder.decode(await file.arrayBuffer())), kind: "html", needsOcr: false };
  }
  if (["png", "jpg", "jpeg", "webp"].includes(extension)) {
    return { text: "", kind: "image", needsOcr: true };
  }
  return { text: decoder.decode(await file.arrayBuffer()), kind: "text", needsOcr: false };
}
