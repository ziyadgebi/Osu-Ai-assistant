/**
 * Admin-only document training server functions.
 * Module scope stays thin: runtime helpers live in ../lib/*.server.ts.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ingestSchema = z.object({
  title: z.string().min(1).max(300),
  fileName: z.string().min(1).max(255),
  fileExtension: z.string().min(1).max(12),
  fileType: z.string().min(1).max(150),
  fileSize: z.number().int().min(0),
  text: z.string().min(1),
  description: z.string().max(1000).optional().nullable(),
  department: z.string().max(150).optional().nullable(),
  fileBase64: z.string().optional().nullable(),
});

const idSchema = z.object({ documentId: z.string().uuid() });

const ocrSchema = z.object({
  fileName: z.string().min(1),
  mimeType: z.string().min(1),
  dataBase64: z.string().min(1),
});

async function assertAdmin(context: { supabase: { rpc: (fn: never, args: never) => Promise<{ data: unknown }> }; userId: string }) {
  const { data } = await context.supabase.rpc("is_admin" as never, { _user_id: context.userId } as never);
  if (!data) throw new Error("Forbidden: administrator role required");
}

export const ingestDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ingestSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { indexDocument, cleanDocumentText } = await import("../lib/ingest.server");

    const clean = cleanDocumentText(data.text);
    if (clean.length < 20) throw new Error("No readable text could be extracted from this file");

    let storagePath: string | null = null;
    if (data.fileBase64) {
      const bytes = Uint8Array.from(atob(data.fileBase64), (char) => char.charCodeAt(0));
      const path = `${context.userId}/${Date.now()}-${data.fileName.replace(/[^\w.-]+/g, "-")}`;
      const { error } = await supabaseAdmin.storage
        .from("knowledge-base")
        .upload(path, bytes, { contentType: data.fileType, upsert: false });
      if (!error) storagePath = path;
      else console.error("[documents] storage upload failed", error.message);
    }

    const { data: document, error } = await supabaseAdmin
      .from("knowledge_documents")
      .insert({
        title: data.title.slice(0, 300),
        description: data.description ?? null,
        department: data.department ?? null,
        source: "upload",
        file_name: data.fileName,
        file_extension: data.fileExtension.toLowerCase(),
        file_type: data.fileType,
        file_size: data.fileSize,
        storage_path: storagePath,
        raw_text: data.text.slice(0, 500_000),
        clean_text: clean.slice(0, 500_000),
        status: "active",
        processing_status: "processing",
        embedding_status: "pending",
        training_status: "untrained",
        uploaded_by: context.userId,
      })
      .select("id")
      .single();
    if (error || !document) throw new Error(error?.message ?? "Could not create the document");

    const result = await indexDocument(supabaseAdmin, { documentId: document.id, text: clean });
    return result;
  });

export const reindexDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { indexDocument } = await import("../lib/ingest.server");

    const { data: document } = await supabaseAdmin
      .from("knowledge_documents")
      .select("id, clean_text, raw_text, source_url")
      .eq("id", data.documentId)
      .maybeSingle();
    if (!document) throw new Error("Document not found");

    const text = document.clean_text || document.raw_text || "";
    if (!text) throw new Error("This document has no stored text to re-index");
    return indexDocument(supabaseAdmin, {
      documentId: document.id,
      text,
      sourceUrl: document.source_url,
    });
  });

export const deleteDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => idSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: document } = await supabaseAdmin
      .from("knowledge_documents")
      .select("id, storage_path")
      .eq("id", data.documentId)
      .maybeSingle();
    if (!document) return { deleted: false };

    if (document.storage_path) {
      await supabaseAdmin.storage.from("knowledge-base").remove([document.storage_path]);
    }
    await supabaseAdmin.from("knowledge_chunks").delete().eq("document_id", document.id);
    await supabaseAdmin.from("knowledge_documents").delete().eq("id", document.id);
    return { deleted: true };
  });

/** Vision OCR for images (PNG/JPG/WebP) through the Lovable AI gateway. */
export const ocrImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ocrSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { getLovableApiKey, AI_GATEWAY_BASE_URL } = await import("@/lib/ai-gateway.server");

    const response = await fetch(`${AI_GATEWAY_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": getLovableApiKey() },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Transcribe every piece of text visible in this image exactly, preserving headings, lists and tables as plain text. If there is no text, describe the image factually in two sentences.",
              },
              { type: "image_url", image_url: { url: `data:${data.mimeType};base64,${data.dataBase64}` } },
            ],
          },
        ],
      }),
    });
    if (!response.ok) throw new Error(`Image reading failed (${response.status})`);
    const payload = (await response.json()) as { choices?: { message?: { content?: string } }[] };
    return { text: payload.choices?.[0]?.message?.content ?? "" };
  });
