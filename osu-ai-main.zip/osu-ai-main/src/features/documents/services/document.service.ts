/** DocumentService — upload, parse and index PDF / Word / Excel / media assets. */

import { notImplemented, type Paginated, type Result } from "@/types/common.types";
import type { KnowledgeDocument } from "@/types/domain.types";

export const documentService = {
  async list(): Promise<Result<Paginated<KnowledgeDocument>>> {
    return notImplemented("DocumentService.list");
  },
  async upload(_file: File): Promise<Result<KnowledgeDocument>> {
    return notImplemented("DocumentService.upload");
  },
  async remove(_id: string): Promise<Result<void>> {
    return notImplemented("DocumentService.remove");
  },
  async reindex(_id: string): Promise<Result<void>> {
    return notImplemented("DocumentService.reindex");
  },
};
