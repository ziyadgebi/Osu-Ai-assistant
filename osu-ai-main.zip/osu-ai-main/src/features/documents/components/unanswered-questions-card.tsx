/** Questions the assistant could not answer — admins answer them to train the knowledge base. */

import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, HelpCircle, Loader2, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { ingestDocument } from "@/features/documents/services/document.functions";

interface QuestionRow {
  id: string;
  question: string;
  language: string;
  ask_count: number;
  created_at: string;
}

interface UnansweredQuestionsCardProps {
  readonly onTrained?: () => void | Promise<void>;
}

export function UnansweredQuestionsCard({ onTrained }: UnansweredQuestionsCardProps) {
  const [rows, setRows] = useState<QuestionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("unanswered_questions")
      .select("id, question, language, ask_count, created_at")
      .eq("status", "open")
      .order("ask_count", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(50);
    setRows((data ?? []) as QuestionRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const train = async (row: QuestionRow) => {
    const answer = (drafts[row.id] ?? "").trim();
    if (answer.length < 10) {
      toast.error("Write the answer first.");
      return;
    }
    setSavingId(row.id);
    try {
      const text = `Question: ${row.question}\n\nAnswer: ${answer}`;
      await ingestDocument({
        data: {
          title: `Q&A — ${row.question.slice(0, 200)}`,
          fileName: `qa-${row.id}.txt`,
          fileExtension: "txt",
          fileType: "text/plain",
          fileSize: new TextEncoder().encode(text).length,
          text,
        },
      });
      await supabase
        .from("unanswered_questions")
        .update({ status: "answered", answer, answered_at: new Date().toISOString() })
        .eq("id", row.id);
      toast.success("Assistant trained on this question");
      setDrafts((current) => ({ ...current, [row.id]: "" }));
      await load();
      await onTrained?.();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Training failed");
    } finally {
      setSavingId(null);
    }
  };

  const dismiss = async (id: string) => {
    await supabase.from("unanswered_questions").update({ status: "dismissed" }).eq("id", id);
    await load();
  };

  return (
    <Card className="mt-6">
      <CardHeader className="flex-row items-center justify-between gap-4">
        <div>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="size-5 text-primary" /> Unanswered questions
          </CardTitle>
          <CardDescription>
            Questions the assistant could not ground in the knowledge base. Answer one to train it instantly.
          </CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={() => void load()} disabled={loading}>
          <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} /> Refresh
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {rows.length === 0 && !loading ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            Nothing pending — the assistant answered every recent question.
          </p>
        ) : null}
        {rows.map((row) => (
          <div key={row.id} className="space-y-2 rounded-lg border border-border/60 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-medium">{row.question}</p>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{row.language.toUpperCase()}</Badge>
                <Badge>asked {row.ask_count}×</Badge>
              </div>
            </div>
            <Textarea
              rows={4}
              value={drafts[row.id] ?? ""}
              onChange={(event) => setDrafts((current) => ({ ...current, [row.id]: event.target.value }))}
              placeholder="Write the official answer…"
              aria-label={`Answer for: ${row.question}`}
            />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" size="sm" onClick={() => void dismiss(row.id)}>
                <Trash2 className="size-4" aria-hidden /> Dismiss
              </Button>
              <Button size="sm" onClick={() => void train(row)} disabled={savingId === row.id}>
                {savingId === row.id ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                ) : (
                  <CheckCircle2 className="size-4" aria-hidden />
                )}
                Train with this answer
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
