/** Admin training by typing text directly into the knowledge base. */

import { useState } from "react";
import { Loader2, PenLine } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ingestDocument } from "@/features/documents/services/document.functions";

interface TextTrainingCardProps {
  readonly onTrained?: () => void | Promise<void>;
}

export function TextTrainingCard({ onTrained }: TextTrainingCardProps) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    const body = text.trim();
    if (body.length < 20) {
      toast.error("Write at least a couple of sentences before training.");
      return;
    }
    setSaving(true);
    try {
      const name = title.trim() || body.slice(0, 60);
      const result = await ingestDocument({
        data: {
          title: name.slice(0, 300),
          fileName: `${name.slice(0, 80).replace(/[^\w -]+/g, "-")}.txt`,
          fileExtension: "txt",
          fileType: "text/plain",
          fileSize: new TextEncoder().encode(body).length,
          text: body,
        },
      });
      toast.success("Text trained", { description: `${result.chunks} chunk(s) embedded` });
      setTitle("");
      setText("");
      await onTrained?.();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Training failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PenLine className="size-5 text-primary" /> Train by writing text
        </CardTitle>
        <CardDescription>
          Paste or type official information (policies, fees, department lists…). It is chunked, embedded and cited
          like any uploaded file.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Input
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Title (e.g. Undergraduate admission requirements 2026)"
          aria-label="Knowledge title"
          disabled={saving}
        />
        <Textarea
          value={text}
          onChange={(event) => setText(event.target.value)}
          rows={8}
          placeholder="Write the official information here…"
          aria-label="Knowledge text"
          disabled={saving}
        />
        <div className="flex justify-end">
          <Button onClick={() => void save()} disabled={saving || text.trim().length < 20}>
            {saving ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <PenLine className="size-4" aria-hidden />}
            Train assistant
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
