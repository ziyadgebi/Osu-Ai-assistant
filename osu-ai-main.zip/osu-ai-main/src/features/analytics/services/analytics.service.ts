/** AnalyticsService — usage metrics, unanswered questions, satisfaction. */

import { notImplemented, type Result } from "@/types/common.types";
import type { AnalyticsSnapshot } from "@/types/domain.types";

export const analyticsService = {
  async getSnapshot(): Promise<Result<AnalyticsSnapshot>> {
    return notImplemented("AnalyticsService.getSnapshot");
  },
  async trackEvent(_name: string, _payload?: Record<string, unknown>): Promise<Result<void>> {
    return notImplemented("AnalyticsService.trackEvent");
  },
};
