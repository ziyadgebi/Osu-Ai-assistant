/**
 * AuthService — authentication facade backed by Lovable Cloud auth.
 * Roles are always resolved from the dedicated user_roles table, never from a profile row.
 */

import { supabase } from "@/integrations/supabase/client";
import { fail, ok, type Result } from "@/types/common.types";
import type { UserProfile, UserRole } from "@/types/domain.types";
import type { LanguageCode } from "@/types/i18n.types";

export interface Credentials {
  readonly email: string;
  readonly password: string;
}

interface ProfileRow {
  id: string;
  email: string | null;
  full_name: string | null;
  avatar_url: string | null;
  department: string | null;
  preferred_language: string;
  created_at: string;
}

const toProfile = (row: ProfileRow): UserProfile => ({
  id: row.id,
  email: row.email ?? "",
  fullName: row.full_name ?? row.email ?? "Unknown",
  avatarUrl: row.avatar_url,
  department: row.department,
  preferredLanguage: (row.preferred_language as LanguageCode) ?? "en",
  createdAt: row.created_at,
});

async function ensureProfile(userId: string, email: string | undefined, fullName?: string): Promise<UserProfile | null> {
  const { data } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
  if (data) return toProfile(data as ProfileRow);

  const { data: created, error } = await supabase
    .from("profiles")
    .insert({ id: userId, email: email ?? null, full_name: fullName ?? email ?? null })
    .select("*")
    .maybeSingle();
  if (error || !created) return null;
  return toProfile(created as ProfileRow);
}

export const authService = {
  async getSession(): Promise<Result<UserProfile | null>> {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) return ok(null);
    const profile = await ensureProfile(data.user.id, data.user.email ?? undefined);
    return ok(profile);
  },

  async signInWithPassword({ email, password }: Credentials): Promise<Result<UserProfile>> {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data.user) return fail("AUTH_SIGN_IN", error?.message ?? "Sign in failed");
    const profile = await ensureProfile(data.user.id, data.user.email ?? undefined);
    return profile ? ok(profile) : fail("AUTH_PROFILE", "Could not load your profile");
  },


  async signUp({ email, password }: Credentials, fullName: string): Promise<Result<UserProfile>> {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/`, data: { full_name: fullName } },
    });
    if (error || !data.user) return fail("AUTH_SIGN_UP", error?.message ?? "Sign up failed");
    const profile = await ensureProfile(data.user.id, data.user.email ?? undefined, fullName);
    return profile ? ok(profile) : fail("AUTH_PROFILE", "Account created — please sign in.");
  },

  async signOut(): Promise<Result<void>> {
    const { error } = await supabase.auth.signOut();
    return error ? fail("AUTH_SIGN_OUT", error.message) : ok(undefined);
  },

  /** Roles are read from the dedicated user_roles table. */
  async getRoles(userId: string): Promise<Result<readonly UserRole[]>> {
    const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    if (error) return fail("AUTH_ROLES", error.message);
    return ok((data ?? []).map((row) => row.role as UserRole));
  },

  /** Bootstraps the very first administrator when no admin exists yet. */
  async claimSuperAdmin(): Promise<Result<boolean>> {
    const { data, error } = await supabase.rpc("claim_super_admin");
    if (error) return fail("AUTH_CLAIM", error.message);
    return ok(Boolean(data));
  },
};
