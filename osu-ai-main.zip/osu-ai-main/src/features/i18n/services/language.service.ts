/** LanguageService — detection and translation across English, Afaan Oromo, Amharic. */

import { notImplemented, type Result } from "@/types/common.types";
import type { LanguageCode } from "@/types/i18n.types";

export const languageService = {
  async detect(_text: string): Promise<Result<LanguageCode>> {
    return notImplemented("LanguageService.detect");
  },
  async translate(_text: string, _to: LanguageCode): Promise<Result<string>> {
    return notImplemented("LanguageService.translate");
  },
};
