/** Translation dictionaries. Kept flat and typed; extracted to a CMS later. */

import type { LanguageCode, LanguageDefinition, TranslationDictionary } from "@/types/i18n.types";

export const languages: readonly LanguageDefinition[] = [
  { code: "en", label: "English", nativeLabel: "English", direction: "ltr" },
  { code: "om", label: "Afaan Oromo", nativeLabel: "Afaan Oromoo", direction: "ltr" },
  { code: "am", label: "Amharic", nativeLabel: "አማርኛ", direction: "ltr" },
];

const en: TranslationDictionary = {
  "nav.home": "Home",
  "nav.chat": "Chat",
  "nav.admin": "Admin",
  "nav.login": "Sign in",
  "home.tagline": "Official AI assistant of Oromia State University",
  "home.title": "Ask anything about Oromia State University",
  "home.subtitle":
    "Grounded answers from official documents, policies, research and the university website — always with citations.",
  "home.cta": "Open the assistant",
  "chat.placeholder": "The assistant is coming soon.",
  "common.comingSoon": "Coming soon",
};

const om: TranslationDictionary = {
  "nav.home": "Fuula Duraa",
  "nav.chat": "Marii",
  "nav.admin": "Bulchiinsa",
  "nav.login": "Seeni",
  "home.tagline": "Gargaaraa AI ifaa Yunivarsiitii Mootummaa Oromiyaa",
  "home.title": "Waa'ee Yunivarsiitii Mootummaa Oromiyaa gaafadhu",
  "home.subtitle":
    "Deebii sirrii galmee, imaammata, qorannoo fi marsariitii yunivarsiitii irraa — yeroo hunda madda waliin.",
  "home.cta": "Gargaaraa banii",
  "chat.placeholder": "Gargaaraan dhiyootti ni dhufa.",
  "common.comingSoon": "Dhiyootti",
};

const am: TranslationDictionary = {
  "nav.home": "መነሻ",
  "nav.chat": "ውይይት",
  "nav.admin": "አስተዳደር",
  "nav.login": "ግባ",
  "home.tagline": "የኦሮሚያ ስቴት ዩኒቨርሲቲ ይፋዊ የAI ረዳት",
  "home.title": "ስለ ኦሮሚያ ስቴት ዩኒቨርሲቲ ማንኛውንም ይጠይቁ",
  "home.subtitle": "ከይፋዊ ሰነዶች፣ ፖሊሲዎች፣ ጥናቶችና ከዩኒቨርሲቲው ድረ-ገጽ የተመሠረቱ መልሶች — ሁልጊዜ ከምንጭ ጋር።",
  "home.cta": "ረዳቱን ክፈት",
  "chat.placeholder": "ረዳቱ በቅርቡ ይመጣል።",
  "common.comingSoon": "በቅርቡ",
};

export const dictionaries: Readonly<Record<LanguageCode, TranslationDictionary>> = { en, om, am };
