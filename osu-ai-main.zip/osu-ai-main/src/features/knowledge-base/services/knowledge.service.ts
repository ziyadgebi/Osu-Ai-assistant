/** KnowledgeService — chunking, embedding and vector retrieval (pgvector). */

import { notImplemented, type Result } from "@/types/common.types";
import type { KnowledgeChunk } from "@/types/domain.types";

export interface RetrievalQuery {
  readonly query: string;
  readonly topK?: number;
  readonly minimumScore?: number;
}

export interface RetrievedChunk extends KnowledgeChunk {
  readonly score: number;
}

export const knowledgeService = {
  async retrieve(_query: RetrievalQuery): Promise<Result<readonly RetrievedChunk[]>> {
    return notImplemented("KnowledgeService.retrieve");
  },
  async chunkDocument(_documentId: string): Promise<Result<number>> {
    return notImplemented("KnowledgeService.chunkDocument");
  },
  async rebuildIndex(): Promise<Result<void>> {
    return notImplemented("KnowledgeService.rebuildIndex");
  },
};
