/** VoiceService — speech-to-text and text-to-speech placeholders. */

import { notImplemented, type Result } from "@/types/common.types";
import type { LanguageCode } from "@/types/i18n.types";

export const voiceService = {
  async speechToText(_audio: Blob, _language: LanguageCode): Promise<Result<string>> {
    return notImplemented("VoiceService.speechToText");
  },
  async textToSpeech(_text: string, _language: LanguageCode): Promise<Result<string>> {
    return notImplemented("VoiceService.textToSpeech");
  },
};
