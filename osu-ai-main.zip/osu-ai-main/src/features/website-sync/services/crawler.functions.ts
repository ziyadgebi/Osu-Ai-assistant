/**
 * Crawler server functions — admin-only entry points into the crawling engine.
 * Module scope stays thin: every runtime helper lives in ../lib/*.server.ts.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const startSchema = z.object({
  websiteId: z.string().uuid(),
  mode: z
    .enum(["manual", "full", "incremental", "scheduled", "single-page", "category", "priority", "emergency"])
    .default("manual"),
  url: z.string().url().optional(),
});

const stepSchema = z.object({ jobId: z.string().uuid(), batchSize: z.number().int().min(1).max(25).optional() });
const jobSchema = z.object({ jobId: z.string().uuid() });
const testSchema = z.object({ url: z.string().url() });

export const startCrawl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => startSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("is_admin", { _user_id: userId });
    if (!isAdmin) throw new Error("Forbidden: administrator role required");

    const { data: website, error: websiteError } = await supabase
      .from("websites")
      .select("id, status, base_url")
      .eq("id", data.websiteId)
      .maybeSingle();
    if (websiteError || !website) throw new Error("Website not found");
    if (website.status === "disabled") throw new Error("Website is disabled");

    const { data: running } = await supabase
      .from("crawl_jobs")
      .select("id")
      .eq("website_id", data.websiteId)
      .in("status", ["pending", "running"])
      .maybeSingle();
    if (running) return { jobId: running.id, resumed: true };

    const { data: job, error } = await supabase
      .from("crawl_jobs")
      .insert({ website_id: data.websiteId, mode: data.mode, status: "pending", created_by: userId })
      .select("id")
      .single();
    if (error || !job) throw new Error(error?.message ?? "Could not create crawl job");

    if (data.mode === "single-page" && data.url) {
      await supabase.from("crawl_queue").insert({
        website_id: data.websiteId,
        job_id: job.id,
        url: data.url,
        depth: 0,
        priority: 100,
        source: "manual",
        status: "pending",
      });
      await supabase.from("crawl_jobs").update({ status: "running", started_at: new Date().toISOString() }).eq("id", job.id);
    }

    return { jobId: job.id, resumed: false };
  });

export const runCrawlStep = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => stepSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("is_admin", { _user_id: userId });
    if (!isAdmin) throw new Error("Forbidden: administrator role required");

    const { runCrawlBatch } = await import("../lib/crawler.server");
    return runCrawlBatch(supabase, { jobId: data.jobId, batchSize: data.batchSize, userId });
  });

export const cancelCrawl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => jobSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("is_admin", { _user_id: userId });
    if (!isAdmin) throw new Error("Forbidden: administrator role required");

    const { data: job } = await supabase.from("crawl_jobs").select("website_id").eq("id", data.jobId).maybeSingle();
    await supabase
      .from("crawl_jobs")
      .update({ status: "cancelled", finished_at: new Date().toISOString() })
      .eq("id", data.jobId);
    if (job) {
      await supabase
        .from("crawl_queue")
        .update({ status: "cancelled", processed_at: new Date().toISOString() })
        .eq("job_id", data.jobId)
        .in("status", ["pending", "retrying", "running"]);
    }
    return { cancelled: true };
  });

export const testWebsite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => testSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("is_admin", { _user_id: userId });
    if (!isAdmin) throw new Error("Forbidden: administrator role required");

    const { testUrl } = await import("../lib/crawler.server");
    return testUrl(data.url);
  });
