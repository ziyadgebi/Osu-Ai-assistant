/** WebsiteService — CRUD, settings and dashboard statistics for crawled websites. */

import { supabase } from "@/integrations/supabase/client";
import { fail, ok, type Result } from "@/types/common.types";
import type { CrawlSettings, Website, WebsiteDashboardStats } from "../types/website.types";

export interface WebsiteInput {
  readonly name: string;
  readonly base_url: string;
  readonly description?: string | null;
  readonly logo_url?: string | null;
  readonly language?: string;
  readonly frequency?: string;
  readonly cron_expression?: string | null;
  readonly status?: string;
}

export const websiteService = {
  async list(): Promise<Result<readonly Website[]>> {
    const { data, error } = await supabase
      .from("websites")
      .select("*")
      .is("deleted_at", null)
      .order("created_at", { ascending: false });
    return error ? fail("WEBSITE_LIST", error.message) : ok((data ?? []) as unknown as Website[]);
  },

  async get(id: string): Promise<Result<Website | null>> {
    const { data, error } = await supabase.from("websites").select("*").eq("id", id).maybeSingle();
    return error ? fail("WEBSITE_GET", error.message) : ok((data as unknown as Website) ?? null);
  },

  async create(input: WebsiteInput): Promise<Result<Website>> {
    const { data: session } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("websites")
      .insert({ ...input, owner_id: session.user?.id ?? null })
      .select("*")
      .single();
    if (error || !data) return fail("WEBSITE_CREATE", error?.message ?? "Could not create website");

    // Every website gets a default settings row so the crawler always has a configuration.
    await supabase.from("crawl_settings").insert({ website_id: data.id });
    return ok(data as unknown as Website);
  },

  async update(id: string, input: Partial<WebsiteInput>): Promise<Result<Website>> {
    const { data, error } = await supabase.from("websites").update(input).eq("id", id).select("*").single();
    return error || !data
      ? fail("WEBSITE_UPDATE", error?.message ?? "Could not update website")
      : ok(data as unknown as Website);
  },

  async setStatus(id: string, status: "active" | "paused" | "disabled"): Promise<Result<void>> {
    const { error } = await supabase.from("websites").update({ status }).eq("id", id);
    return error ? fail("WEBSITE_STATUS", error.message) : ok(undefined);
  },

  async remove(id: string): Promise<Result<void>> {
    const { error } = await supabase.from("websites").update({ deleted_at: new Date().toISOString() }).eq("id", id);
    return error ? fail("WEBSITE_DELETE", error.message) : ok(undefined);
  },

  async getSettings(websiteId: string): Promise<Result<CrawlSettings | null>> {
    const { data, error } = await supabase
      .from("crawl_settings")
      .select("*")
      .eq("website_id", websiteId)
      .maybeSingle();
    if (error) return fail("SETTINGS_GET", error.message);
    if (data) return ok(data as unknown as CrawlSettings);
    const { data: created, error: createError } = await supabase
      .from("crawl_settings")
      .insert({ website_id: websiteId })
      .select("*")
      .maybeSingle();
    return createError ? fail("SETTINGS_GET", createError.message) : ok((created as unknown as CrawlSettings) ?? null);
  },

  async updateSettings(websiteId: string, patch: Partial<CrawlSettings>): Promise<Result<void>> {
    const { error } = await supabase.from("crawl_settings").update(patch).eq("website_id", websiteId);
    return error ? fail("SETTINGS_UPDATE", error.message) : ok(undefined);
  },

  async dashboard(): Promise<Result<WebsiteDashboardStats>> {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const count = async (build: () => PromiseLike<{ count: number | null }>) => (await build()).count ?? 0;

    try {
      const [totalWebsites, indexedPages, crawledToday, updatedPages, failedPages, pendingQueue, duplicatePages, brokenPages] =
        await Promise.all([
          count(() => supabase.from("websites").select("id", { count: "exact", head: true }).is("deleted_at", null)),
          count(() => supabase.from("website_pages").select("id", { count: "exact", head: true }).is("deleted_at", null)),
          count(() =>
            supabase
              .from("website_pages")
              .select("id", { count: "exact", head: true })
              .gte("last_crawled_at", startOfDay.toISOString()),
          ),
          count(() => supabase.from("website_pages").select("id", { count: "exact", head: true }).eq("status", "updated")),
          count(() => supabase.from("website_pages").select("id", { count: "exact", head: true }).eq("status", "failed")),
          count(() =>
            supabase.from("crawl_queue").select("id", { count: "exact", head: true }).in("status", ["pending", "retrying"]),
          ),
          count(() => supabase.from("website_pages").select("id", { count: "exact", head: true }).eq("is_duplicate", true)),
          count(() => supabase.from("website_pages").select("id", { count: "exact", head: true }).eq("status", "broken")),
        ]);

      const { data: sizes } = await supabase.from("website_pages").select("word_count").is("deleted_at", null).limit(5000);
      const storageBytes = (sizes ?? []).reduce((total, row) => total + (row.word_count ?? 0) * 6, 0);

      const { data: durations } = await supabase
        .from("crawl_jobs")
        .select("duration_ms")
        .eq("status", "completed")
        .not("duration_ms", "is", null)
        .limit(50);
      const averageCrawlMs =
        (durations ?? []).length > 0
          ? Math.round((durations ?? []).reduce((total, row) => total + (row.duration_ms ?? 0), 0) / (durations ?? []).length)
          : 0;

      return ok({
        totalWebsites,
        indexedPages,
        crawledToday,
        updatedPages,
        failedPages,
        pendingQueue,
        storageBytes,
        averageCrawlMs,
        duplicatePages,
        brokenPages,
      });
    } catch (error) {
      return fail("WEBSITE_STATS", error instanceof Error ? error.message : "Could not load statistics");
    }
  },
};
