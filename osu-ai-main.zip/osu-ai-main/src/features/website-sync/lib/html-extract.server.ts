/**
 * HTML extraction & cleaning (server-only, DOM-free).
 * Turns a raw university web page into meaningful, noise-free content plus metadata.
 */

import type { PageType } from "../types/website.types";

export interface ExtractedLink {
  readonly url: string;
  readonly text: string;
}

export interface ExtractedFile {
  readonly url: string;
  readonly kind: string;
  readonly label: string;
}

export interface ExtractedPage {
  readonly title: string;
  readonly subtitle: string | null;
  readonly description: string | null;
  readonly canonical: string | null;
  readonly langAttribute: string | null;
  readonly author: string | null;
  readonly publishedAt: string | null;
  readonly updatedAt: string | null;
  readonly headings: readonly { level: number; text: string }[];
  readonly breadcrumbs: readonly string[];
  readonly paragraphs: readonly string[];
  readonly lists: readonly string[][];
  readonly tables: readonly string[][][];
  readonly links: readonly ExtractedLink[];
  readonly images: readonly string[];
  readonly files: readonly ExtractedFile[];
  readonly extracted: string;
  readonly clean: string;
  readonly wordCount: number;
  readonly metadata: Record<string, string>;
}

const NOISE_TAGS = [
  "script",
  "style",
  "noscript",
  "iframe",
  "svg",
  "nav",
  "header",
  "footer",
  "aside",
  "form",
  "template",
];

const NOISE_CLASS_PATTERN =
  /(cookie|consent|advert|ads?-|banner|social|share|sidebar|menu|breadcrumb|skip-link|pagination|newsletter|popup|modal|tracking|widget-footer|site-header|site-footer)/i;

const FILE_KINDS: Record<string, string> = {
  pdf: "pdf",
  doc: "docx",
  docx: "docx",
  xls: "xlsx",
  xlsx: "xlsx",
  ppt: "pptx",
  pptx: "pptx",
  zip: "zip",
  csv: "csv",
  txt: "txt",
  jpg: "image",
  jpeg: "image",
  png: "image",
  gif: "image",
  webp: "image",
  mp4: "video",
  webm: "video",
  mp3: "audio",
  wav: "audio",
};

const decodeEntities = (input: string): string =>
  input
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_match, code: string) => String.fromCharCode(Number(code)));

const stripTags = (html: string): string => decodeEntities(html.replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();

const removeNoise = (html: string): string => {
  let output = html;
  for (const tag of NOISE_TAGS) {
    output = output.replace(new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?</${tag}>`, "gi"), " ");
    output = output.replace(new RegExp(`<${tag}\\b[^>]*/?>`, "gi"), " ");
  }
  output = output.replace(/<!--[\s\S]*?-->/g, " ");
  // Drop obvious chrome containers identified by class/id naming.
  output = output.replace(
    /<div\b[^>]*(?:class|id)="[^"]*"[^>]*>/gi,
    (match) => (NOISE_CLASS_PATTERN.test(match) ? "<div data-noise>" : match),
  );
  output = output.replace(/\[hidden\]|aria-hidden="true"/gi, "");
  return output;
};

const pickMainRegion = (html: string): string => {
  const candidates = [
    /<main\b[^>]*>([\s\S]*?)<\/main>/i,
    /<article\b[^>]*>([\s\S]*?)<\/article>/i,
    /<div\b[^>]*(?:id|class)="[^"]*(content|main|page-body|entry)[^"]*"[^>]*>([\s\S]*?)<\/div>/i,
    /<body\b[^>]*>([\s\S]*?)<\/body>/i,
  ];
  for (const pattern of candidates) {
    const match = html.match(pattern);
    if (match) {
      const body = match[match.length - 1] ?? "";
      if (stripTags(body).length > 200) return body;
    }
  }
  return html;
};

const metaContent = (html: string, name: string): string | null => {
  const pattern = new RegExp(
    `<meta[^>]+(?:name|property)=["']${name}["'][^>]*content=["']([^"']*)["']`,
    "i",
  );
  const alt = new RegExp(
    `<meta[^>]+content=["']([^"']*)["'][^>]*(?:name|property)=["']${name}["']`,
    "i",
  );
  return html.match(pattern)?.[1] ?? html.match(alt)?.[1] ?? null;
};

const absolute = (href: string, base: string): string | null => {
  try {
    const url = new URL(href, base);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    url.hash = "";
    return url.toString();
  } catch {
    return null;
  }
};

/** Cleans extracted text: collapses whitespace, drops artefacts and repeated boilerplate lines. */
export function cleanText(input: string): string {
  const lines = input
    .split("\n")
    .map((line) => line.replace(/[ \t\u00a0]+/g, " ").trim())
    .filter((line) => line.length > 0);

  const seen = new Map<string, number>();
  for (const line of lines) seen.set(line, (seen.get(line) ?? 0) + 1);

  const kept: string[] = [];
  for (const line of lines) {
    const repeats = seen.get(line) ?? 0;
    if (repeats > 3 && line.length < 80) continue; // repeated header/footer fragment
    if (/^[^\p{L}\p{N}]+$/u.test(line)) continue; // decorative separators
    if (kept[kept.length - 1] === line) continue;
    kept.push(line);
  }
  return kept.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

/** Script + stop-word detection for English, Afaan Oromoo and Amharic. */
export function detectLanguage(text: string, fallback = "en"): string {
  const sample = text.slice(0, 4000);
  const ethiopic = (sample.match(/[\u1200-\u137F]/g) ?? []).length;
  if (ethiopic > sample.length * 0.08) return "am";

  const lower = ` ${sample.toLowerCase()} `;
  const oromo = ["akkasumas", "barnoota", "yunivarsiitii", "waa'ee", "keessatti", "fi ", "kan ", "guyyaa", "hojii"];
  const english = [" the ", " and ", " university", " student", " research", " admission", " of ", " for "];
  const oromoScore = oromo.reduce((total, token) => total + (lower.split(token).length - 1), 0);
  const englishScore = english.reduce((total, token) => total + (lower.split(token).length - 1), 0);
  if (oromoScore > englishScore && oromoScore > 2) return "om";
  if (englishScore > 0) return "en";
  return fallback;
}

/** Rule-based page classification from URL and title. */
export function classifyPage(url: string, title: string): PageType {
  const haystack = `${url} ${title}`.toLowerCase();
  const rules: readonly [PageType, RegExp][] = [
    ["admission", /admission|apply|enroll|entrance/],
    ["registrar", /registrar|registration|transcript/],
    ["library", /librar/],
    ["scholarship", /scholarship|bursary|financial-aid/],
    ["research", /research|publication|journal|innovation/],
    ["staff", /staff|faculty-members|academic-staff|team/],
    ["news", /news|blog|press/],
    ["announcement", /announce|notice|vacanc/],
    ["event", /event|conference|workshop|graduation/],
    ["policy", /policy|policies|guideline|regulation|senate-legislation/],
    ["contact", /contact|address|reach-us/],
    ["downloads", /download|forms?|resources?\/files/],
    ["academic-calendar", /calendar|academic-year|schedule/],
    ["department", /department|college|school|institute|program|faculty/],
  ];
  for (const [type, pattern] of rules) if (pattern.test(haystack)) return type;
  try {
    const parsed = new URL(url);
    if (parsed.pathname === "/" || parsed.pathname === "") return "home";
  } catch {
    /* ignore */
  }
  return "general";
}

/** Maps a page type onto a knowledge-base category. */
export function mapCategory(pageType: PageType): string {
  const map: Record<PageType, string> = {
    home: "General",
    department: "Departments",
    admission: "Admissions",
    registrar: "Registrar",
    library: "Library",
    scholarship: "Scholarships",
    research: "Research",
    staff: "Administration",
    news: "News",
    announcement: "News",
    event: "Events",
    policy: "Policies",
    contact: "Campus",
    downloads: "General",
    "academic-calendar": "Registrar",
    general: "General",
  };
  return map[pageType];
}

export async function sha256(input: string): Promise<string> {
  const bytes = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

/** Jaccard similarity over word sets — used for near-duplicate detection. */
export function similarity(left: string, right: string): number {
  const tokenize = (value: string) => new Set(value.toLowerCase().split(/\W+/).filter((word) => word.length > 3));
  const a = tokenize(left);
  const b = tokenize(right);
  if (a.size === 0 || b.size === 0) return 0;
  let shared = 0;
  for (const token of a) if (b.has(token)) shared += 1;
  return shared / (a.size + b.size - shared);
}

/** Naive line diff between two versions of a page. */
export function diffContent(previous: string, next: string) {
  const before = new Set(previous.split("\n").map((line) => line.trim()).filter(Boolean));
  const after = new Set(next.split("\n").map((line) => line.trim()).filter(Boolean));
  const added: string[] = [];
  const removed: string[] = [];
  for (const line of after) if (!before.has(line)) added.push(line);
  for (const line of before) if (!after.has(line)) removed.push(line);
  return {
    addedCount: added.length,
    removedCount: removed.length,
    added: added.slice(0, 40),
    removed: removed.slice(0, 40),
  };
}

export function extractPage(html: string, baseUrl: string): ExtractedPage {
  const title = stripTags(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] ?? "") || baseUrl;
  const description = metaContent(html, "description") ?? metaContent(html, "og:description");
  const canonical = html.match(/<link[^>]+rel=["']canonical["'][^>]*href=["']([^"']+)["']/i)?.[1] ?? null;
  const langAttribute = html.match(/<html[^>]+lang=["']([^"']+)["']/i)?.[1] ?? null;
  const author = metaContent(html, "author") ?? metaContent(html, "article:author");
  const publishedAt = metaContent(html, "article:published_time") ?? metaContent(html, "datePublished");
  const updatedAt = metaContent(html, "article:modified_time") ?? metaContent(html, "dateModified");

  const breadcrumbs = Array.from(
    html.matchAll(/<(?:nav|ol|ul)[^>]*(?:class|id)="[^"]*breadcrumb[^"]*"[^>]*>([\s\S]*?)<\/(?:nav|ol|ul)>/gi),
  )
    .flatMap((match) => Array.from(match[1].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)).map((item) => stripTags(item[1])))
    .filter(Boolean);

  const main = removeNoise(pickMainRegion(removeNoise(html)));

  const headings = Array.from(main.matchAll(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi))
    .map((match) => ({ level: Number(match[1]), text: stripTags(match[2]) }))
    .filter((heading) => heading.text.length > 0);

  const paragraphs = Array.from(main.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi))
    .map((match) => stripTags(match[1]))
    .filter((text) => text.length > 30);

  const lists = Array.from(main.matchAll(/<(ul|ol)[^>]*>([\s\S]*?)<\/\1>/gi))
    .map((match) => Array.from(match[2].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)).map((item) => stripTags(item[1])))
    .filter((items) => items.filter(Boolean).length > 1);

  const tables = Array.from(main.matchAll(/<table[^>]*>([\s\S]*?)<\/table>/gi)).map((table) =>
    Array.from(table[1].matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)).map((row) =>
      Array.from(row[1].matchAll(/<t[hd][^>]*>([\s\S]*?)<\/t[hd]>/gi)).map((cell) => stripTags(cell[1])),
    ),
  );

  const anchors = Array.from(html.matchAll(/<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi));
  const links: ExtractedLink[] = [];
  const files: ExtractedFile[] = [];
  for (const anchor of anchors) {
    const url = absolute(anchor[1], baseUrl);
    if (!url) continue;
    const text = stripTags(anchor[2]);
    const extension = url.split("?")[0].split("#")[0].split(".").pop()?.toLowerCase() ?? "";
    const kind = FILE_KINDS[extension];
    if (kind) files.push({ url, kind, label: text || url.split("/").pop() || url });
    else links.push({ url, text });
  }

  const images = Array.from(main.matchAll(/<img[^>]+src=["']([^"']+)["']/gi))
    .map((match) => absolute(match[1], baseUrl))
    .filter((value): value is string => value !== null);

  const sections: string[] = [];
  if (title) sections.push(`# ${title}`);
  if (description) sections.push(description);
  for (const heading of headings) sections.push(`${"#".repeat(Math.min(heading.level, 6))} ${heading.text}`);
  sections.push(...paragraphs);
  for (const list of lists) sections.push(list.filter(Boolean).map((item) => `- ${item}`).join("\n"));
  for (const table of tables) {
    const rendered = table.filter((row) => row.length > 0).map((row) => row.join(" | ")).join("\n");
    if (rendered.trim().length > 0) sections.push(rendered);
  }

  const extracted = sections.join("\n\n");
  const clean = cleanText(extracted);
  const subtitle = headings.find((heading) => heading.level === 2)?.text ?? null;

  const metadata: Record<string, string> = {};
  for (const [, name, content] of html.matchAll(
    /<meta[^>]+(?:name|property)=["']([^"']+)["'][^>]*content=["']([^"']*)["'][^>]*>/gi,
  )) {
    if (name && content) metadata[name] = content.slice(0, 500);
  }

  return {
    title,
    subtitle,
    description,
    canonical: canonical ? absolute(canonical, baseUrl) : null,
    langAttribute,
    author,
    publishedAt,
    updatedAt,
    headings,
    breadcrumbs,
    paragraphs,
    lists,
    tables,
    links,
    images,
    files,
    extracted,
    clean,
    wordCount: clean.split(/\s+/).filter(Boolean).length,
    metadata,
  };
}
