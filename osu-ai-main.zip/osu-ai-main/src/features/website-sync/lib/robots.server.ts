/** robots.txt and sitemap.xml handling (server-only). */

export interface RobotsRules {
  readonly disallow: readonly string[];
  readonly allow: readonly string[];
  readonly sitemaps: readonly string[];
  readonly crawlDelayMs: number | null;
}

export const EMPTY_ROBOTS: RobotsRules = { disallow: [], allow: [], sitemaps: [], crawlDelayMs: null };

export function parseRobots(text: string): RobotsRules {
  const disallow: string[] = [];
  const allow: string[] = [];
  const sitemaps: string[] = [];
  let crawlDelayMs: number | null = null;
  let appliesToUs = false;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.split("#")[0].trim();
    if (!line) continue;
    const [rawKey, ...rest] = line.split(":");
    const key = rawKey.trim().toLowerCase();
    const value = rest.join(":").trim();
    if (key === "user-agent") appliesToUs = value === "*";
    else if (key === "sitemap" && value) sitemaps.push(value);
    else if (appliesToUs && key === "disallow" && value) disallow.push(value);
    else if (appliesToUs && key === "allow" && value) allow.push(value);
    else if (appliesToUs && key === "crawl-delay" && value) {
      const seconds = Number(value);
      if (Number.isFinite(seconds)) crawlDelayMs = Math.round(seconds * 1000);
    }
  }
  return { disallow, allow, sitemaps, crawlDelayMs };
}

export function isAllowedByRobots(pathname: string, rules: RobotsRules): boolean {
  const matches = (rule: string) => pathname.startsWith(rule.replace(/\*$/, ""));
  if (rules.allow.some(matches)) return true;
  return !rules.disallow.some(matches);
}

export async function fetchRobots(baseUrl: string, timeoutMs: number): Promise<RobotsRules> {
  try {
    const url = new URL("/robots.txt", baseUrl).toString();
    const response = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) });
    if (!response.ok) return EMPTY_ROBOTS;
    return parseRobots(await response.text());
  } catch {
    return EMPTY_ROBOTS;
  }
}

/** Reads a sitemap (and nested sitemap indexes) and returns the discovered page URLs. */
export async function fetchSitemapUrls(
  sitemapUrl: string,
  timeoutMs: number,
  depth = 0,
  seen = new Set<string>(),
): Promise<string[]> {
  if (depth > 2 || seen.has(sitemapUrl)) return [];
  seen.add(sitemapUrl);
  try {
    const response = await fetch(sitemapUrl, { signal: AbortSignal.timeout(timeoutMs) });
    if (!response.ok) return [];
    const xml = await response.text();
    const locations = Array.from(xml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)).map((match) => match[1]);
    const isIndex = /<sitemapindex/i.test(xml);
    if (!isIndex) return locations;
    const nested = await Promise.all(
      locations.slice(0, 10).map((location) => fetchSitemapUrls(location, timeoutMs, depth + 1, seen)),
    );
    return nested.flat();
  } catch {
    return [];
  }
}

/** Default sitemap locations tried when robots.txt does not declare one. */
export function defaultSitemapCandidates(baseUrl: string): string[] {
  return ["/sitemap.xml", "/sitemap_index.xml", "/wp-sitemap.xml"].map((path) =>
    new URL(path, baseUrl).toString(),
  );
}
