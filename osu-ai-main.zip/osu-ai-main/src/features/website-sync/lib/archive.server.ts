/**
 * Wayback Machine fallback (server-only).
 * The official site is occasionally down; archived snapshots keep the assistant
 * grounded in the university's own published content instead of guessing.
 */

const CDX = "https://web.archive.org/cdx/search/cdx";

export interface ArchivedPage {
  readonly html: string;
  readonly timestamp: string;
  readonly url: string;
}

/** Latest successful snapshot for a single URL, or null. */
export async function fetchArchivedHtml(url: string, timeoutMs = 20_000): Promise<ArchivedPage | null> {
  // Snapshots are keyed by the exact URL, so try the common variants.
  const variants = new Set<string>([url]);
  variants.add(url.endsWith("/") ? url.slice(0, -1) : `${url}/`);
  try {
    const parsed = new URL(url);
    const swapped = parsed.hostname.startsWith("www.")
      ? parsed.hostname.slice(4)
      : `www.${parsed.hostname}`;
    parsed.hostname = swapped;
    variants.add(parsed.toString());
    variants.add(parsed.toString().endsWith("/") ? parsed.toString().slice(0, -1) : `${parsed.toString()}/`);
  } catch {
    /* keep the plain variants */
  }

  for (const candidate of variants) {
    try {
      const query = `${CDX}?url=${encodeURIComponent(candidate)}&output=json&filter=statuscode:200&filter=mimetype:text/html&limit=-1&fl=timestamp`;
      const listing = await fetch(query, { signal: AbortSignal.timeout(timeoutMs) });
      if (!listing.ok) continue;
      const rows = (await listing.json()) as string[][];
      const timestamp = rows.at(-1)?.[0];
      if (!timestamp || timestamp === "timestamp") continue;

      const snapshot = `https://web.archive.org/web/${timestamp}id_/${candidate}`;
      const response = await fetch(snapshot, { signal: AbortSignal.timeout(timeoutMs) });
      if (!response.ok) continue;
      const html = await response.text();
      if (html.length < 200) continue;
      return { html, timestamp, url: candidate };
    } catch {
      /* try the next variant */
    }
  }
  return null;
}


/** Archived URL inventory for a domain — used when the live sitemap is unreachable. */
export async function fetchArchivedUrls(baseUrl: string, limit = 300, timeoutMs = 30_000): Promise<string[]> {
  try {
    const host = new URL(baseUrl).hostname.replace(/^www\./, "");
    const query =
      `${CDX}?url=${encodeURIComponent(host)}*&output=json&filter=statuscode:200&filter=mimetype:text/html` +
      `&collapse=urlkey&fl=original&from=2024&limit=${limit * 3}`;
    const response = await fetch(query, { signal: AbortSignal.timeout(timeoutMs) });
    if (!response.ok) return [];
    const rows = (await response.json()) as string[][];
    const urls = rows
      .slice(1)
      .map((row) => row[0])
      .filter((url) => typeof url === "string" && !url.includes("?") && !/\.(jpg|jpeg|png|gif|pdf|css|js)$/i.test(url));
    return Array.from(new Set(urls)).slice(0, limit);
  } catch {
    return [];
  }
}
