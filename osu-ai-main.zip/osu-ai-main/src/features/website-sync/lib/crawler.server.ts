/**
 * Crawler orchestrator (server-only).
 * Discovery -> queue -> fetch -> extract -> clean -> classify -> change detection ->
 * versioning -> knowledge-base sync (chunks + embeddings).
 *
 * A run is processed in bounded batches so it can resume safely after interruption.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import {
  classifyPage,
  cleanText,
  detectLanguage,
  diffContent,
  extractPage,
  mapCategory,
  sha256,
  similarity,
} from "./html-extract.server";
import { chunkText } from "./chunker.server";
import { defaultSitemapCandidates, fetchRobots, fetchSitemapUrls, isAllowedByRobots } from "./robots.server";
import { fetchArchivedHtml, fetchArchivedUrls } from "./archive.server";

type Client = SupabaseClient<Database>;

export interface BatchResult {
  readonly jobId: string;
  readonly processed: number;
  readonly updated: number;
  readonly failed: number;
  readonly discovered: number;
  readonly remaining: number;
  readonly status: "running" | "completed";
}

interface Settings {
  max_depth: number;
  max_pages: number;
  max_concurrency: number;
  retry_count: number;
  timeout_ms: number;
  delay_ms: number;
  respect_robots: boolean;
  respect_sitemap: boolean;
  follow_redirects: boolean;
  allow_pdf: boolean;
  allow_images: boolean;
  allow_videos: boolean;
  allow_external: boolean;
  allowed_domains: string[];
  ignored_urls: string[];
  ignored_extensions: string[];
  ignored_patterns: string[];
}

const USER_AGENT = "OSU-AI-Assistant-Crawler/1.0 (+https://osu.edu.et)";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function log(
  supabase: Client,
  entry: {
    website_id: string;
    job_id?: string | null;
    page_id?: string | null;
    step: string;
    level?: string;
    message: string;
    url?: string | null;
    duration_ms?: number | null;
    context?: Record<string, unknown>;
  },
) {
  await supabase.from("crawl_logs").insert({
    website_id: entry.website_id,
    job_id: entry.job_id ?? null,
    page_id: entry.page_id ?? null,
    step: entry.step,
    level: entry.level ?? "info",
    message: entry.message.slice(0, 2000),
    url: entry.url ?? null,
    duration_ms: entry.duration_ms ?? null,
    context: (entry.context ?? {}) as never,
  });
}

/** Security: only http(s), inside allowed domains, no loops, no ignored patterns. */
function isCrawlable(rawUrl: string, baseUrl: string, settings: Settings): boolean {
  let url: URL;
  let base: URL;
  try {
    url = new URL(rawUrl);
    base = new URL(baseUrl);
  } catch {
    return false;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return false;

  const allowedDomains = settings.allowed_domains.length > 0 ? settings.allowed_domains : [base.hostname];
  const insideAllowed = allowedDomains.some(
    (domain) => url.hostname === domain || url.hostname.endsWith(`.${domain}`),
  );
  if (!insideAllowed && !settings.allow_external) return false;

  const extension = url.pathname.split(".").pop()?.toLowerCase() ?? "";
  if (settings.ignored_extensions.includes(extension)) return false;
  if (settings.ignored_urls.some((ignored) => url.toString().startsWith(ignored))) return false;
  if (settings.ignored_patterns.some((pattern) => new RegExp(pattern, "i").test(url.toString()))) return false;
  if (url.pathname.split("/").length > 12) return false; // recursion guard
  return true;
}

const normalizeUrl = (rawUrl: string): string => {
  const url = new URL(rawUrl);
  url.hash = "";
  if (url.pathname.length > 1 && url.pathname.endsWith("/")) url.pathname = url.pathname.slice(0, -1);
  return url.toString();
};

async function enqueue(
  supabase: Client,
  websiteId: string,
  jobId: string,
  urls: readonly { url: string; depth: number; priority?: number; source: string }[],
): Promise<number> {
  if (urls.length === 0) return 0;
  const unique = new Map<string, { url: string; depth: number; priority?: number; source: string }>();
  for (const item of urls) unique.set(item.url, item);
  const candidates = Array.from(unique.values());

  const { data: existing } = await supabase
    .from("crawl_queue")
    .select("url")
    .eq("website_id", websiteId)
    .in("url", candidates.map((item) => item.url));
  const known = new Set((existing ?? []).map((row) => row.url));

  const rows = candidates
    .filter((item) => !known.has(item.url))
    .map((item) => ({
      website_id: websiteId,
      job_id: jobId,
      url: item.url,
      depth: item.depth,
      priority: item.priority ?? Math.max(0, 10 - item.depth),
      source: item.source,
      status: "pending",
    }));
  if (rows.length === 0) return 0;
  const { error } = await supabase.from("crawl_queue").insert(rows);
  return error ? 0 : rows.length;
}

/** Seeds the queue from homepage, robots.txt and sitemap.xml. */
async function seedQueue(supabase: Client, website: { id: string; base_url: string }, settings: Settings, jobId: string) {
  const seeds: { url: string; depth: number; priority: number; source: string }[] = [
    { url: normalizeUrl(website.base_url), depth: 0, priority: 100, source: "homepage" },
  ];

  if (settings.respect_sitemap) {
    const robots = await fetchRobots(website.base_url, settings.timeout_ms);
    const sitemapUrls = robots.sitemaps.length > 0 ? robots.sitemaps : defaultSitemapCandidates(website.base_url);
    const discovered: string[] = [];
    for (const sitemap of sitemapUrls.slice(0, 4)) {
      const urls = await fetchSitemapUrls(sitemap, settings.timeout_ms);
      discovered.push(...urls);
      if (discovered.length > settings.max_pages) break;
    }
    for (const url of discovered.slice(0, settings.max_pages)) {
      try {
        const normalized = normalizeUrl(url);
        if (isCrawlable(normalized, website.base_url, settings)) {
          seeds.push({ url: normalized, depth: 1, priority: 50, source: "sitemap" });
        }
      } catch {
        /* skip invalid sitemap entry */
      }
    }
    await log(supabase, {
      website_id: website.id,
      job_id: jobId,
      step: "discovery",
      message: `Sitemap discovery found ${discovered.length} URL(s)`,
    });
  }

  // No live sitemap (site down or none published): recover the URL inventory
  // from archived snapshots of the same domain.
  if (seeds.length <= 1) {
    const archivedUrls = await fetchArchivedUrls(website.base_url, settings.max_pages);
    for (const url of archivedUrls) {
      try {
        const normalized = normalizeUrl(url);
        if (isCrawlable(normalized, website.base_url, settings)) {
          seeds.push({ url: normalized, depth: 1, priority: 40, source: "archive" });
        }
      } catch {
        /* skip invalid archived entry */
      }
    }
    await log(supabase, {
      website_id: website.id,
      job_id: jobId,
      step: "discovery",
      message: `Archive discovery found ${archivedUrls.length} URL(s)`,
    });
  }



  const inserted = await enqueue(supabase, website.id, jobId, seeds);
  await log(supabase, {
    website_id: website.id,
    job_id: jobId,
    step: "discovery",
    message: `Queued ${inserted} URL(s) for crawling`,
  });
  return inserted;
}

async function embed(texts: readonly string[]): Promise<(number[] | null)[]> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) return texts.map(() => null);
  try {
    const response = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model: "google/gemini-embedding-001", input: texts, dimensions: 768 }),
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) return texts.map(() => null);
    const payload = (await response.json()) as { data?: { embedding: number[] }[] };
    return texts.map((_text, index) => payload.data?.[index]?.embedding ?? null);
  } catch {
    return texts.map(() => null);
  }
}

/** Pushes a changed page into the knowledge base: document row + chunks + embeddings. */
async function syncToKnowledgeBase(
  supabase: Client,
  page: {
    id: string;
    url: string;
    title: string;
    language: string;
    category: string;
    department: string | null;
    clean: string;
    extracted: string;
    documentId: string | null;
    checksum: string;
  },
  userId: string | null,
): Promise<string | null> {
  const documentPayload = {
    title: page.title.slice(0, 300),
    description: `Synchronized from ${page.url}`,
    language: page.language,
    department: page.department,
    source: "website",
    source_url: page.url,
    file_name: `${page.url.replace(/https?:\/\//, "").replace(/[^\w.-]+/g, "-").slice(0, 120)}.html`,
    file_extension: "html",
    file_type: "text/html",
    file_size: page.clean.length,
    checksum: page.checksum,
    raw_text: page.extracted.slice(0, 500_000),
    clean_text: page.clean.slice(0, 500_000),
    status: "active",
    processing_status: "completed",
    embedding_status: "pending",
    training_status: "untrained",
    uploaded_by: userId,
  };

  let documentId = page.documentId;
  if (documentId) {
    await supabase.from("knowledge_documents").update(documentPayload).eq("id", documentId);
  } else {
    const { data } = await supabase.from("knowledge_documents").insert(documentPayload).select("id").maybeSingle();
    documentId = data?.id ?? null;
  }
  if (!documentId) return null;

  await supabase.from("knowledge_chunks").delete().eq("document_id", documentId);

  const chunks = chunkText(page.clean);
  if (chunks.length === 0) return documentId;

  const vectors = await embed(chunks.map((chunk) => chunk.content));
  const rows = chunks.map((chunk, index) => ({
    document_id: documentId,
    chunk_index: chunk.index,
    content: chunk.content,
    token_count: chunk.tokenCount,
    section: chunk.section,
    language: page.language,
    keywords: [],
    embedding: vectors[index] ? JSON.stringify(vectors[index]) : null,
    embedding_model: vectors[index] ? "google/gemini-embedding-001" : null,
    metadata: { source_url: page.url, page_id: page.id } as never,
  }));
  await supabase.from("knowledge_chunks").insert(rows as never);

  const embedded = vectors.filter(Boolean).length;
  await supabase
    .from("knowledge_documents")
    .update({
      chunk_count: chunks.length,
      embedding_status: embedded === chunks.length ? "completed" : embedded > 0 ? "partial" : "pending",
      training_status: embedded > 0 ? "trained" : "untrained",
    })
    .eq("id", documentId);

  return documentId;
}

async function processQueueItem(
  supabase: Client,
  item: { id: string; url: string; depth: number; attempts: number },
  website: { id: string; base_url: string; language: string },
  settings: Settings,
  jobId: string,
  robotsAllowed: (url: string) => boolean,
  userId: string | null,
): Promise<"updated" | "unchanged" | "failed" | "skipped"> {
  const started = Date.now();
  await supabase.from("crawl_queue").update({ status: "running" }).eq("id", item.id);

  if (!robotsAllowed(item.url)) {
    await supabase
      .from("crawl_queue")
      .update({ status: "skipped", processed_at: new Date().toISOString(), error: "Blocked by robots.txt" })
      .eq("id", item.id);
    await log(supabase, {
      website_id: website.id,
      job_id: jobId,
      step: "robots",
      level: "warn",
      message: "Skipped by robots.txt",
      url: item.url,
    });
    return "skipped";
  }

  try {
    let html: string | null = null;
    let httpStatus = 0;
    let fromArchive = false;

    try {
      const response = await fetch(item.url, {
        headers: { "User-Agent": USER_AGENT, Accept: "text/html,application/xhtml+xml" },
        redirect: settings.follow_redirects ? "follow" : "manual",
        signal: AbortSignal.timeout(settings.timeout_ms),
      });
      httpStatus = response.status;
      const contentType = response.headers.get("content-type") ?? "";
      if (response.ok && contentType.includes("html")) html = await response.text();
    } catch {
      httpStatus = 0;
    }

    // The official site is intermittently unavailable — fall back to its own
    // archived snapshot so the knowledge base stays grounded in real content.
    if (html === null) {
      const archived = await fetchArchivedHtml(item.url, settings.timeout_ms + 10_000);
      if (archived) {
        html = archived.html;
        fromArchive = true;
        await log(supabase, {
          website_id: website.id,
          job_id: jobId,
          step: "fetch",
          level: "warn",
          message: `Live fetch failed (HTTP ${httpStatus}) — indexed archived snapshot ${archived.timestamp}`,
          url: item.url,
        });
      }
    }

    if (html === null) {
      await supabase.from("website_pages").upsert(
        {
          website_id: website.id,
          url: item.url,
          status: "broken",
          http_status: httpStatus,
          depth: item.depth,
          error: `Unreachable (HTTP ${httpStatus}) and no archived snapshot`,
          last_crawled_at: new Date().toISOString(),
        },
        { onConflict: "website_id,url" },
      );
      await supabase
        .from("crawl_queue")
        .update({ status: "failed", processed_at: new Date().toISOString(), error: `HTTP ${httpStatus}` })
        .eq("id", item.id);
      await log(supabase, {
        website_id: website.id,
        job_id: jobId,
        step: "fetch",
        level: "error",
        message: `Fetch failed with HTTP ${httpStatus}`,
        url: item.url,
        duration_ms: Date.now() - started,
      });
      return "failed";
    }

    void fromArchive;

    const extracted = extractPage(html, item.url);
    const clean = cleanText(extracted.clean);
    const hash = await sha256(clean);
    const language = detectLanguage(clean, extracted.langAttribute?.slice(0, 2) ?? website.language);
    const pageType = classifyPage(item.url, extracted.title);
    const category = mapCategory(pageType);
    const department = extracted.breadcrumbs[1] ?? null;

    const { data: existing } = await supabase
      .from("website_pages")
      .select("id, content_hash, clean_content, version, document_id, category")
      .eq("website_id", website.id)
      .eq("url", item.url)
      .maybeSingle();

    // Duplicate detection: same content hash under a different URL.
    const { data: duplicate } = await supabase
      .from("website_pages")
      .select("id, url")
      .eq("website_id", website.id)
      .eq("content_hash", hash)
      .neq("url", item.url)
      .maybeSingle();

    const changed = !existing || existing.content_hash !== hash;
    const nextVersion = existing ? (changed ? existing.version + 1 : existing.version) : 1;

    const pageRow = {
      website_id: website.id,
      url: item.url,
      canonical_url: extracted.canonical,
      title: extracted.title.slice(0, 500),
      description: extracted.description,
      language,
      page_type: pageType,
      category: existing?.category ?? category,
      department,
      status: changed ? (existing ? "updated" : "crawled") : "unchanged",
      http_status: httpStatus || 200,
      content_hash: hash,
      raw_html: html.slice(0, 400_000),
      extracted_content: extracted.extracted.slice(0, 400_000),
      clean_content: clean.slice(0, 400_000),
      word_count: extracted.wordCount,
      headings: extracted.headings as never,
      links: extracted.links.slice(0, 300) as never,
      files: extracted.files.slice(0, 200) as never,
      metadata: {
        author: extracted.author,
        publishedAt: extracted.publishedAt,
        updatedAt: extracted.updatedAt,
        breadcrumbs: extracted.breadcrumbs,
        images: extracted.images.slice(0, 50),
        meta: extracted.metadata,
      } as never,
      depth: item.depth,
      version: nextVersion,
      is_duplicate: Boolean(duplicate),
      duplicate_of: duplicate?.id ?? null,
      error: null,
      last_crawled_at: new Date().toISOString(),
      last_modified_at: changed ? new Date().toISOString() : undefined,
    };

    const { data: saved } = await supabase
      .from("website_pages")
      .upsert(pageRow, { onConflict: "website_id,url" })
      .select("id, document_id")
      .maybeSingle();
    const pageId = saved?.id ?? existing?.id ?? null;

    if (pageId && changed) {
      const diff = diffContent(existing?.clean_content ?? "", clean);
      await supabase.from("website_versions").insert({
        page_id: pageId,
        version: nextVersion,
        title: extracted.title.slice(0, 500),
        clean_content: clean.slice(0, 400_000),
        content_hash: hash,
        metadata: { url: item.url, language, pageType } as never,
        diff_summary: {
          ...diff,
          similarity: existing ? Number(similarity(existing.clean_content ?? "", clean).toFixed(3)) : 0,
        } as never,
      });

      if (!duplicate && clean.length > 200) {
        const documentId = await syncToKnowledgeBase(
          supabase,
          {
            id: pageId,
            url: item.url,
            title: extracted.title,
            language,
            category: existing?.category ?? category,
            department,
            clean,
            extracted: extracted.extracted,
            documentId: saved?.document_id ?? existing?.document_id ?? null,
            checksum: hash,
          },
          userId,
        );
        if (documentId) await supabase.from("website_pages").update({ document_id: documentId }).eq("id", pageId);
      }
    }

    // Discover further pages and downloadable files.
    if (item.depth < settings.max_depth) {
      const nextUrls = extracted.links
        .map((link) => {
          try {
            return normalizeUrl(link.url);
          } catch {
            return null;
          }
        })
        .filter((url): url is string => url !== null && isCrawlable(url, website.base_url, settings))
        .slice(0, 120)
        .map((url) => ({ url, depth: item.depth + 1, source: "link" }));
      await enqueue(supabase, website.id, jobId, nextUrls);
    }

    if (settings.allow_pdf && extracted.files.length > 0) {
      await log(supabase, {
        website_id: website.id,
        job_id: jobId,
        page_id: pageId,
        step: "files",
        message: `Discovered ${extracted.files.length} downloadable file(s)`,
        url: item.url,
        context: { files: extracted.files.slice(0, 25) },
      });
    }

    await supabase
      .from("crawl_queue")
      .update({ status: changed ? "completed" : "duplicate", processed_at: new Date().toISOString() })
      .eq("id", item.id);

    await log(supabase, {
      website_id: website.id,
      job_id: jobId,
      page_id: pageId,
      step: "extraction",
      message: changed ? `Indexed ${extracted.wordCount} words` : "Unchanged since last crawl",
      url: item.url,
      duration_ms: Date.now() - started,
    });

    return changed ? "updated" : "unchanged";
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown crawl error";
    const retry = item.attempts + 1 <= settings.retry_count;
    await supabase
      .from("crawl_queue")
      .update({
        status: retry ? "retrying" : "failed",
        attempts: item.attempts + 1,
        error: message,
        processed_at: retry ? null : new Date().toISOString(),
      })
      .eq("id", item.id);
    await log(supabase, {
      website_id: website.id,
      job_id: jobId,
      step: "fetch",
      level: "error",
      message,
      url: item.url,
      duration_ms: Date.now() - started,
    });
    return "failed";
  }
}

export function computeNextCrawl(frequency: string): string | null {
  const now = Date.now();
  const map: Record<string, number> = {
    hourly: 3_600_000,
    daily: 86_400_000,
    weekly: 604_800_000,
    monthly: 2_592_000_000,
  };
  const delta = map[frequency];
  return delta ? new Date(now + delta).toISOString() : null;
}

/** Processes one bounded batch of the crawl queue and returns progress. */
export async function runCrawlBatch(
  supabase: Client,
  options: { jobId: string; batchSize?: number; userId: string | null },
): Promise<BatchResult> {
  const { data: job } = await supabase.from("crawl_jobs").select("*").eq("id", options.jobId).maybeSingle();
  if (!job) throw new Error("Crawl job not found");
  if (job.status === "cancelled") {
    return { jobId: job.id, processed: 0, updated: 0, failed: 0, discovered: 0, remaining: 0, status: "completed" };
  }

  const { data: website } = await supabase.from("websites").select("*").eq("id", job.website_id).maybeSingle();
  if (!website) throw new Error("Website not found");

  const { data: settingsRow } = await supabase
    .from("crawl_settings")
    .select("*")
    .eq("website_id", website.id)
    .maybeSingle();
  if (!settingsRow) throw new Error("Crawl settings missing for this website");
  const settings = settingsRow as unknown as Settings;

  let discovered = 0;
  if (job.status === "pending") {
    await supabase
      .from("crawl_jobs")
      .update({ status: "running", started_at: new Date().toISOString() })
      .eq("id", job.id);
    if (job.mode === "full") {
      await supabase.from("crawl_queue").delete().eq("website_id", website.id).in("status", ["completed", "duplicate"]);
    }
    discovered = await seedQueue(supabase, website, settings, job.id);
  }

  const robots = settings.respect_robots ? await fetchRobots(website.base_url, settings.timeout_ms) : null;
  const robotsAllowed = (url: string) => {
    if (!robots) return true;
    try {
      return isAllowedByRobots(new URL(url).pathname, robots);
    } catch {
      return false;
    }
  };

  const { count: crawledSoFar } = await supabase
    .from("website_pages")
    .select("id", { count: "exact", head: true })
    .eq("website_id", website.id);
  const budget = Math.max(0, settings.max_pages - (crawledSoFar ?? 0));

  const batchSize = Math.min(options.batchSize ?? 12, Math.max(budget, 0));
  const { data: items } = await supabase
    .from("crawl_queue")
    .select("id, url, depth, attempts")
    .eq("website_id", website.id)
    .in("status", ["pending", "retrying"])
    .order("priority", { ascending: false })
    .order("depth", { ascending: true })
    .limit(batchSize);

  let updated = 0;
  let failed = 0;
  let processed = 0;

  const queue = items ?? [];
  const concurrency = Math.max(1, Math.min(settings.max_concurrency, 4));
  for (let index = 0; index < queue.length; index += concurrency) {
    const slice = queue.slice(index, index + concurrency);
    const results = await Promise.all(
      slice.map((item) =>
        processQueueItem(supabase, item, website, settings, job.id, robotsAllowed, options.userId),
      ),
    );
    for (const result of results) {
      processed += 1;
      if (result === "updated") updated += 1;
      if (result === "failed") failed += 1;
    }
    if (settings.delay_ms > 0 && index + concurrency < queue.length) await sleep(settings.delay_ms);
  }

  const { count: remaining } = await supabase
    .from("crawl_queue")
    .select("id", { count: "exact", head: true })
    .eq("website_id", website.id)
    .in("status", ["pending", "retrying"]);

  const { count: totalPages } = await supabase
    .from("website_pages")
    .select("id", { count: "exact", head: true })
    .eq("website_id", website.id)
    .is("deleted_at", null);

  const done = (remaining ?? 0) === 0 || budget - processed <= 0;
  const startedAt = job.started_at ? new Date(job.started_at).getTime() : Date.now();

  await supabase
    .from("crawl_jobs")
    .update({
      status: done ? "completed" : "running",
      pages_discovered: job.pages_discovered + discovered,
      pages_crawled: job.pages_crawled + processed,
      pages_updated: job.pages_updated + updated,
      pages_failed: job.pages_failed + failed,
      finished_at: done ? new Date().toISOString() : null,
      duration_ms: done ? Date.now() - startedAt : null,
    })
    .eq("id", job.id);

  await supabase
    .from("websites")
    .update({
      total_pages: totalPages ?? 0,
      last_crawl_at: new Date().toISOString(),
      next_crawl_at: computeNextCrawl(website.frequency),
    })
    .eq("id", website.id);

  if (done) {
    await log(supabase, {
      website_id: website.id,
      job_id: job.id,
      step: "sync",
      message: `Crawl completed — ${totalPages ?? 0} page(s) indexed`,
    });
  }

  return {
    jobId: job.id,
    processed,
    updated,
    failed,
    discovered,
    remaining: remaining ?? 0,
    status: done ? "completed" : "running",
  };
}

/** Fetches a single URL and reports reachability without storing anything. */
export async function testUrl(url: string, timeoutMs = 15_000) {
  const started = Date.now();
  try {
    const response = await fetch(url, {
      headers: { "User-Agent": USER_AGENT },
      signal: AbortSignal.timeout(timeoutMs),
    });
    const html = await response.text();
    const extracted = extractPage(html, url);
    return {
      ok: response.ok,
      httpStatus: response.status,
      durationMs: Date.now() - started,
      title: extracted.title,
      wordCount: extracted.wordCount,
      links: extracted.links.length,
      files: extracted.files.length,
      language: detectLanguage(extracted.clean),
      pageType: classifyPage(url, extracted.title),
      preview: extracted.clean.slice(0, 1200),
      error: null as string | null,
    };
  } catch (error) {
    return {
      ok: false,
      httpStatus: 0,
      durationMs: Date.now() - started,
      title: "",
      wordCount: 0,
      links: 0,
      files: 0,
      language: "en",
      pageType: "general" as const,
      preview: "",
      error: error instanceof Error ? error.message : "Request failed",
    };
  }
}
