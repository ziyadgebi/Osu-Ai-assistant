/** Deterministic text chunking for RAG (server-only, no dependencies). */

export interface ChunkOptions {
  readonly size: number;
  readonly overlap: number;
  readonly minLength: number;
  readonly maxLength: number;
  readonly strategy: "paragraph" | "sentence" | "heading";
}

export const DEFAULT_CHUNK_OPTIONS: ChunkOptions = {
  size: 1000,
  overlap: 150,
  minLength: 120,
  maxLength: 2000,
  strategy: "paragraph",
};

export interface TextChunk {
  readonly index: number;
  readonly content: string;
  readonly tokenCount: number;
  readonly section: string | null;
}

const estimateTokens = (text: string): number => Math.max(1, Math.round(text.length / 4));

function split(text: string, strategy: ChunkOptions["strategy"]): string[] {
  if (strategy === "sentence") return text.split(/(?<=[.!?])\s+/).filter(Boolean);
  if (strategy === "heading") return text.split(/\n(?=#{1,6}\s)/).filter(Boolean);
  return text.split(/\n{2,}/).filter(Boolean);
}

export function chunkText(text: string, options: Partial<ChunkOptions> = {}): TextChunk[] {
  const config = { ...DEFAULT_CHUNK_OPTIONS, ...options };
  const units = split(text.trim(), config.strategy);
  const chunks: TextChunk[] = [];

  let buffer = "";
  let section: string | null = null;

  const flush = () => {
    const content = buffer.trim();
    buffer = "";
    if (content.length < config.minLength && chunks.length > 0) {
      const last = chunks[chunks.length - 1];
      chunks[chunks.length - 1] = {
        ...last,
        content: `${last.content}\n\n${content}`.slice(0, config.maxLength),
        tokenCount: estimateTokens(`${last.content}\n\n${content}`),
      };
      return;
    }
    if (content.length === 0) return;
    chunks.push({
      index: chunks.length,
      content: content.slice(0, config.maxLength),
      tokenCount: estimateTokens(content),
      section,
    });
  };

  for (const unit of units) {
    const headingMatch = unit.match(/^#{1,6}\s+(.*)$/m);
    if (headingMatch) section = headingMatch[1].trim();

    if (buffer.length + unit.length + 2 > config.size && buffer.length > 0) {
      const tail = buffer.slice(-config.overlap);
      flush();
      buffer = `${tail}\n\n${unit}`;
    } else {
      buffer = buffer.length > 0 ? `${buffer}\n\n${unit}` : unit;
    }
  }
  flush();

  return chunks.map((chunk, index) => ({ ...chunk, index }));
}
