/** Website crawling & synchronization domain types. */

import type { ISODateString, UUID } from "@/types/common.types";

export type WebsiteStatus = "active" | "paused" | "disabled";
export type CrawlFrequency = "manual" | "hourly" | "daily" | "weekly" | "monthly" | "custom";
export type CrawlMode =
  | "manual"
  | "full"
  | "incremental"
  | "scheduled"
  | "single-page"
  | "category"
  | "priority"
  | "emergency";
export type JobStatus = "pending" | "running" | "completed" | "failed" | "cancelled";
export type QueueStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "retrying"
  | "cancelled"
  | "skipped"
  | "duplicate";
export type PageStatus = "discovered" | "crawled" | "updated" | "unchanged" | "failed" | "broken" | "duplicate";
export type PageType =
  | "home"
  | "department"
  | "admission"
  | "registrar"
  | "library"
  | "scholarship"
  | "research"
  | "staff"
  | "news"
  | "announcement"
  | "event"
  | "policy"
  | "contact"
  | "downloads"
  | "academic-calendar"
  | "general";

export const PAGE_TYPES: readonly PageType[] = [
  "home",
  "department",
  "admission",
  "registrar",
  "library",
  "scholarship",
  "research",
  "staff",
  "news",
  "announcement",
  "event",
  "policy",
  "contact",
  "downloads",
  "academic-calendar",
  "general",
];

export const KNOWLEDGE_CATEGORIES: readonly string[] = [
  "Admissions",
  "Programs",
  "Scholarships",
  "Registrar",
  "Policies",
  "Departments",
  "News",
  "Events",
  "Research",
  "Library",
  "Student Services",
  "Campus",
  "Administration",
  "General",
];

export interface Website {
  readonly id: UUID;
  readonly name: string;
  readonly base_url: string;
  readonly logo_url: string | null;
  readonly description: string | null;
  readonly status: WebsiteStatus;
  readonly language: string;
  readonly owner_id: UUID | null;
  readonly frequency: CrawlFrequency;
  readonly cron_expression: string | null;
  readonly last_crawl_at: ISODateString | null;
  readonly next_crawl_at: ISODateString | null;
  readonly total_pages: number;
  readonly created_at: ISODateString;
  readonly updated_at: ISODateString;
  readonly deleted_at: ISODateString | null;
}

export interface CrawlSettings {
  readonly id: UUID;
  readonly website_id: UUID;
  readonly max_depth: number;
  readonly max_pages: number;
  readonly max_concurrency: number;
  readonly retry_count: number;
  readonly timeout_ms: number;
  readonly delay_ms: number;
  readonly respect_robots: boolean;
  readonly respect_sitemap: boolean;
  readonly follow_redirects: boolean;
  readonly allow_pdf: boolean;
  readonly allow_images: boolean;
  readonly allow_videos: boolean;
  readonly allow_external: boolean;
  readonly allowed_domains: string[];
  readonly ignored_urls: string[];
  readonly ignored_extensions: string[];
  readonly ignored_patterns: string[];
}

export interface DiscoveredFile {
  readonly url: string;
  readonly kind: string;
  readonly label: string;
}

export interface WebsitePage {
  readonly id: UUID;
  readonly website_id: UUID;
  readonly url: string;
  readonly canonical_url: string | null;
  readonly title: string | null;
  readonly description: string | null;
  readonly language: string | null;
  readonly page_type: PageType;
  readonly category: string | null;
  readonly department: string | null;
  readonly status: PageStatus;
  readonly http_status: number | null;
  readonly content_hash: string | null;
  readonly raw_html: string | null;
  readonly extracted_content: string | null;
  readonly clean_content: string | null;
  readonly word_count: number;
  readonly headings: unknown;
  readonly links: unknown;
  readonly files: unknown;
  readonly metadata: Record<string, unknown>;
  readonly depth: number;
  readonly version: number;
  readonly is_duplicate: boolean;
  readonly duplicate_of: UUID | null;
  readonly error: string | null;
  readonly document_id: UUID | null;
  readonly last_crawled_at: ISODateString | null;
  readonly last_modified_at: ISODateString | null;
  readonly created_at: ISODateString;
  readonly updated_at: ISODateString;
  readonly deleted_at: ISODateString | null;
}

export interface WebsiteVersion {
  readonly id: UUID;
  readonly page_id: UUID;
  readonly version: number;
  readonly title: string | null;
  readonly clean_content: string | null;
  readonly content_hash: string | null;
  readonly metadata: Record<string, unknown>;
  readonly diff_summary: Record<string, unknown>;
  readonly created_at: ISODateString;
}

export interface CrawlJob {
  readonly id: UUID;
  readonly website_id: UUID;
  readonly mode: CrawlMode;
  readonly status: JobStatus;
  readonly pages_discovered: number;
  readonly pages_crawled: number;
  readonly pages_updated: number;
  readonly pages_failed: number;
  readonly pages_skipped: number;
  readonly files_found: number;
  readonly error: string | null;
  readonly started_at: ISODateString | null;
  readonly finished_at: ISODateString | null;
  readonly duration_ms: number | null;
  readonly created_at: ISODateString;
}

export interface CrawlQueueItem {
  readonly id: UUID;
  readonly website_id: UUID;
  readonly job_id: UUID | null;
  readonly url: string;
  readonly depth: number;
  readonly priority: number;
  readonly status: QueueStatus;
  readonly attempts: number;
  readonly error: string | null;
  readonly source: string;
  readonly processed_at: ISODateString | null;
  readonly created_at: ISODateString;
}

export interface CrawlLog {
  readonly id: UUID;
  readonly website_id: UUID | null;
  readonly job_id: UUID | null;
  readonly page_id: UUID | null;
  readonly step: string;
  readonly level: string;
  readonly message: string;
  readonly url: string | null;
  readonly duration_ms: number | null;
  readonly context: Record<string, unknown>;
  readonly created_at: ISODateString;
}

export interface WebsiteDashboardStats {
  readonly totalWebsites: number;
  readonly indexedPages: number;
  readonly crawledToday: number;
  readonly updatedPages: number;
  readonly failedPages: number;
  readonly pendingQueue: number;
  readonly storageBytes: number;
  readonly averageCrawlMs: number;
  readonly duplicatePages: number;
  readonly brokenPages: number;
}
