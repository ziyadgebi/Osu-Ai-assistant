/** AdminService — platform settings, provider toggles and moderation actions. */

import { notImplemented, type Result } from "@/types/common.types";
import type { AIProviderConfig, PlatformSetting, UserRoleRecord } from "@/types/domain.types";

export const adminService = {
  async getSettings(): Promise<Result<readonly PlatformSetting[]>> {
    return notImplemented("AdminService.getSettings");
  },
  async updateSetting(_key: string, _value: string): Promise<Result<void>> {
    return notImplemented("AdminService.updateSetting");
  },
  async updateProvider(_config: AIProviderConfig): Promise<Result<void>> {
    return notImplemented("AdminService.updateProvider");
  },
  async assignRole(_record: Omit<UserRoleRecord, "id" | "grantedAt">): Promise<Result<void>> {
    return notImplemented("AdminService.assignRole");
  },
};
