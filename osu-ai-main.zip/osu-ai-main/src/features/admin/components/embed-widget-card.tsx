/** Shows the copy-paste snippet used to embed the assistant on any website. */

import { useEffect, useState } from "react";
import { Check, Code2, Copy } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function EmbedWidgetCard() {
  const [origin, setOrigin] = useState("https://osu-ai.lovable.app");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") setOrigin(window.location.origin);
  }, []);

  const snippet = `<script src="${origin}/widget.js" data-title="Ask OSU AI" data-position="right" defer></script>`;

  return (
    <Card>
      <CardHeader>
        <span className="mb-2 grid size-10 place-items-center rounded-xl bg-primary/10 text-primary">
          <Code2 className="size-5" aria-hidden />
        </span>
        <CardTitle className="text-base">Embed on your website</CardTitle>
        <CardDescription>
          Paste this before <code>&lt;/body&gt;</code> on osu.edu.et. It adds a floating button that opens the
          assistant in a panel.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <pre className="overflow-x-auto rounded-md bg-muted p-3 text-xs">
          <code>{snippet}</code>
        </pre>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            void navigator.clipboard.writeText(snippet);
            setCopied(true);
            window.setTimeout(() => setCopied(false), 2000);
          }}
        >
          {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
          {copied ? "Copied" : "Copy snippet"}
        </Button>
        <p className="text-xs text-muted-foreground">
          Options: <code>data-title</code> (button label), <code>data-color</code> (hex), <code>data-position</code>{" "}
          (left or right). The panel loads <code>{origin}/embed</code>.
        </p>
      </CardContent>
    </Card>
  );
}
