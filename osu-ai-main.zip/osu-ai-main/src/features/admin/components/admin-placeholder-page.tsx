/** Shared admin page scaffold so every console screen stays consistent. */

import type { LucideIcon } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { PlaceholderPanel, type PlaceholderPanelProps } from "@/components/common/placeholder-panel";

export interface AdminPlaceholderPageProps {
  readonly title: string;
  readonly description: string;
  readonly icon: LucideIcon;
  readonly panels: readonly PlaceholderPanelProps[];
}

export function AdminPlaceholderPage({ title, description, panels }: AdminPlaceholderPageProps) {
  return (
    <>
      <PageHeader eyebrow="Admin" title={title} description={description} />
      <div className="grid gap-4 lg:grid-cols-2">
        {panels.map((panel) => (
          <PlaceholderPanel key={panel.title} {...panel} />
        ))}
      </div>
    </>
  );
}
