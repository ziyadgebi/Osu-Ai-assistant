/** ConversationService — conversation & message persistence (client side, RLS scoped). */

import { supabase } from "@/integrations/supabase/client";
import { fail, ok, type Result } from "@/types/common.types";
import type { Citation, Conversation, Message, MessageRole } from "@/types/domain.types";
import type { LanguageCode } from "@/types/i18n.types";

type ConversationRow = {
  id: string;
  user_id: string | null;
  title: string;
  language: string;
  message_count: number;
  created_at: string;
  updated_at: string;
};

type MessageRow = {
  id: string;
  conversation_id: string;
  role: string;
  content: string;
  citations: unknown;
  prompt_tokens: number | null;
  completion_tokens: number | null;
  confidence: number | null;
  created_at: string;
};

const toConversation = (row: ConversationRow): Conversation => ({
  id: row.id,
  userId: row.user_id,
  title: row.title,
  language: row.language as LanguageCode,
  messageCount: row.message_count,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

const toMessage = (row: MessageRow): Message => ({
  id: row.id,
  conversationId: row.conversation_id,
  role: row.role as MessageRole,
  content: row.content,
  citations: (Array.isArray(row.citations) ? row.citations : []) as readonly Citation[],
  tokensUsed: (row.prompt_tokens ?? 0) + (row.completion_tokens ?? 0) || null,
  createdAt: row.created_at,
});

export interface ConversationSummary extends Conversation {
  readonly isPinned: boolean;
  readonly isArchived: boolean;
}

export const conversationService = {
  async list(): Promise<Result<readonly ConversationSummary[]>> {
    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .is("deleted_at", null)
      .order("updated_at", { ascending: false })
      .limit(50);
    if (error) return fail("CONVERSATIONS_LIST_FAILED", error.message);
    return ok(
      (data ?? []).map((row) => ({
        ...toConversation(row as ConversationRow),
        isPinned: row.is_pinned,
        isArchived: row.is_archived,
      })),
    );
  },

  async create(title: string, language: LanguageCode = "en"): Promise<Result<Conversation>> {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return fail("UNAUTHENTICATED", "Sign in to save conversations.");
    const { data, error } = await supabase
      .from("conversations")
      .insert({ title: title.slice(0, 80) || "New conversation", language, user_id: auth.user.id })
      .select("*")
      .single();
    if (error) return fail("CONVERSATION_CREATE_FAILED", error.message);
    return ok(toConversation(data as ConversationRow));
  },

  async rename(id: string, title: string): Promise<Result<void>> {
    const { error } = await supabase.from("conversations").update({ title: title.slice(0, 80) }).eq("id", id);
    return error ? fail("CONVERSATION_RENAME_FAILED", error.message) : ok(undefined);
  },

  async remove(id: string): Promise<Result<void>> {
    const { error } = await supabase.from("conversations").update({ deleted_at: new Date().toISOString() }).eq("id", id);
    return error ? fail("CONVERSATION_DELETE_FAILED", error.message) : ok(undefined);
  },

  async messages(conversationId: string): Promise<Result<readonly Message[]>> {
    const { data, error } = await supabase
      .from("conversation_messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });
    if (error) return fail("MESSAGES_LOAD_FAILED", error.message);
    return ok((data ?? []).map((row) => toMessage(row as MessageRow)));
  },
};
