import { useState } from "react";
import { ChevronDown, ExternalLink, FileText, BookOpen } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Muted } from "@/components/ui/typography";
import { cn } from "@/lib/utils";
import type { Citation } from "@/types/domain.types";

interface CitationListProps {
  readonly citations: readonly Citation[];
  readonly confidence?: number;
  /** Original source numbers, so filtered lists still match the [n] markers in the answer. */
  readonly numbers?: readonly number[];
}

/** Sources are hidden behind a toggle so the answer stays the focus. */
export function CitationList({ citations, confidence, numbers }: CitationListProps) {
  const [open, setOpen] = useState(false);
  if (citations.length === 0) return null;

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
          className="gap-1.5"
        >
          <BookOpen className="size-3.5" aria-hidden />
          Sources ({citations.length})
          <ChevronDown className={cn("size-3.5 transition-transform", open && "rotate-180")} aria-hidden />
        </Button>
        {typeof confidence === "number" ? (
          <Badge variant={confidence >= 0.6 ? "default" : "secondary"}>
            Confidence {Math.round(confidence * 100)}%
          </Badge>
        ) : null}
      </div>

      {open ? (
        <ol className="space-y-2 rounded-xl border border-dashed p-3">
          {citations.map((citation, index) => (
            <li key={`${citation.sourceId}-${index}`} className="rounded-lg border bg-card/60 p-3 text-sm">
              <div className="flex items-start gap-2">
                <span className="mt-0.5 text-xs font-semibold text-primary">[{numbers?.[index] ?? index + 1}]</span>

                <div className="min-w-0 flex-1 space-y-1">
                  <p className="flex items-center gap-1.5 font-medium">
                    <FileText className="size-3.5 shrink-0 text-muted-foreground" aria-hidden />
                    <span className="truncate">{citation.title}</span>
                  </p>
                  <Muted className="line-clamp-2">{citation.snippet}</Muted>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    {citation.page ? <span>Page {citation.page}</span> : null}
                    <span>Score {citation.score.toFixed(2)}</span>
                    {citation.url ? (
                      <a
                        className="inline-flex items-center gap-1 text-primary hover:underline"
                        href={citation.url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Open source <ExternalLink className="size-3" aria-hidden />
                      </a>
                    ) : null}
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ol>
      ) : null}
    </div>
  );
}
