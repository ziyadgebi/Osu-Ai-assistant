import { Bot, UserRound } from "lucide-react";

import { cn } from "@/lib/utils";

interface MessageBubbleProps {
  readonly role: "user" | "assistant" | "system";
  readonly content: string;
  readonly pending?: boolean;
}

/** Renders a single chat turn. Citation markers [1] are highlighted inline. */
export function MessageBubble({ role, content, pending }: MessageBubbleProps) {
  const isUser = role === "user";

  return (
    <div className={cn("flex gap-3", isUser && "flex-row-reverse")}>
      <span
        className={cn(
          "grid size-8 shrink-0 place-items-center rounded-xl",
          isUser ? "bg-secondary text-secondary-foreground" : "bg-primary/10 text-primary",
        )}
        aria-hidden
      >
        {isUser ? <UserRound className="size-4" /> : <Bot className="size-4" />}
      </span>
      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap",
          isUser ? "bg-secondary text-secondary-foreground" : "border bg-card",
        )}
      >
        {content ? renderWithMarkers(content) : pending ? <TypingDots /> : null}
      </div>
    </div>
  );
}

function renderWithMarkers(content: string) {
  return content.split(/(\[\d{1,2}\])/g).map((part, index) =>
    /^\[\d{1,2}\]$/.test(part) ? (
      <sup key={index} className="mx-0.5 font-semibold text-primary">
        {part}
      </sup>
    ) : (
      <span key={index}>{part}</span>
    ),
  );
}

function TypingDots() {
  return (
    <span className="flex items-center gap-1" aria-label="Assistant is typing">
      {[0, 150, 300].map((delay) => (
        <span
          key={delay}
          className="size-1.5 animate-bounce rounded-full bg-muted-foreground/60"
          style={{ animationDelay: `${delay}ms` }}
        />
      ))}
    </span>
  );
}
