/** Standalone chat surface designed to be embedded in an iframe by /widget.js. */

import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageBubble } from "@/features/chat/components/message-bubble";
import { CitationList } from "@/features/chat/components/citation-list";
import type { Citation } from "@/types/domain.types";

export const Route = createFileRoute("/embed")({
  head: () => ({
    meta: [
      { title: "OSU Assistant Widget" },
      { name: "description", content: "Embeddable Oromia State University AI assistant widget." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "OSU Assistant Widget" },
      { property: "og:description", content: "Embeddable Oromia State University AI assistant widget." },
    ],
  }),
  component: EmbedPage,
});

interface CitationPayload {
  readonly citations: readonly Citation[];
  readonly confidence: number;
  readonly conversationId: string | null;
}

function usedCitationNumbers(text: string): number[] {
  const found = new Set<number>();
  for (const match of text.matchAll(/\[(\d{1,2})\]/g)) {
    const value = Number(match[1]);
    if (value > 0) found.add(value);
  }
  return [...found].sort((a, b) => a - b);
}

function EmbedPage() {
  const [input, setInput] = useState("");
  const conversationId = useRef<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const composer = useRef<HTMLTextAreaElement>(null);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        prepareSendMessagesRequest: async ({ messages, body }) => ({
          body: { ...body, messages, conversationId: conversationId.current },
        }),
      }),
    [],
  );

  const { messages, sendMessage, status } = useChat({ transport });
  const isBusy = status === "submitted" || status === "streaming";

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, status]);

  useEffect(() => {
    if (!isBusy) composer.current?.focus();
  }, [isBusy]);

  const send = (text: string) => {
    const value = text.trim();
    if (!value || isBusy) return;
    setInput("");
    void sendMessage({ text: value });
  };

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="border-b border-border bg-gradient-hero px-4 py-3 text-primary-foreground">
        <p className="text-sm font-semibold">OSU AI Assistant</p>
        <p className="text-xs text-primary-foreground/80">Cited answers from official university sources</p>
      </header>

      <div className="flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 ? (
          <p className="mt-10 text-center text-sm text-muted-foreground">
            Ask about admissions, programs, policies or research.
          </p>
        ) : (
          messages.map((message) => {
            const text = message.parts.map((part) => (part.type === "text" ? part.text : "")).join("");
            const meta = message.parts.find((part) => part.type === "data-citations") as
              | { data?: CitationPayload }
              | undefined;
            if (meta?.data?.conversationId) conversationId.current = meta.data.conversationId;

            const cited = usedCitationNumbers(text)
              .map((number) => ({ number, citation: meta?.data?.citations[number - 1] }))
              .filter((entry): entry is { number: number; citation: Citation } => Boolean(entry.citation));

            return (
              <div key={message.id} className="space-y-2">
                <MessageBubble
                  role={message.role === "user" ? "user" : "assistant"}
                  content={text}
                  pending={isBusy}
                />
                {message.role === "assistant" && meta?.data && cited.length > 0 ? (
                  <CitationList
                    citations={cited.map((entry) => entry.citation)}
                    numbers={cited.map((entry) => entry.number)}
                    confidence={meta.data.confidence}
                  />
                ) : null}
              </div>
            );
          })
        )}
        <div ref={bottom} />
      </div>

      <form
        className="flex items-end gap-2 border-t border-border p-3"
        onSubmit={(event) => {
          event.preventDefault();
          send(input);
        }}
      >
        <Textarea
          ref={composer}
          value={input}
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              send(input);
            }
          }}
          rows={1}
          placeholder="Type your question…"
          className="max-h-32 min-h-10 resize-none"
        />
        <Button type="submit" size="icon" disabled={isBusy || input.trim().length === 0} aria-label="Send">
          <Send className="size-4" aria-hidden />
        </Button>
      </form>
    </div>
  );
}
