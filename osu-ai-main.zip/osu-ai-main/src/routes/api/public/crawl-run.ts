/**
 * Admin/cron crawl runner.
 * POST with an administrator bearer token (or the cron secret) to advance a crawl
 * of the official university website in bounded batches.
 */

import { createFileRoute } from "@tanstack/react-router";

interface Body {
  websiteId?: string;
  jobId?: string;
  mode?: "manual" | "full" | "incremental";
  batches?: number;
  batchSize?: number;
}

const json = (payload: unknown, status = 200) =>
  new Response(JSON.stringify(payload), { status, headers: { "Content-Type": "application/json" } });

export const Route = createFileRoute("/api/public/crawl-run")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Caller must be an administrator, or present the cron secret.
        const cronSecret = process.env["CRAWL_CRON_SECRET"];
        const presented = request.headers.get("x-cron-secret");
        let userId: string | null = null;
        let authorized = Boolean(cronSecret && presented && presented === cronSecret);

        if (!authorized) {
          const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? null;
          if (!token) return json({ error: "Unauthorized" }, 401);
          const { data } = await supabaseAdmin.auth.getUser(token);
          userId = data.user?.id ?? null;
          if (!userId) return json({ error: "Unauthorized" }, 401);
          const { data: isAdmin } = await supabaseAdmin.rpc("is_admin", { _user_id: userId });
          if (!isAdmin) return json({ error: "Forbidden" }, 403);
          authorized = true;
        }

        const body = (await request.json().catch(() => ({}))) as Body;

        let websiteId = body.websiteId ?? null;
        if (!websiteId) {
          const { data } = await supabaseAdmin
            .from("websites")
            .select("id")
            .eq("status", "active")
            .order("created_at", { ascending: true })
            .limit(1)
            .maybeSingle();
          websiteId = data?.id ?? null;
        }
        if (!websiteId) return json({ error: "No website configured" }, 400);

        let jobId = body.jobId ?? null;
        if (!jobId) {
          const { data: running } = await supabaseAdmin
            .from("crawl_jobs")
            .select("id")
            .eq("website_id", websiteId)
            .in("status", ["pending", "running"])
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();
          if (running) jobId = running.id;
          else {
            const { data: created, error } = await supabaseAdmin
              .from("crawl_jobs")
              .insert({ website_id: websiteId, mode: body.mode ?? "manual", status: "pending", created_by: userId })
              .select("id")
              .single();
            if (error || !created) return json({ error: error?.message ?? "Could not create job" }, 500);
            jobId = created.id;
          }
        }

        const { runCrawlBatch } = await import("@/features/website-sync/lib/crawler.server");
        const batches = Math.min(Math.max(body.batches ?? 1, 1), 10);
        let last = null as Awaited<ReturnType<typeof runCrawlBatch>> | null;
        for (let index = 0; index < batches; index += 1) {
          last = await runCrawlBatch(supabaseAdmin, { jobId, batchSize: body.batchSize, userId });
          if (last.status === "completed") break;
        }

        return json({ jobId, result: last });
      },
    },
  },
});
