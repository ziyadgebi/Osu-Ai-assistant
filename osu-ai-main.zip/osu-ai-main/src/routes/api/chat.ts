/**
 * Streaming RAG endpoint.
 * Pipeline: sanitise → injection scan → language detect → query rewrite →
 * hybrid retrieval → grounded generation → citations → persistence → telemetry.
 */

import { createFileRoute } from "@tanstack/react-router";
import {
  convertToModelMessages,
  createUIMessageStream,
  createUIMessageStreamResponse,
  streamText,
  type UIMessage,
} from "ai";

import { createLovableAiGatewayProvider, getLovableApiKey } from "@/lib/ai-gateway.server";
import { detectLanguage } from "@/features/ai/lib/language";
import { buildSystemPrompt, blockedMessages } from "@/features/ai/lib/prompts.server";
import { detectPromptInjection, sanitizeUserInput } from "@/features/ai/lib/security.server";
import {
  buildContextBlock,
  hybridRetrieve,
  scoreConfidence,
  toCitations,
} from "@/features/ai/lib/retrieval.server";
import {
  rewriteQuery,
  suggestFollowUps,
  summarizeMemory,
  translateQueryVariants,
} from "@/features/ai/lib/query-rewrite.server";
import type { LanguageCode } from "@/types/i18n.types";

interface ChatBody {
  readonly messages?: UIMessage[];
  readonly conversationId?: string | null;
  readonly language?: LanguageCode | null;
}

function textOf(message: UIMessage): string {
  return message.parts
    .map((part) => (part.type === "text" ? part.text : ""))
    .join(" ")
    .trim();
}

function textStream(message: string) {
  return createUIMessageStreamResponse({
    stream: createUIMessageStream({
      execute: async ({ writer }) => {
        writer.write({ type: "text-start", id: "0" });
        writer.write({ type: "text-delta", id: "0", delta: message });
        writer.write({ type: "text-end", id: "0" });
      },
    }),
  });
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const startedAt = Date.now();
        const body = (await request.json()) as ChatBody;
        const messages = body.messages ?? [];
        if (!Array.isArray(messages) || messages.length === 0) {
          return new Response("Messages are required", { status: 400 });
        }

        let apiKey: string;
        try {
          apiKey = getLovableApiKey();
        } catch {
          return new Response("AI is not configured", { status: 500 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Identify the caller (optional — guests may chat without persistence).
        const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? null;
        let userId: string | null = null;
        if (token) {
          const { data } = await supabaseAdmin.auth.getUser(token);
          userId = data.user?.id ?? null;
        }

        const lastUser = [...messages].reverse().find((message) => message.role === "user");
        const rawQuestion = lastUser ? textOf(lastUser) : "";
        const question = sanitizeUserInput(rawQuestion);
        if (!question) return new Response("Empty question", { status: 400 });

        const language = (body.language ?? detectLanguage(question)) as LanguageCode;

        const injection = detectPromptInjection(question);
        if (injection.flagged) {
          console.warn("[chat] prompt injection blocked", injection.matched);
          return textStream(blockedMessages[language]);
        }

        // Platform AI settings (single row).
        const { data: settingsRow } = await supabaseAdmin.from("ai_settings").select("*").maybeSingle();
        const settings = {
          chatModel: settingsRow?.chat_model || "google/gemini-2.5-flash",
          temperature: Number(settingsRow?.temperature ?? 0.2),
          maxTokens: settingsRow?.max_tokens ?? 1200,
          topK: settingsRow?.top_k ?? 8,
          minScore: Number(settingsRow?.min_score ?? 0.35),
          rewrite: settingsRow?.enable_query_rewrite ?? true,
          hybrid: settingsRow?.enable_hybrid_search ?? true,
          refuse: settingsRow?.refuse_without_sources ?? true,
          systemPrompt: settingsRow?.system_prompt ?? null,
          providerId: settingsRow?.active_provider ?? "gemini",
        };

        const history = messages
          .slice(0, -1)
          .filter((message) => message.role === "user" || message.role === "assistant")
          .map((message) => ({ role: message.role as "user" | "assistant", content: textOf(message) }))
          .filter((turn) => turn.content.length > 0);

        const searchQuery = settings.rewrite ? await rewriteQuery(question, history) : question;

        // Cross-language retrieval: the answer may only exist in one language.
        const variants = await translateQueryVariants(searchQuery);
        const results = await Promise.all(
          variants.map((variant) =>
            hybridRetrieve(supabaseAdmin, {
              query: variant,
              topK: settings.topK,
              minScore: settings.minScore,
              hybrid: settings.hybrid,
            }),
          ),
        );

        const bestById = new Map<string, (typeof results)[number]["chunks"][number]>();
        for (const result of results) {
          for (const chunk of result.chunks) {
            const existing = bestById.get(chunk.id);
            if (!existing || chunk.score > existing.score) bestById.set(chunk.id, chunk);
          }
        }
        const retrieval = {
          chunks: Array.from(bestById.values())
            .sort((a, b) => b.score - a.score)
            .slice(0, settings.topK),
          vectorCount: results.reduce((sum, result) => sum + result.vectorCount, 0),
          keywordCount: results.reduce((sum, result) => sum + result.keywordCount, 0),
          durationMs: Math.max(...results.map((result) => result.durationMs), 0),
          embeddingFailed: results.every((result) => result.embeddingFailed),
        };

        const citations = toCitations(retrieval.chunks);
        const confidence = scoreConfidence(retrieval.chunks);

        // Conversation memory (long-term summary for signed-in users).
        let conversationId = body.conversationId ?? null;
        let memorySummary: string | null = null;
        if (userId && conversationId) {
          const { data: conversation } = await supabaseAdmin
            .from("conversations")
            .select("id, user_id, memory_summary")
            .eq("id", conversationId)
            .maybeSingle();
          if (!conversation || conversation.user_id !== userId) conversationId = null;
          else memorySummary = conversation.memory_summary;
        }
        if (userId && !conversationId) {
          const { data: created } = await supabaseAdmin
            .from("conversations")
            .insert({
              user_id: userId,
              title: question.slice(0, 80),
              language,
              provider_id: settings.providerId,
              model: settings.chatModel,
            })
            .select("id")
            .single();
          conversationId = created?.id ?? null;
        }

        const gateway = createLovableAiGatewayProvider(apiKey);
        const system = buildSystemPrompt({
          language,
          hasSources: retrieval.chunks.length > 0,
          refuseWithoutSources: settings.refuse,
          memorySummary,
          basePrompt: settings.systemPrompt,
        });

        const modelMessages = await convertToModelMessages(messages);
        const systemWithContext = `${system}\n\n${buildContextBlock(retrieval.chunks)}`;

        const stream = createUIMessageStream({
          execute: async ({ writer }) => {
            writer.write({
              type: "data-citations",
              id: "citations",
              data: {
                citations,
                confidence,
                language,
                searchQuery,
                model: settings.chatModel,
                providerId: settings.providerId,
                retrieval: {
                  vectorCount: retrieval.vectorCount,
                  keywordCount: retrieval.keywordCount,
                  durationMs: retrieval.durationMs,
                  embeddingFailed: retrieval.embeddingFailed,
                },
                conversationId,
              },
            });

            const result = streamText({
              model: gateway(settings.chatModel),
              instructions: systemWithContext,
              messages: modelMessages,
              temperature: settings.temperature,
              maxOutputTokens: settings.maxTokens,
            });

            writer.merge(result.toUIMessageStream({
              sendStart: false,
              onError: (streamError) => {
                console.error("[chat] model error", streamError);
                return streamError instanceof Error ? streamError.message : String(streamError);
              },
            }));

            const answer = await result.text;
            const usage = await result.usage;

            const followUps = await suggestFollowUps(question, answer, language);
            if (followUps.length > 0) {
              writer.write({ type: "data-follow-ups", id: "follow-ups", data: { followUps } });
            }

            // Questions the knowledge base could not ground are queued for the admins.
            const grounded = /\[\d{1,2}\]/.test(answer) && retrieval.chunks.length > 0;
            const looksLikeQuestion = question.trim().split(/\s+/).length >= 3;
            if (!grounded && looksLikeQuestion) {
              const { data: existing } = await supabaseAdmin
                .from("unanswered_questions")
                .select("id, ask_count")
                .eq("status", "open")
                .ilike("question", question.slice(0, 200))
                .maybeSingle();
              if (existing) {
                await supabaseAdmin
                  .from("unanswered_questions")
                  .update({ ask_count: (existing.ask_count ?? 1) + 1, updated_at: new Date().toISOString() })
                  .eq("id", existing.id);
              } else {
                await supabaseAdmin.from("unanswered_questions").insert({
                  question: question.slice(0, 2000),
                  language,
                  user_id: userId,
                  conversation_id: conversationId,
                  confidence,
                });
              }
            }

            const latencyMs = Date.now() - startedAt;


            if (userId && conversationId) {
              await supabaseAdmin.from("conversation_messages").insert([
                { conversation_id: conversationId, role: "user", content: question, language },
                {
                  conversation_id: conversationId,
                  role: "assistant",
                  content: answer,
                  citations: citations as unknown as never,
                  retrieval: {
                    searchQuery,
                    vectorCount: retrieval.vectorCount,
                    keywordCount: retrieval.keywordCount,
                    chunkIds: retrieval.chunks.map((chunk) => chunk.id),
                  } as unknown as never,
                  confidence,
                  language,
                  provider_id: settings.providerId,
                  model: settings.chatModel,
                  prompt_tokens: usage?.inputTokens ?? null,
                  completion_tokens: usage?.outputTokens ?? null,
                  latency_ms: latencyMs,
                },
              ]);

              const summary = await summarizeMemory(memorySummary, [
                { role: "user", content: question },
                { role: "assistant", content: answer },
              ]);

              await supabaseAdmin
                .from("conversations")
                .update({
                  memory_summary: summary,
                  message_count: history.length + 2,
                  language,
                })
                .eq("id", conversationId);
            }

            await supabaseAdmin.from("ai_usage_events").insert({
              user_id: userId,
              conversation_id: conversationId,
              kind: "chat",
              provider_id: settings.providerId,
              model: settings.chatModel,
              prompt_tokens: usage?.inputTokens ?? 0,
              completion_tokens: usage?.outputTokens ?? 0,
              duration_ms: latencyMs,
              success: true,
            });
          },
          onError: (error) => {
            console.error("[chat] stream error", error);
            return "The assistant failed to answer. Please try again.";
          },
        });

        return createUIMessageStreamResponse({ stream });
      },
    },
  },
});
