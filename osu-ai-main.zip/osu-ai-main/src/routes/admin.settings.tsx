import { createFileRoute } from "@tanstack/react-router";
import { Palette, Settings, ShieldCheck } from "lucide-react";
import { AdminPlaceholderPage } from "@/features/admin/components/admin-placeholder-page";
import { EmbedWidgetCard } from "@/features/admin/components/embed-widget-card";


export const Route = createFileRoute("/admin/settings")({
  head: () => ({
    meta: [
      { title: "Settings — OSU AI Assistant" },
      { name: "description", content: "Platform configuration, branding and security settings." },
      { property: "og:title", content: "Settings — OSU AI Assistant" },
      { property: "og:description", content: "Centralized platform configuration." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <div className="space-y-6">
      <AdminPlaceholderPage
        icon={Settings}
        title="Settings"
        description="Centralized configuration — no setting is hardcoded inside a feature."
        panels={[
          {
            icon: Settings,
            title: "Platform",
            description: "Feature flags, languages and assistant limits.",
            capabilities: ["Feature toggles", "Default language", "Message limits", "Retention window"],
          },
          {
            icon: Palette,
            title: "Branding",
            description: "University identity applied through design tokens.",
            capabilities: ["Colour tokens", "Logo assets", "Light / dark / system", "Typography scale"],
          },
          {
            icon: ShieldCheck,
            title: "Security",
            description: "Protections enforced at the edge and in the database.",
            capabilities: ["Rate limiting", "Row Level Security", "Input sanitization", "Audit logging"],
          },
        ]}
      />
      <EmbedWidgetCard />
    </div>
  );
}

