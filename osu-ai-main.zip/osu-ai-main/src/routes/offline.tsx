import { createFileRoute, Link } from "@tanstack/react-router";
import { WifiOff } from "lucide-react";

import { PublicLayout } from "@/layouts/public-layout";
import { Container } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { Lead, PageTitle } from "@/components/ui/typography";

export const Route = createFileRoute("/offline")({
  head: () => ({
    meta: [
      { title: "You're offline — OSU AI Assistant" },
      { name: "description", content: "This page is shown when the OSU AI Assistant cannot reach the network." },
      { property: "og:title", content: "You're offline — OSU AI Assistant" },
      { property: "og:description", content: "Reconnect to continue using the assistant." },
    ],
  }),
  component: OfflinePage,
});

/** Fallback destination for the future offline-capable service worker. */
function OfflinePage() {
  return (
    <PublicLayout>
      <Container size="sm" className="flex min-h-[65vh] flex-col items-center justify-center gap-4 py-16 text-center">
        <span className="grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground">
          <WifiOff className="size-7" aria-hidden />
        </span>
        <PageTitle>You're offline</PageTitle>
        <Lead>Cached pages remain available. Live answers resume as soon as you reconnect.</Lead>
        <Button asChild>
          <Link to="/">Back to home</Link>
        </Button>
      </Container>
    </PublicLayout>
  );
}
