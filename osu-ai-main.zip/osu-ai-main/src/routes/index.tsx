import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, FileSearch, Globe, Languages, MessageSquare, Mic, ShieldCheck, Sparkles } from "lucide-react";

import heroCampus from "@/assets/hero-campus.jpg";
import { PublicLayout } from "@/layouts/public-layout";
import { Container } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Eyebrow, Lead, SectionTitle } from "@/components/ui/typography";
import { appConfig } from "@/config/app.config";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OSU AI Assistant — Oromia State University" },
      {
        name: "description",
        content:
          "The official AI assistant of Oromia State University: grounded, cited answers from university documents, policies, research and osu.edu.et.",
      },
      { property: "og:title", content: "OSU AI Assistant — Oromia State University" },
      {
        property: "og:description",
        content: "The official AI assistant of Oromia State University: grounded, cited answers from university documents, policies, research and osu.edu.et.",
      },
    ],
  }),
  component: HomePage,
});

const pillars = [
  {
    icon: FileSearch,
    title: "Retrieval-Augmented Generation",
    description: "Every answer is retrieved from indexed university content before it is generated.",
  },
  {
    icon: ShieldCheck,
    title: "No hallucinations",
    description: "If no official source exists, the assistant says so instead of inventing an answer.",
  },
  {
    icon: BookOpen,
    title: "Cited sources",
    description: "Documents, policies, research papers and pages are linked with every response.",
  },
  {
    icon: Globe,
    title: "Website synchronization",
    description: "Architecture ready for scheduled crawling and re-indexing of osu.edu.et.",
  },
  {
    icon: Languages,
    title: "Three languages",
    description: "English, Afaan Oromoo and አማርኛ with automatic detection planned.",
  },
  {
    icon: Mic,
    title: "Voice ready",
    description: "Speech-to-text and text-to-speech interfaces are defined for the next phase.",
  },
] as const;

const audiences = ["Students", "Applicants", "Staff", "Researchers", "Visitors", "Administrators"] as const;

function HomePage() {
  return (
    <PublicLayout>
      <section className="relative overflow-hidden bg-gradient-hero text-primary-foreground">
        <img
          src={heroCampus}
          alt="Oromia State University campus at golden hour"
          width={1600}
          height={1000}
          className="absolute inset-0 size-full object-cover opacity-25"
        />
        <Container className="relative py-20 sm:py-28">
          <div className="max-w-3xl space-y-6">
            <Badge variant="secondary" className="bg-primary-foreground/15 text-primary-foreground">
              {appConfig.organization}
            </Badge>
            <h1 className="text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
              Ask anything about Oromia State University
            </h1>
            <p className="max-w-2xl text-lg text-primary-foreground/85">
              Grounded answers from official documents, policies, research and the university website — always with
              citations, never invented.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild variant="hero" size="xl">
                <Link to="/chat">
                  <MessageSquare aria-hidden />
                  Open the assistant
                </Link>
              </Button>
              <Button asChild variant="onDark" size="xl">
                <Link to="/admin">Admin console</Link>
              </Button>
            </div>
            <p className="text-sm text-primary-foreground/70">
              Platform status: architecture foundation complete — conversational engine arriving in the next phase.
            </p>
          </div>
        </Container>
      </section>

      <section className="py-16 sm:py-20">
        <Container>
          <div className="max-w-2xl space-y-3">
            <Eyebrow>Platform principles</Eyebrow>
            <SectionTitle>Built for accuracy, not guesswork</SectionTitle>
            <Lead>
              Each capability below already has typed service contracts, provider interfaces and admin screens in
              place, so implementation is incremental rather than structural.
            </Lead>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pillars.map((pillar) => (
              <Card key={pillar.title} className="h-full transition-shadow hover:shadow-soft">
                <CardHeader>
                  <span className="mb-2 grid size-10 place-items-center rounded-xl bg-primary/10 text-primary">
                    <pillar.icon className="size-5" aria-hidden />
                  </span>
                  <CardTitle className="text-base">{pillar.title}</CardTitle>
                  <CardDescription>{pillar.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-border bg-muted/40 py-14">
        <Container className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="space-y-2">
            <Eyebrow>Who it serves</Eyebrow>
            <SectionTitle>One assistant for the whole university</SectionTitle>
          </div>
          <ul className="flex flex-wrap gap-2">
            {audiences.map((audience) => (
              <li key={audience}>
                <Badge variant="outline" className="px-3 py-1.5 text-sm">
                  {audience}
                </Badge>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      <section className="py-16">
        <Container>
          <Card className="overflow-hidden border-0 bg-gradient-hero text-primary-foreground">
            <CardContent className="flex flex-col items-start gap-6 p-8 sm:p-12 lg:flex-row lg:items-center lg:justify-between">
              <div className="max-w-xl space-y-3">
                <span className="inline-flex items-center gap-2 text-sm text-primary-foreground/80">
                  <Sparkles className="size-4" aria-hidden />
                  Next phase
                </span>
                <h2 className="text-2xl font-semibold sm:text-3xl">Knowledge ingestion and the chat engine</h2>
                <p className="text-primary-foreground/80">
                  Documents, embeddings and retrieval land next, followed by the conversational interface with
                  streaming answers and inline citations.
                </p>
              </div>
            </CardContent>

          </Card>
        </Container>
      </section>
    </PublicLayout>
  );
}
