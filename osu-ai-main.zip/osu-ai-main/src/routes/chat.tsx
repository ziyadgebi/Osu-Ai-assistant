import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { History as HistoryIcon, Loader2, Send, ShieldCheck, Sparkles } from "lucide-react";

import { PublicLayout } from "@/layouts/public-layout";
import { Container } from "@/components/layout/container";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Muted } from "@/components/ui/typography";
import { MessageBubble } from "@/features/chat/components/message-bubble";
import { CitationList } from "@/features/chat/components/citation-list";
import { supabase } from "@/integrations/supabase/client";
import {
  conversationService,
  type ConversationSummary,
} from "@/features/chat/services/conversation.service";
import { useAuth } from "@/hooks/use-auth";
import { useTranslation } from "@/hooks/use-translation";
import type { Citation } from "@/types/domain.types";

export const Route = createFileRoute("/chat")({
  head: () => ({
    meta: [
      { title: "Assistant — OSU AI Assistant" },
      {
        name: "description",
        content: "Chat with the Oromia State University assistant for cited answers from official sources.",
      },
      { property: "og:title", content: "Assistant — OSU AI Assistant" },
      { property: "og:description", content: "Cited answers from official Oromia State University sources." },
    ],
  }),
  component: ChatPage,
});

interface CitationPayload {
  readonly citations: readonly Citation[];
  readonly confidence: number;
  readonly language: string;
  readonly searchQuery: string;
  readonly model: string;
  readonly retrieval: { vectorCount: number; keywordCount: number; durationMs: number };
  readonly conversationId: string | null;
}


const LAST_CONVERSATION_KEY = "osu.chat.last-conversation";
const GUEST_MESSAGES_KEY = "osu.chat.guest-messages";

/** Source numbers the answer actually cites, e.g. "… fees [2][5]" -> [2, 5]. */
function usedCitationNumbers(text: string): number[] {
  const found = new Set<number>();
  for (const match of text.matchAll(/\[(\d{1,2})\]/g)) {
    const value = Number(match[1]);
    if (value > 0) found.add(value);
  }
  return [...found].sort((a, b) => a - b);
}


function ChatPage() {
  const { language } = useTranslation();
  const { user } = useAuth();
  const [input, setInput] = useState("");
  const conversationId = useRef<string | null>(null);
  const composer = useRef<HTMLTextAreaElement>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const [history, setHistory] = useState<readonly ConversationSummary[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        prepareSendMessagesRequest: async ({ messages, body }) => {
          const { data } = await supabase.auth.getSession();
          const token = data.session?.access_token;
          const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};
          return {
            headers,
            body: { ...body, messages, conversationId: conversationId.current, language },
          };
        },
      }),
    [language],
  );

  const { messages, setMessages, sendMessage, status, error } = useChat({ transport });
  const isBusy = status === "submitted" || status === "streaming";

  const refreshHistory = async () => {
    if (!user) return;
    const result = await conversationService.list();
    if (result.ok) setHistory(result.data);
  };

  useEffect(() => {
    void refreshHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!isBusy && user) void refreshHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isBusy]);

  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const openConversation = async (id: string) => {
    setLoadingId(id);
    setHistoryError(null);
    const result = await conversationService.messages(id);
    setLoadingId(null);
    if (!result.ok) {
      setHistoryError("Could not open that conversation. Please try again.");
      return;
    }
    conversationId.current = id;
    setActiveId(id);
    if (typeof window !== "undefined") window.localStorage.setItem(LAST_CONVERSATION_KEY, id);
    setMessages(
      result.data.map((message) => ({
        id: message.id,
        role: message.role === "assistant" ? ("assistant" as const) : ("user" as const),
        parts: [{ type: "text" as const, text: message.content }],
      })),
    );
    setStick(true);
  };


  const startNewChat = () => {
    conversationId.current = null;
    setActiveId(null);
    setMessages([]);
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(LAST_CONVERSATION_KEY);
      window.localStorage.removeItem(GUEST_MESSAGES_KEY);
    }
    composer.current?.focus();
  };

  // Restore the previous session when the visitor comes back to the site.
  const restored = useRef(false);
  useEffect(() => {
    if (restored.current || typeof window === "undefined") return;
    if (user) {
      const last = window.localStorage.getItem(LAST_CONVERSATION_KEY);
      if (last) {
        restored.current = true;
        void openConversation(last);
      }
      return;
    }
    const cached = window.localStorage.getItem(GUEST_MESSAGES_KEY);
    if (cached) {
      restored.current = true;
      try {
        const parsed = JSON.parse(cached) as typeof messages;
        if (Array.isArray(parsed) && parsed.length > 0) setMessages(parsed);
      } catch {
        window.localStorage.removeItem(GUEST_MESSAGES_KEY);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // Guests keep their transcript locally so it survives a reload.
  useEffect(() => {
    if (user || isBusy || typeof window === "undefined") return;
    if (messages.length === 0) return;
    window.localStorage.setItem(GUEST_MESSAGES_KEY, JSON.stringify(messages.slice(-40)));
  }, [messages, isBusy, user]);

  useEffect(() => {
    composer.current?.focus();
  }, []);

  useEffect(() => {
    if (!isBusy) composer.current?.focus();
  }, [isBusy]);

  // ChatGPT-style autoscroll: follow the stream until the user scrolls, then stay put.
  const [stick, setStick] = useState(true);

  useEffect(() => {
    const stop = () => setStick(false);
    window.addEventListener("wheel", stop, { passive: true });
    window.addEventListener("touchmove", stop, { passive: true });
    window.addEventListener("keydown", (event) => {
      if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End"].includes(event.key)) stop();
    });
    return () => {
      window.removeEventListener("wheel", stop);
      window.removeEventListener("touchmove", stop);
    };
  }, []);

  useEffect(() => {
    if (stick) bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, status, stick]);


  const send = (text: string) => {
    const value = text.trim();
    if (!value || isBusy) return;
    setInput("");
    setStick(true);
    void sendMessage({ text: value });
  };

  const lastFollowUps = [...messages]
    .reverse()
    .flatMap((message) => message.parts)
    .find((part) => part.type === "data-follow-ups") as { data?: { followUps?: string[] } } | undefined;

  return (
    <PublicLayout>
      <Container size="md" className="space-y-6 py-10">
        <PageHeader
          eyebrow="Assistant"
          title="OSU Assistant"
          description="Answers are generated only from official university knowledge, with sources attached."
        />

        {user ? (
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setHistoryOpen((open) => !open)}>
                <HistoryIcon className="size-4" aria-hidden />
                Chat history ({history.length})
              </Button>
              <Button variant="ghost" size="sm" onClick={startNewChat}>
                New chat
              </Button>
            </div>
            {historyOpen ? (
              <Card>
                <CardContent className="max-h-72 space-y-1 overflow-y-auto p-2">
                  {historyError ? <p className="p-2 text-xs text-destructive">{historyError}</p> : null}
                  {history.length === 0 ? (
                    <Muted className="p-2 text-xs">No saved conversations yet.</Muted>
                  ) : (
                    history.map((conversation) => (
                      <button
                        key={conversation.id}
                        type="button"
                        onClick={() => void openConversation(conversation.id)}
                        aria-current={activeId === conversation.id}
                        className={`flex w-full flex-col rounded-md px-3 py-2 text-left text-sm hover:bg-muted ${
                          activeId === conversation.id ? "bg-muted ring-1 ring-primary/40" : ""
                        }`}
                      >
                        <span className="line-clamp-1 font-medium">{conversation.title}</span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          {new Date(conversation.updatedAt).toLocaleString()} · {conversation.messageCount} messages
                          {loadingId === conversation.id ? <Loader2 className="size-3 animate-spin" aria-hidden /> : null}
                          {activeId === conversation.id && loadingId !== conversation.id ? " · open" : ""}
                        </span>
                      </button>
                    ))
                  )}
                </CardContent>
              </Card>
            ) : null}
            {activeId ? (
              <Muted className="text-xs">
                Viewing: {history.find((item) => item.id === activeId)?.title ?? "conversation"} — continue typing below to
                add to it.
              </Muted>
            ) : null}

          </div>
        ) : null}


        <Card className="bg-gradient-surface">
          <CardContent className="min-h-[320px] space-y-6 p-5">
            {messages.length === 0 ? (
              <div className="flex min-h-[260px] flex-col items-center justify-center gap-4 text-center">
                <span className="grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary">
                  <Sparkles className="size-6" aria-hidden />
                </span>
                <p className="text-lg font-medium">Ask about admissions, programs, policies or research</p>

              </div>
            ) : (
              messages.map((message) => {
                const text = message.parts
                  .map((part) => (part.type === "text" ? part.text : ""))
                  .join("");
                const meta = message.parts.find((part) => part.type === "data-citations") as
                  | { data?: CitationPayload }
                  | undefined;
                if (meta?.data?.conversationId) conversationId.current = meta.data.conversationId;
                if (meta?.data?.conversationId && typeof window !== "undefined") {
                  window.localStorage.setItem(LAST_CONVERSATION_KEY, meta.data.conversationId);
                }

                // Only the sources the answer actually cites are shown.
                const used = usedCitationNumbers(text);
                const cited = used
                  .map((number) => ({ number, citation: meta?.data?.citations[number - 1] }))
                  .filter((entry): entry is { number: number; citation: Citation } => Boolean(entry.citation));

                return (
                  <div key={message.id} className="space-y-3">
                    <MessageBubble
                      role={message.role === "user" ? "user" : "assistant"}
                      content={text}
                      pending={isBusy}
                    />
                    {message.role === "assistant" && meta?.data && cited.length > 0 ? (
                      <div className="space-y-2 pl-11">
                        <CitationList
                          citations={cited.map((entry) => entry.citation)}
                          numbers={cited.map((entry) => entry.number)}
                          confidence={meta.data.confidence}
                        />
                      </div>
                    ) : null}
                  </div>

                );
              })
            )}
            <div ref={bottom} />
          </CardContent>
        </Card>

        {lastFollowUps?.data?.followUps?.length ? (
          <div className="flex flex-wrap gap-2">
            {lastFollowUps.data.followUps.map((question) => (
              <Button key={question} size="sm" variant="secondary" onClick={() => send(question)}>
                {question}
              </Button>
            ))}
          </div>
        ) : null}

        {error ? (
          <p className="text-sm text-destructive">
            {error.message || "The assistant could not answer. Please try again."}
          </p>
        ) : null}

        <div className="space-y-3">
          <Textarea
            ref={composer}
            rows={3}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                send(input);
              }
            }}
            aria-label="Message the assistant"
            placeholder="Ask about admissions, programs, policies, research…"
          />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="gap-1">
                <ShieldCheck className="size-3" aria-hidden /> Grounded answers only
              </Badge>
              {!user ? <Muted className="text-xs">Sign in to keep your chat history.</Muted> : null}
            </div>
            <Button size="sm" disabled={isBusy || input.trim().length === 0} onClick={() => send(input)}>
              {isBusy ? <Loader2 className="animate-spin" aria-hidden /> : <Send aria-hidden />}
              Send
            </Button>
          </div>
        </div>
      </Container>
    </PublicLayout>
  );
}
