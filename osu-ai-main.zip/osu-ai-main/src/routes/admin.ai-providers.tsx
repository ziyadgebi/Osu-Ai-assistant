import { createFileRoute } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/page-header";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Muted } from "@/components/ui/typography";
import { providerCatalog } from "@/features/ai/providers/provider-registry";

export const Route = createFileRoute("/admin/ai-providers")({
  head: () => ({
    meta: [
      { title: "AI providers — OSU AI Assistant" },
      { name: "description", content: "Configure Gemini, Addis AI, OpenRouter, Ollama, OpenAI, Claude and DeepSeek." },
      { property: "og:title", content: "AI providers — OSU AI Assistant" },
      { property: "og:description", content: "Pluggable model providers behind one interface." },
    ],
  }),
  component: AIProvidersPage,
});

/** Every provider implements the same AIProvider interface (chat/embed/translate/speech). */
function AIProvidersPage() {
  return (
    <>
      <PageHeader
        eyebrow="Admin"
        title="AI providers"
        description="One interface, many vendors. Keys are stored as backend secrets — never in the codebase."
      />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {providerCatalog.map((provider) => (
          <Card key={provider.id} className="h-full">
            <CardHeader>
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-base">{provider.label}</CardTitle>
                <Badge variant={provider.enabled ? "default" : "secondary"}>
                  {provider.enabled ? "Enabled" : "Not configured"}
                </Badge>
              </div>
              <CardDescription>Chat model: {provider.chatModel}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1.5">
              <Muted>Embeddings: {provider.embeddingModel ?? "not supported"}</Muted>
              <Muted>Translation: {provider.supportsTranslation ? "yes" : "no"}</Muted>
              <Muted>Speech: {provider.supportsSpeech ? "yes" : "no"}</Muted>
              <Muted>Secret: {provider.secretName}</Muted>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}
