import { createFileRoute } from "@tanstack/react-router";
import { CalendarClock, Globe, ListChecks } from "lucide-react";
import { AdminPlaceholderPage } from "@/features/admin/components/admin-placeholder-page";

export const Route = createFileRoute("/admin/website-sync")({
  head: () => ({
    meta: [
      { title: "Website sync — OSU AI Assistant" },
      { name: "description", content: "Automatic crawling and re-indexing of osu.edu.et." },
      { property: "og:title", content: "Website sync — OSU AI Assistant" },
      { property: "og:description", content: "Keep the assistant aligned with the official university website." },
    ],
  }),
  component: WebsiteSyncPage,
});

function WebsiteSyncPage() {
  return (
    <AdminPlaceholderPage
      icon={Globe}
      title="Website sync"
      description="Scheduled crawl of https://osu.edu.et with change detection and re-indexing."
      panels={[
        {
          icon: CalendarClock,
          title: "Scheduling",
          description: "Cron-driven crawls with manual on-demand runs.",
          capabilities: ["Nightly full crawl", "Hourly news sweep", "Manual trigger", "Robots.txt respected"],
        },
        {
          icon: ListChecks,
          title: "Page inventory",
          description: "Every discovered URL with its hash and index status.",
          capabilities: ["Content hash diffing", "Include / exclude rules", "Failure retries", "Last crawled timestamp"],
        },
      ]}
    />
  );
}
