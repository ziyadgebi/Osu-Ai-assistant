/** Admin training screen — upload files, extract text, embed into the knowledge base. */

import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { FileText, Loader2, RefreshCw, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import {
  SUPPORTED_EXTENSIONS,
  extensionOf,
  extractTextFromFile,
  fileToBase64,
} from "@/features/documents/lib/extract-client";
import { deleteDocument, ingestDocument, ocrImage, reindexDocument } from "@/features/documents/services/document.functions";
import { TextTrainingCard } from "@/features/documents/components/text-training-card";
import { UnansweredQuestionsCard } from "@/features/documents/components/unanswered-questions-card";

export const Route = createFileRoute("/admin/training")({
  head: () => ({
    meta: [
      { title: "AI training — OSU AI Assistant" },
      { name: "description", content: "Upload PDF, Word, PowerPoint, Excel and image files to train the OSU assistant." },
      { property: "og:title", content: "AI training — OSU AI Assistant" },
      { property: "og:description", content: "Administrator-only training of the university knowledge base." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TrainingPage,
});

interface DocumentRow {
  id: string;
  title: string;
  file_extension: string | null;
  file_size: number | null;
  chunk_count: number | null;
  embedding_status: string | null;
  created_at: string;
}

const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp", "gif", "bmp"]);

function formatSize(bytes: number | null): string {
  if (!bytes) return "—";
  const units = ["B", "KB", "MB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function TrainingPage() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);
  const [documents, setDocuments] = useState<DocumentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentFile, setCurrentFile] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from("knowledge_documents")
      .select("id, title, file_extension, file_size, chunk_count, embedding_status, created_at")
      .eq("source", "upload")
      .order("created_at", { ascending: false })
      .limit(100);
    setDocuments((data ?? []) as DocumentRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (isAdmin) void load();
  }, [isAdmin, load]);

  const handleFiles = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      setBusy(true);
      const total = files.length;

      for (let index = 0; index < total; index += 1) {
        const file = files[index]!;
        setCurrentFile(file.name);
        setProgress(Math.round((index / total) * 100));
        const extension = extensionOf(file.name);

        try {
          if (!SUPPORTED_EXTENSIONS.includes(extension as never)) {
            throw new Error(`Unsupported file type .${extension}`);
          }

          let text = "";
          if (IMAGE_EXTENSIONS.has(extension)) {
            const dataBase64 = await fileToBase64(file);
            const ocr = await ocrImage({
              data: { fileName: file.name, mimeType: file.type || "image/png", dataBase64 },
            });
            text = ocr.text;
          } else {
            const extracted = await extractTextFromFile(file);
            text = extracted.text;
          }

          if (!text || text.trim().length < 20) throw new Error("No readable text found in this file");

          const fileBase64 = file.size <= 8_000_000 ? await fileToBase64(file) : null;
          const result = await ingestDocument({
            data: {
              title: file.name.replace(/\.[^.]+$/, ""),
              fileName: file.name,
              fileExtension: extension,
              fileType: file.type || "application/octet-stream",
              fileSize: file.size,
              text,
              fileBase64,
            },
          });
          toast.success(`${file.name} trained`, { description: `${result.chunks} chunk(s) embedded` });
        } catch (error) {
          toast.error(`${file.name} failed`, {
            description: error instanceof Error ? error.message : "Unknown error",
          });
        }
      }

      setProgress(100);
      setCurrentFile(null);
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
      await load();
    },
    [load],
  );

  if (authLoading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground">
        <Loader2 className="size-4 animate-spin" /> Checking permissions…
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <>
        <PageHeader eyebrow="Admin" title="AI training" description="Administrator access required." />
        <Card>
          <CardContent className="py-10 text-center text-muted-foreground">
            Only administrators can train the assistant. Sign in with an administrator account to continue.
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Admin"
        title="AI training"
        description="Upload official university files. Text is extracted, chunked and embedded so the assistant can answer from them with citations."
      />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UploadCloud className="size-5 text-primary" /> Upload training files
          </CardTitle>
          <CardDescription>
            PDF, Word, PowerPoint, Excel, CSV, Markdown, HTML, plain text and images (scanned pages are read with vision OCR).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            ref={inputRef}
            type="file"
            multiple
            disabled={busy}
            accept=".pdf,.docx,.doc,.pptx,.xlsx,.xls,.csv,.txt,.md,.html,.htm,.png,.jpg,.jpeg,.webp"
            onChange={(event) => void handleFiles(event.target.files)}
            aria-label="Select training files"
          />
          {busy ? (
            <div className="space-y-2">
              <Progress value={progress} />
              <p className="text-sm text-muted-foreground">
                <Loader2 className="mr-2 inline size-3 animate-spin" />
                Processing {currentFile ?? "files"}…
              </p>
            </div>
          ) : null}
        </CardContent>
      </Card>

      <TextTrainingCard onTrained={load} />

      <UnansweredQuestionsCard onTrained={load} />



      <Card className="mt-6">
        <CardHeader className="flex-row items-center justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="size-5 text-primary" /> Trained documents
            </CardTitle>
            <CardDescription>{documents.length} uploaded source(s) in the knowledge base.</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => void load()} disabled={loading}>
            <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {documents.length === 0 && !loading ? (
            <p className="py-8 text-center text-sm text-muted-foreground">No documents yet — upload the first file above.</p>
          ) : null}
          {documents.map((document) => (
            <div
              key={document.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border/60 p-3"
            >
              <div className="min-w-0">
                <p className="truncate font-medium">{document.title}</p>
                <p className="text-xs text-muted-foreground">
                  .{document.file_extension ?? "?"} · {formatSize(document.file_size)} ·{" "}
                  {document.chunk_count ?? 0} chunk(s)
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={document.embedding_status === "completed" ? "default" : "secondary"}>
                  {document.embedding_status ?? "pending"}
                </Badge>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    try {
                      const result = await reindexDocument({ data: { documentId: document.id } });
                      toast.success("Re-indexed", { description: `${result.chunks} chunk(s)` });
                      await load();
                    } catch (error) {
                      toast.error(error instanceof Error ? error.message : "Re-index failed");
                    }
                  }}
                >
                  <RefreshCw className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={async () => {
                    try {
                      await deleteDocument({ data: { documentId: document.id } });
                      toast.success("Document removed");
                      await load();
                    } catch (error) {
                      toast.error(error instanceof Error ? error.message : "Delete failed");
                    }
                  }}
                >
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </>
  );
}
