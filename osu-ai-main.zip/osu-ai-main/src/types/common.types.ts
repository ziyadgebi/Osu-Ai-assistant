/**
 * Shared primitive types used across every feature.
 */

export type UUID = string;
export type ISODateString = string;

/** Discriminated result type — services never throw for expected failures. */
export type Result<TData, TError = AppError> =
  | { readonly ok: true; readonly data: TData }
  | { readonly ok: false; readonly error: TError };

export interface AppError {
  readonly code: string;
  readonly message: string;
  readonly details?: Readonly<Record<string, unknown>>;
}

export interface Paginated<TItem> {
  readonly items: readonly TItem[];
  readonly total: number;
  readonly page: number;
  readonly pageSize: number;
}

export interface PaginationParams {
  readonly page?: number;
  readonly pageSize?: number;
  readonly search?: string;
}

export const ok = <TData>(data: TData): Result<TData> => ({ ok: true, data });

export const fail = <TData = never>(code: string, message: string, details?: Record<string, unknown>): Result<TData> => ({
  ok: false,
  error: { code, message, details },
});

/** Thrown/returned when a placeholder service is called during the architecture phase. */
export const notImplemented = <TData = never>(service: string): Result<TData> =>
  fail<TData>("NOT_IMPLEMENTED", `${service} is not implemented yet.`);
