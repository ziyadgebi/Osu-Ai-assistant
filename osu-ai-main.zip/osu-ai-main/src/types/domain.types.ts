/**
 * Domain models — the future PostgreSQL schema expressed as TypeScript.
 * No SQL is created in this phase; these interfaces are the contract that the
 * database migrations, Edge Functions and UI will all be generated against.
 */

import type { ISODateString, UUID } from "./common.types";
import type { LanguageCode } from "./i18n.types";

export type UserRole = "super_admin" | "admin" | "moderator" | "staff" | "student" | "guest";

export interface UserProfile {
  readonly id: UUID;
  readonly email: string;
  readonly fullName: string;
  readonly avatarUrl: string | null;
  readonly department: string | null;
  readonly preferredLanguage: LanguageCode;
  readonly createdAt: ISODateString;
}

/** Roles live in a dedicated table — never on the profile row. */
export interface UserRoleRecord {
  readonly id: UUID;
  readonly userId: UUID;
  readonly role: UserRole;
  readonly grantedAt: ISODateString;
}

export interface Conversation {
  readonly id: UUID;
  readonly userId: UUID | null;
  readonly title: string;
  readonly language: LanguageCode;
  readonly messageCount: number;
  readonly createdAt: ISODateString;
  readonly updatedAt: ISODateString;
}

export type MessageRole = "user" | "assistant" | "system";

export interface Message {
  readonly id: UUID;
  readonly conversationId: UUID;
  readonly role: MessageRole;
  readonly content: string;
  readonly citations: readonly Citation[];
  readonly tokensUsed: number | null;
  readonly createdAt: ISODateString;
}

export interface Citation {
  readonly sourceId: UUID;
  readonly title: string;
  readonly url: string | null;
  readonly page: number | null;
  readonly snippet: string;
  readonly score: number;
}

export type DocumentKind = "pdf" | "docx" | "xlsx" | "webpage" | "image" | "video" | "research" | "policy" | "news";
export type IngestionStatus = "pending" | "processing" | "indexed" | "failed";

export interface KnowledgeDocument {
  readonly id: UUID;
  readonly title: string;
  readonly kind: DocumentKind;
  readonly storagePath: string | null;
  readonly sourceUrl: string | null;
  readonly language: LanguageCode;
  readonly status: IngestionStatus;
  readonly chunkCount: number;
  readonly uploadedBy: UUID | null;
  readonly createdAt: ISODateString;
}

export interface KnowledgeChunk {
  readonly id: UUID;
  readonly documentId: UUID;
  readonly index: number;
  readonly content: string;
  readonly tokenCount: number;
  readonly metadata: Readonly<Record<string, string | number | boolean | null>>;
}

/** pgvector row; the embedding itself is never sent to the browser. */
export interface EmbeddingRecord {
  readonly id: UUID;
  readonly chunkId: UUID;
  readonly model: string;
  readonly dimensions: number;
  readonly createdAt: ISODateString;
}

export interface WebsitePage {
  readonly id: UUID;
  readonly url: string;
  readonly title: string;
  readonly contentHash: string;
  readonly status: IngestionStatus;
  readonly lastCrawledAt: ISODateString | null;
}

export type AIProviderId = "gemini" | "addis-ai" | "openrouter" | "ollama" | "openai" | "claude" | "deepseek";

export interface AIProviderConfig {
  readonly id: AIProviderId;
  readonly label: string;
  readonly enabled: boolean;
  readonly chatModel: string;
  readonly embeddingModel: string | null;
  readonly supportsSpeech: boolean;
  readonly supportsTranslation: boolean;
  readonly secretName: string;
}

export interface AnalyticsSnapshot {
  readonly totalConversations: number;
  readonly totalMessages: number;
  readonly answeredWithSources: number;
  readonly unansweredQuestions: number;
  readonly averageLatencyMs: number;
  readonly satisfactionScore: number;
}

export type LogLevel = "debug" | "info" | "warn" | "error";

export interface LogRecord {
  readonly id: UUID;
  readonly level: LogLevel;
  readonly message: string;
  readonly context: Readonly<Record<string, unknown>>;
  readonly createdAt: ISODateString;
}

export interface FeedbackRecord {
  readonly id: UUID;
  readonly messageId: UUID;
  readonly rating: "up" | "down";
  readonly comment: string | null;
  readonly createdAt: ISODateString;
}

export interface PlatformSetting {
  readonly key: string;
  readonly value: string;
  readonly updatedAt: ISODateString;
}
