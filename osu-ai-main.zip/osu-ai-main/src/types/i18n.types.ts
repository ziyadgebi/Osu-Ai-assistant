/** Internationalization contracts. */

export type LanguageCode = "en" | "om" | "am";

export interface LanguageDefinition {
  readonly code: LanguageCode;
  readonly label: string;
  readonly nativeLabel: string;
  readonly direction: "ltr" | "rtl";
}

export type TranslationKey = string;

export type TranslationDictionary = Readonly<Record<TranslationKey, string>>;

export interface I18nContextValue {
  readonly language: LanguageCode;
  readonly setLanguage: (language: LanguageCode) => void;
  readonly t: (key: TranslationKey, fallback?: string) => string;
  readonly languages: readonly LanguageDefinition[];
}
