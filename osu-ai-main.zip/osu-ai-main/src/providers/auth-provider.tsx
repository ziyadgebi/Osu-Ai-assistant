/**
 * AuthProvider — real session context backed by Lovable Cloud auth.
 * Roles come from the user_roles table; never trust client storage for authorization.
 */

import { createContext, useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { authService } from "@/features/auth/services/auth.service";
import type { UserProfile, UserRole } from "@/types/domain.types";

export interface AuthContextValue {
  readonly user: UserProfile | null;
  readonly roles: readonly UserRole[];
  readonly isLoading: boolean;
  readonly isAuthenticated: boolean;
  readonly isAdmin: boolean;
  readonly hasRole: (role: UserRole) => boolean;
  readonly refresh: () => Promise<void>;
  readonly signOut: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [roles, setRoles] = useState<readonly UserRole[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const load = useCallback(async () => {
    const session = await authService.getSession();
    const profile = session.ok ? session.data : null;
    setUser(profile);
    if (profile) {
      const result = await authService.getRoles(profile.id);
      setRoles(result.ok ? result.data : []);
    } else {
      setRoles([]);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      void load();
    });
    return () => data.subscription.unsubscribe();
  }, [load]);

  const value = useMemo<AuthContextValue>(() => {
    const hasRole = (role: UserRole) => roles.includes(role);
    return {
      user,
      roles,
      isLoading,
      isAuthenticated: user !== null,
      isAdmin: roles.includes("admin") || roles.includes("super_admin" as UserRole),
      hasRole,
      refresh: load,
      signOut: async () => {
        await authService.signOut();
        setUser(null);
        setRoles([]);
      },
    };
  }, [user, roles, isLoading, load]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
