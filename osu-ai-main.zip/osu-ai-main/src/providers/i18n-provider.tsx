/**
 * I18nProvider — minimal, dependency-free i18n layer.
 * Designed so a full i18next/ICU backend can replace the implementation
 * without touching any consumer (they only use `t`).
 */

import { createContext, useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { appConfig } from "@/config/app.config";
import { dictionaries, languages } from "@/features/i18n/locales";
import type { I18nContextValue, LanguageCode } from "@/types/i18n.types";

export const I18nContext = createContext<I18nContextValue | null>(null);

const STORAGE_KEY = "osu-language";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode>(appConfig.defaultLanguage);

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY) as LanguageCode | null;
    if (stored && appConfig.supportedLanguages.includes(stored)) setLanguageState(stored);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = useCallback((next: LanguageCode) => {
    window.localStorage.setItem(STORAGE_KEY, next);
    setLanguageState(next);
  }, []);

  const t = useCallback(
    (key: string, fallback?: string) =>
      dictionaries[language][key] ?? dictionaries[appConfig.defaultLanguage][key] ?? fallback ?? key,
    [language],
  );

  const value = useMemo<I18nContextValue>(
    () => ({ language, setLanguage, t, languages }),
    [language, setLanguage, t],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}
