/**
 * Lovable AI Gateway access. Server-only: never import from client code.
 * One place owns the base URL, the API key and the embedding contract.
 */

import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

export const AI_GATEWAY_BASE_URL = "https://ai.gateway.lovable.dev/v1";

/** Embedding model + dimension must match the pgvector column (vector(768)). */
export const EMBEDDING_MODEL = "google/gemini-embedding-001";
export const EMBEDDING_DIMENSIONS = 768;

export function getLovableApiKey(): string {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return key;
}

/** OpenAI-compatible provider bound to the Lovable AI Gateway. */
export function createLovableAiGatewayProvider(lovableApiKey: string) {
  return createOpenAICompatible({
    name: "lovable",
    baseURL: AI_GATEWAY_BASE_URL,
    headers: {
      "Lovable-API-Key": lovableApiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
  });
}

export interface EmbedResult {
  readonly vectors: readonly (readonly number[] | null)[];
  readonly model: string;
  readonly dimensions: number;
}

/** Embeds a batch of texts. Never throws — returns nulls on failure. */
export async function embedTexts(texts: readonly string[]): Promise<EmbedResult> {
  const empty: EmbedResult = {
    vectors: texts.map(() => null),
    model: EMBEDDING_MODEL,
    dimensions: EMBEDDING_DIMENSIONS,
  };
  if (texts.length === 0) return empty;

  try {
    const response = await fetch(`${AI_GATEWAY_BASE_URL}/embeddings`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": getLovableApiKey(),
      },
      body: JSON.stringify({
        model: EMBEDDING_MODEL,
        input: texts,
        dimensions: EMBEDDING_DIMENSIONS,
      }),
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) {
      console.error("[ai-gateway] embeddings failed", response.status, await response.text());
      return empty;
    }
    const payload = (await response.json()) as { data?: { embedding: number[] }[] };
    return {
      vectors: texts.map((_text, index) => payload.data?.[index]?.embedding ?? null),
      model: EMBEDDING_MODEL,
      dimensions: EMBEDDING_DIMENSIONS,
    };
  } catch (error) {
    console.error("[ai-gateway] embeddings error", error);
    return empty;
  }
}

/** Single-text convenience wrapper. */
export async function embedQuery(text: string): Promise<readonly number[] | null> {
  const { vectors } = await embedTexts([text]);
  return vectors[0] ?? null;
}
