/**
 * Input validation & sanitization helpers.
 * Every user-supplied string crossing a trust boundary goes through here.
 */

import { z } from "zod";
import { appConfig } from "@/config/app.config";

export const uuidSchema = z.string().uuid();
export const emailSchema = z.string().email().max(254);

export const chatMessageSchema = z
  .string()
  .trim()
  .min(1, "Message cannot be empty")
  .max(appConfig.limits.maxMessageLength, "Message is too long");

/** Strips control characters and angle brackets to mitigate XSS in rendered text. */
export const sanitizeText = (input: string): string =>
  input
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001F\u007F]/g, " ")
    .replace(/[<>]/g, "")
    .trim();

/** Only allow http(s) links; blocks javascript:/data: URL injection. */
export const sanitizeUrl = (input: string): string | null => {
  try {
    const url = new URL(input);
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
};
