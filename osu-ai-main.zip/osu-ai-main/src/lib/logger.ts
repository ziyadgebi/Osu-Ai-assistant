/**
 * Application-wide logging service.
 * Swap the transport (console today, Supabase `logs` table later) in one place.
 */

import type { LogLevel } from "@/types/domain.types";
import { publicEnv } from "@/config/env";

export interface LogTransport {
  write(level: LogLevel, message: string, context?: Record<string, unknown>): void;
}

const levelWeight: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

class ConsoleTransport implements LogTransport {
  write(level: LogLevel, message: string, context?: Record<string, unknown>): void {
    const payload = context ? [message, context] : [message];
    if (level === "error") console.error("[osu]", ...payload);
    else if (level === "warn") console.warn("[osu]", ...payload);
    else if (level === "info") console.info("[osu]", ...payload);
    else console.debug("[osu]", ...payload);
  }
}

class Logger {
  private transports: LogTransport[] = [new ConsoleTransport()];
  private minimumLevel: LogLevel = publicEnv.isProduction ? "info" : "debug";

  addTransport(transport: LogTransport): void {
    this.transports.push(transport);
  }

  setLevel(level: LogLevel): void {
    this.minimumLevel = level;
  }

  private emit(level: LogLevel, message: string, context?: Record<string, unknown>): void {
    if (levelWeight[level] < levelWeight[this.minimumLevel]) return;
    for (const transport of this.transports) transport.write(level, message, context);
  }

  debug(message: string, context?: Record<string, unknown>): void {
    this.emit("debug", message, context);
  }
  info(message: string, context?: Record<string, unknown>): void {
    this.emit("info", message, context);
  }
  warn(message: string, context?: Record<string, unknown>): void {
    this.emit("warn", message, context);
  }
  error(message: string, context?: Record<string, unknown>): void {
    this.emit("error", message, context);
  }
}

export const logger = new Logger();
