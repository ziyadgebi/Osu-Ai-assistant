/**
 * Client-side rate limiter (sliding window).
 * Server-side enforcement still happens in Edge Functions — this only protects UX.
 */

export class RateLimiter {
  private readonly hits: number[] = [];

  constructor(
    private readonly limit: number,
    private readonly windowMs: number,
  ) {}

  tryConsume(now: number = Date.now()): boolean {
    while (this.hits.length > 0 && now - this.hits[0] > this.windowMs) this.hits.shift();
    if (this.hits.length >= this.limit) return false;
    this.hits.push(now);
    return true;
  }

  get remaining(): number {
    return Math.max(0, this.limit - this.hits.length);
  }
}
