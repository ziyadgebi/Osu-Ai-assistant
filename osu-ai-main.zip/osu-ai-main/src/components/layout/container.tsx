/** Layout container with consistent max width and gutters. */

import type { ElementType, ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface ContainerProps {
  readonly children: ReactNode;
  readonly className?: string;
  readonly as?: ElementType;
  readonly size?: "sm" | "md" | "lg" | "full";
}

const sizeMap: Record<NonNullable<ContainerProps["size"]>, string> = {
  sm: "max-w-3xl",
  md: "max-w-5xl",
  lg: "max-w-7xl",
  full: "max-w-none",
};

export function Container({ children, className, as: Tag = "div", size = "lg" }: ContainerProps) {
  return <Tag className={cn("mx-auto w-full px-4 sm:px-6 lg:px-8", sizeMap[size], className)}>{children}</Tag>;
}
