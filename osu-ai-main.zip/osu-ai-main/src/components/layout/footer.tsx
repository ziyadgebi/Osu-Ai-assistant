/** Global site footer. */

import { Link } from "@tanstack/react-router";
import { Container } from "@/components/layout/container";
import { appConfig } from "@/config/app.config";

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/40">
      <Container className="flex flex-col gap-4 py-8 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} {appConfig.organization}. All rights reserved.
        </p>
        <nav aria-label="Footer" className="flex flex-wrap gap-4 text-sm text-muted-foreground">
          <a href={appConfig.organizationUrl} target="_blank" rel="noreferrer" className="hover:text-foreground">
            osu.edu.et
          </a>
          <Link to="/chat" className="hover:text-foreground">
            Assistant
          </Link>
          <Link to="/admin" className="hover:text-foreground">
            Admin
          </Link>
          <a href={`mailto:${appConfig.supportEmail}`} className="hover:text-foreground">
            Support
          </a>
          <a
            href="https://miilis-prtfolio.lovable.app/"
            target="_blank"
            rel="noreferrer"
            className="font-medium text-foreground hover:text-primary"
          >
            Developed by Million · 0907858058
          </a>
        </nav>
      </Container>
    </footer>
  );
}
