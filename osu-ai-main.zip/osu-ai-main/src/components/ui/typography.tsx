/** Typography primitives so text styles are never re-invented per page. */

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface TextProps {
  readonly children: ReactNode;
  readonly className?: string;
}

export function PageTitle({ children, className }: TextProps) {
  return <h1 className={cn("text-3xl font-semibold sm:text-4xl", className)}>{children}</h1>;
}

export function SectionTitle({ children, className }: TextProps) {
  return <h2 className={cn("text-xl font-semibold sm:text-2xl", className)}>{children}</h2>;
}

export function Lead({ children, className }: TextProps) {
  return <p className={cn("text-base leading-relaxed text-muted-foreground sm:text-lg", className)}>{children}</p>;
}

export function Muted({ children, className }: TextProps) {
  return <p className={cn("text-sm text-muted-foreground", className)}>{children}</p>;
}

export function Eyebrow({ children, className }: TextProps) {
  return (
    <span className={cn("text-xs font-semibold uppercase tracking-[0.18em] text-accent", className)}>
      {children}
    </span>
  );
}
