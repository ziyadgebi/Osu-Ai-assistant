/** Language switcher for English / Afaan Oromo / Amharic. */

import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTranslation } from "@/hooks/use-translation";

export function LanguageSwitcher() {
  const { language, setLanguage, languages } = useTranslation();
  const active = languages.find((item) => item.code === language);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" aria-label="Change language" className="gap-2">
          <Languages aria-hidden />
          <span className="hidden sm:inline">{active?.nativeLabel}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {languages.map((item) => (
          <DropdownMenuItem key={item.code} onSelect={() => setLanguage(item.code)}>
            <span className="font-medium">{item.nativeLabel}</span>
            <span className="ml-2 text-xs text-muted-foreground">{item.label}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
