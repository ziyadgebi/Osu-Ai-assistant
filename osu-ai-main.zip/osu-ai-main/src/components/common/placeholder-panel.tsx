/**
 * PlaceholderPanel — the standard "architecture ready, implementation next"
 * block. Keeps every unbuilt screen visually consistent and honest.
 */

import type { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export interface PlaceholderPanelProps {
  readonly icon: LucideIcon;
  readonly title: string;
  readonly description: string;
  readonly capabilities: readonly string[];
  readonly status?: string;
}

export function PlaceholderPanel({
  icon: Icon,
  title,
  description,
  capabilities,
  status = "Planned",
}: PlaceholderPanelProps) {
  return (
    <Card className="border-dashed bg-gradient-surface">
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="rounded-xl bg-primary/10 p-2.5 text-primary">
            <Icon className="size-5" aria-hidden />
          </span>
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
        </div>
        <Badge variant="secondary">{status}</Badge>
      </CardHeader>
      <CardContent>
        <ul className="grid gap-2 sm:grid-cols-2">
          {capabilities.map((capability) => (
            <li key={capability} className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-accent" aria-hidden />
              {capability}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
