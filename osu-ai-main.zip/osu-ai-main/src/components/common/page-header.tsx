/** Consistent page heading block used by every admin & public page. */

import type { ReactNode } from "react";
import { Eyebrow, Lead, PageTitle } from "@/components/ui/typography";

export interface PageHeaderProps {
  readonly eyebrow?: string;
  readonly title: string;
  readonly description?: string;
  readonly actions?: ReactNode;
}

export function PageHeader({ eyebrow, title, description, actions }: PageHeaderProps) {
  return (
    <header className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between">
      <div className="space-y-2">
        {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}
        <PageTitle>{title}</PageTitle>
        {description ? <Lead className="max-w-2xl text-base">{description}</Lead> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}
