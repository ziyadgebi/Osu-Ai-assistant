/** University wordmark used in the navbar, sidebar and footer. */

import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { appConfig } from "@/config/app.config";
import osuLogo from "@/assets/osu-logo.png.asset.json";

export function BrandMark({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  return (
    <Link to="/" className={cn("flex items-center gap-2.5", className)} aria-label={`${appConfig.name} home`}>
      <span
        className={cn(
          "grid size-9 shrink-0 place-items-center overflow-hidden rounded-xl bg-background",
          inverted && "bg-sidebar-accent",
        )}
      >
        <img src={osuLogo.url} alt="" aria-hidden className="size-9 object-cover object-left" />
      </span>
      <span className="leading-tight">
        <span className="block font-display text-sm font-semibold">{appConfig.shortName}</span>
        <span className={cn("block text-[11px]", inverted ? "text-sidebar-foreground/70" : "text-muted-foreground")}>
          {appConfig.organization}
        </span>
      </span>
    </Link>
  );
}
