export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_settings: {
        Row: {
          active_provider: string
          chat_model: string
          embedding_model: string
          enable_hybrid_search: boolean
          enable_query_rewrite: boolean
          id: boolean
          max_tokens: number
          min_score: number
          refuse_without_sources: boolean
          system_prompt: string | null
          temperature: number
          top_k: number
          updated_at: string
        }
        Insert: {
          active_provider?: string
          chat_model?: string
          embedding_model?: string
          enable_hybrid_search?: boolean
          enable_query_rewrite?: boolean
          id?: boolean
          max_tokens?: number
          min_score?: number
          refuse_without_sources?: boolean
          system_prompt?: string | null
          temperature?: number
          top_k?: number
          updated_at?: string
        }
        Update: {
          active_provider?: string
          chat_model?: string
          embedding_model?: string
          enable_hybrid_search?: boolean
          enable_query_rewrite?: boolean
          id?: boolean
          max_tokens?: number
          min_score?: number
          refuse_without_sources?: boolean
          system_prompt?: string | null
          temperature?: number
          top_k?: number
          updated_at?: string
        }
        Relationships: []
      }
      ai_usage_events: {
        Row: {
          completion_tokens: number
          conversation_id: string | null
          created_at: string
          duration_ms: number
          error_message: string | null
          id: string
          kind: string
          model: string
          prompt_tokens: number
          provider_id: string
          success: boolean
          user_id: string | null
        }
        Insert: {
          completion_tokens?: number
          conversation_id?: string | null
          created_at?: string
          duration_ms?: number
          error_message?: string | null
          id?: string
          kind?: string
          model: string
          prompt_tokens?: number
          provider_id: string
          success?: boolean
          user_id?: string | null
        }
        Update: {
          completion_tokens?: number
          conversation_id?: string | null
          created_at?: string
          duration_ms?: number
          error_message?: string | null
          id?: string
          kind?: string
          model?: string
          prompt_tokens?: number
          provider_id?: string
          success?: boolean
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_usage_events_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_messages: {
        Row: {
          citations: Json
          completion_tokens: number | null
          confidence: number | null
          content: string
          conversation_id: string
          created_at: string
          id: string
          language: string | null
          latency_ms: number | null
          model: string | null
          prompt_tokens: number | null
          provider_id: string | null
          retrieval: Json
          role: string
        }
        Insert: {
          citations?: Json
          completion_tokens?: number | null
          confidence?: number | null
          content?: string
          conversation_id: string
          created_at?: string
          id?: string
          language?: string | null
          latency_ms?: number | null
          model?: string | null
          prompt_tokens?: number | null
          provider_id?: string | null
          retrieval?: Json
          role: string
        }
        Update: {
          citations?: Json
          completion_tokens?: number | null
          confidence?: number | null
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          language?: string | null
          latency_ms?: number | null
          model?: string | null
          prompt_tokens?: number | null
          provider_id?: string | null
          retrieval?: Json
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          deleted_at: string | null
          id: string
          is_archived: boolean
          is_pinned: boolean
          language: string
          memory_summary: string | null
          message_count: number
          model: string | null
          provider_id: string
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          deleted_at?: string | null
          id?: string
          is_archived?: boolean
          is_pinned?: boolean
          language?: string
          memory_summary?: string | null
          message_count?: number
          model?: string | null
          provider_id?: string
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          deleted_at?: string | null
          id?: string
          is_archived?: boolean
          is_pinned?: boolean
          language?: string
          memory_summary?: string | null
          message_count?: number
          model?: string | null
          provider_id?: string
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      crawl_jobs: {
        Row: {
          created_at: string
          created_by: string | null
          duration_ms: number | null
          error: string | null
          files_found: number
          finished_at: string | null
          id: string
          mode: string
          pages_crawled: number
          pages_discovered: number
          pages_failed: number
          pages_skipped: number
          pages_updated: number
          started_at: string | null
          status: string
          updated_at: string
          website_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          duration_ms?: number | null
          error?: string | null
          files_found?: number
          finished_at?: string | null
          id?: string
          mode?: string
          pages_crawled?: number
          pages_discovered?: number
          pages_failed?: number
          pages_skipped?: number
          pages_updated?: number
          started_at?: string | null
          status?: string
          updated_at?: string
          website_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          duration_ms?: number | null
          error?: string | null
          files_found?: number
          finished_at?: string | null
          id?: string
          mode?: string
          pages_crawled?: number
          pages_discovered?: number
          pages_failed?: number
          pages_skipped?: number
          pages_updated?: number
          started_at?: string | null
          status?: string
          updated_at?: string
          website_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crawl_jobs_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: false
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      crawl_logs: {
        Row: {
          context: Json
          created_at: string
          duration_ms: number | null
          id: string
          job_id: string | null
          level: string
          message: string
          page_id: string | null
          step: string
          url: string | null
          website_id: string | null
        }
        Insert: {
          context?: Json
          created_at?: string
          duration_ms?: number | null
          id?: string
          job_id?: string | null
          level?: string
          message: string
          page_id?: string | null
          step: string
          url?: string | null
          website_id?: string | null
        }
        Update: {
          context?: Json
          created_at?: string
          duration_ms?: number | null
          id?: string
          job_id?: string | null
          level?: string
          message?: string
          page_id?: string | null
          step?: string
          url?: string | null
          website_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "crawl_logs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "crawl_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crawl_logs_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: false
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      crawl_queue: {
        Row: {
          attempts: number
          created_at: string
          depth: number
          error: string | null
          id: string
          job_id: string | null
          priority: number
          processed_at: string | null
          source: string
          status: string
          updated_at: string
          url: string
          website_id: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          depth?: number
          error?: string | null
          id?: string
          job_id?: string | null
          priority?: number
          processed_at?: string | null
          source?: string
          status?: string
          updated_at?: string
          url: string
          website_id: string
        }
        Update: {
          attempts?: number
          created_at?: string
          depth?: number
          error?: string | null
          id?: string
          job_id?: string | null
          priority?: number
          processed_at?: string | null
          source?: string
          status?: string
          updated_at?: string
          url?: string
          website_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crawl_queue_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "crawl_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crawl_queue_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: false
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      crawl_settings: {
        Row: {
          allow_external: boolean
          allow_images: boolean
          allow_pdf: boolean
          allow_videos: boolean
          allowed_domains: string[]
          created_at: string
          delay_ms: number
          follow_redirects: boolean
          id: string
          ignored_extensions: string[]
          ignored_patterns: string[]
          ignored_urls: string[]
          max_concurrency: number
          max_depth: number
          max_pages: number
          respect_robots: boolean
          respect_sitemap: boolean
          retry_count: number
          timeout_ms: number
          updated_at: string
          website_id: string
        }
        Insert: {
          allow_external?: boolean
          allow_images?: boolean
          allow_pdf?: boolean
          allow_videos?: boolean
          allowed_domains?: string[]
          created_at?: string
          delay_ms?: number
          follow_redirects?: boolean
          id?: string
          ignored_extensions?: string[]
          ignored_patterns?: string[]
          ignored_urls?: string[]
          max_concurrency?: number
          max_depth?: number
          max_pages?: number
          respect_robots?: boolean
          respect_sitemap?: boolean
          retry_count?: number
          timeout_ms?: number
          updated_at?: string
          website_id: string
        }
        Update: {
          allow_external?: boolean
          allow_images?: boolean
          allow_pdf?: boolean
          allow_videos?: boolean
          allowed_domains?: string[]
          created_at?: string
          delay_ms?: number
          follow_redirects?: boolean
          id?: string
          ignored_extensions?: string[]
          ignored_patterns?: string[]
          ignored_urls?: string[]
          max_concurrency?: number
          max_depth?: number
          max_pages?: number
          respect_robots?: boolean
          respect_sitemap?: boolean
          retry_count?: number
          timeout_ms?: number
          updated_at?: string
          website_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crawl_settings_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: true
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      document_relationships: {
        Row: {
          created_at: string
          document_id: string
          id: string
          related_document_id: string
          relation_type: string
          score: number
        }
        Insert: {
          created_at?: string
          document_id: string
          id?: string
          related_document_id: string
          relation_type?: string
          score?: number
        }
        Update: {
          created_at?: string
          document_id?: string
          id?: string
          related_document_id?: string
          relation_type?: string
          score?: number
        }
        Relationships: [
          {
            foreignKeyName: "document_relationships_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_relationships_related_document_id_fkey"
            columns: ["related_document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_activity_log: {
        Row: {
          action: string
          actor_email: string | null
          actor_id: string | null
          context: Json
          created_at: string
          detail: string | null
          document_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_email?: string | null
          actor_id?: string | null
          context?: Json
          created_at?: string
          detail?: string | null
          document_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_email?: string | null
          actor_id?: string | null
          context?: Json
          created_at?: string
          detail?: string | null
          document_id?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_activity_log_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_categories: {
        Row: {
          color: string
          created_at: string
          created_by: string | null
          deleted_at: string | null
          description: string | null
          document_count: number
          id: string
          is_archived: boolean
          name: string
          parent_id: string | null
          slug: string
          updated_at: string
        }
        Insert: {
          color?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          description?: string | null
          document_count?: number
          id?: string
          is_archived?: boolean
          name: string
          parent_id?: string | null
          slug: string
          updated_at?: string
        }
        Update: {
          color?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          description?: string | null
          document_count?: number
          id?: string
          is_archived?: boolean
          name?: string
          parent_id?: string | null
          slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "knowledge_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_chunks: {
        Row: {
          category_id: string | null
          chunk_index: number
          content: string
          content_hash: string | null
          created_at: string
          document_id: string
          embedding: string | null
          embedding_model: string | null
          id: string
          keywords: string[]
          language: string | null
          metadata: Json
          page_number: number | null
          section: string | null
          token_count: number
        }
        Insert: {
          category_id?: string | null
          chunk_index: number
          content: string
          content_hash?: string | null
          created_at?: string
          document_id: string
          embedding?: string | null
          embedding_model?: string | null
          id?: string
          keywords?: string[]
          language?: string | null
          metadata?: Json
          page_number?: number | null
          section?: string | null
          token_count?: number
        }
        Update: {
          category_id?: string | null
          chunk_index?: number
          content?: string
          content_hash?: string | null
          created_at?: string
          document_id?: string
          embedding?: string | null
          embedding_model?: string | null
          id?: string
          keywords?: string[]
          language?: string | null
          metadata?: Json
          page_number?: number | null
          section?: string | null
          token_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_chunks_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "knowledge_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_chunks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_document_tags: {
        Row: {
          created_at: string
          document_id: string
          tag_id: string
        }
        Insert: {
          created_at?: string
          document_id: string
          tag_id: string
        }
        Update: {
          created_at?: string
          document_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_document_tags_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_document_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "knowledge_tags"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_documents: {
        Row: {
          author: string | null
          category_id: string | null
          checksum: string | null
          chunk_count: number
          clean_text: string | null
          created_at: string
          deleted_at: string | null
          department: string | null
          description: string | null
          embedding_status: string
          file_extension: string
          file_name: string
          file_size: number
          file_type: string
          id: string
          keywords: string[]
          language: string
          page_count: number | null
          processing_error: string | null
          processing_status: string
          raw_text: string | null
          source: string
          source_url: string | null
          status: string
          storage_path: string | null
          title: string
          training_status: string
          updated_at: string
          uploaded_by: string | null
          usage_count: number
          version: number
        }
        Insert: {
          author?: string | null
          category_id?: string | null
          checksum?: string | null
          chunk_count?: number
          clean_text?: string | null
          created_at?: string
          deleted_at?: string | null
          department?: string | null
          description?: string | null
          embedding_status?: string
          file_extension: string
          file_name: string
          file_size?: number
          file_type: string
          id?: string
          keywords?: string[]
          language?: string
          page_count?: number | null
          processing_error?: string | null
          processing_status?: string
          raw_text?: string | null
          source?: string
          source_url?: string | null
          status?: string
          storage_path?: string | null
          title: string
          training_status?: string
          updated_at?: string
          uploaded_by?: string | null
          usage_count?: number
          version?: number
        }
        Update: {
          author?: string | null
          category_id?: string | null
          checksum?: string | null
          chunk_count?: number
          clean_text?: string | null
          created_at?: string
          deleted_at?: string | null
          department?: string | null
          description?: string | null
          embedding_status?: string
          file_extension?: string
          file_name?: string
          file_size?: number
          file_type?: string
          id?: string
          keywords?: string[]
          language?: string
          page_count?: number | null
          processing_error?: string | null
          processing_status?: string
          raw_text?: string | null
          source?: string
          source_url?: string | null
          status?: string
          storage_path?: string | null
          title?: string
          training_status?: string
          updated_at?: string
          uploaded_by?: string | null
          usage_count?: number
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "knowledge_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_metadata: {
        Row: {
          created_at: string
          document_id: string
          id: string
          key: string
          updated_at: string
          value: string | null
        }
        Insert: {
          created_at?: string
          document_id: string
          id?: string
          key: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          created_at?: string
          document_id?: string
          id?: string
          key?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_metadata_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_processing_jobs: {
        Row: {
          attempts: number
          created_at: string
          created_by: string | null
          document_id: string
          duration_ms: number | null
          error: string | null
          finished_at: string | null
          id: string
          progress: number
          stage: string
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          created_by?: string | null
          document_id: string
          duration_ms?: number | null
          error?: string | null
          finished_at?: string | null
          id?: string
          progress?: number
          stage?: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          attempts?: number
          created_at?: string
          created_by?: string | null
          document_id?: string
          duration_ms?: number | null
          error?: string | null
          finished_at?: string | null
          id?: string
          progress?: number
          stage?: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_processing_jobs_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_processing_logs: {
        Row: {
          context: Json
          created_at: string
          document_id: string | null
          duration_ms: number | null
          id: string
          job_id: string | null
          level: string
          message: string
          step: string
        }
        Insert: {
          context?: Json
          created_at?: string
          document_id?: string | null
          duration_ms?: number | null
          id?: string
          job_id?: string | null
          level?: string
          message: string
          step: string
        }
        Update: {
          context?: Json
          created_at?: string
          document_id?: string | null
          duration_ms?: number | null
          id?: string
          job_id?: string | null
          level?: string
          message?: string
          step?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_processing_logs_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "knowledge_processing_logs_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "knowledge_processing_jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_tags: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
          slug: string
          updated_at: string
          usage_count: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          slug: string
          updated_at?: string
          usage_count?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          slug?: string
          updated_at?: string
          usage_count?: number
        }
        Relationships: []
      }
      knowledge_versions: {
        Row: {
          checksum: string | null
          created_at: string
          created_by: string | null
          document_id: string
          file_name: string
          file_size: number
          file_type: string | null
          id: string
          note: string | null
          storage_path: string
          version: number
        }
        Insert: {
          checksum?: string | null
          created_at?: string
          created_by?: string | null
          document_id: string
          file_name: string
          file_size?: number
          file_type?: string | null
          id?: string
          note?: string | null
          storage_path: string
          version: number
        }
        Update: {
          checksum?: string | null
          created_at?: string
          created_by?: string | null
          document_id?: string
          file_name?: string
          file_size?: number
          file_type?: string | null
          id?: string
          note?: string | null
          storage_path?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "knowledge_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          department: string | null
          email: string | null
          full_name: string | null
          id: string
          preferred_language: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          department?: string | null
          email?: string | null
          full_name?: string | null
          id: string
          preferred_language?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          department?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          preferred_language?: string
          updated_at?: string
        }
        Relationships: []
      }
      unanswered_questions: {
        Row: {
          answer: string | null
          answered_at: string | null
          answered_by: string | null
          ask_count: number
          confidence: number | null
          conversation_id: string | null
          created_at: string
          id: string
          language: string
          question: string
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          answer?: string | null
          answered_at?: string | null
          answered_by?: string | null
          ask_count?: number
          confidence?: number | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          language?: string
          question: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          answer?: string | null
          answered_at?: string | null
          answered_by?: string | null
          ask_count?: number
          confidence?: number | null
          conversation_id?: string | null
          created_at?: string
          id?: string
          language?: string
          question?: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          granted_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          granted_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          granted_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      website_metadata: {
        Row: {
          created_at: string
          id: string
          key: string
          updated_at: string
          value: string | null
          website_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          key: string
          updated_at?: string
          value?: string | null
          website_id: string
        }
        Update: {
          created_at?: string
          id?: string
          key?: string
          updated_at?: string
          value?: string | null
          website_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "website_metadata_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: false
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      website_pages: {
        Row: {
          canonical_url: string | null
          category: string | null
          clean_content: string | null
          content_hash: string | null
          created_at: string
          deleted_at: string | null
          department: string | null
          depth: number
          description: string | null
          document_id: string | null
          duplicate_of: string | null
          error: string | null
          extracted_content: string | null
          files: Json
          headings: Json
          http_status: number | null
          id: string
          is_duplicate: boolean
          language: string | null
          last_crawled_at: string | null
          last_modified_at: string | null
          links: Json
          metadata: Json
          page_type: string
          raw_html: string | null
          status: string
          title: string | null
          updated_at: string
          url: string
          version: number
          website_id: string
          word_count: number
        }
        Insert: {
          canonical_url?: string | null
          category?: string | null
          clean_content?: string | null
          content_hash?: string | null
          created_at?: string
          deleted_at?: string | null
          department?: string | null
          depth?: number
          description?: string | null
          document_id?: string | null
          duplicate_of?: string | null
          error?: string | null
          extracted_content?: string | null
          files?: Json
          headings?: Json
          http_status?: number | null
          id?: string
          is_duplicate?: boolean
          language?: string | null
          last_crawled_at?: string | null
          last_modified_at?: string | null
          links?: Json
          metadata?: Json
          page_type?: string
          raw_html?: string | null
          status?: string
          title?: string | null
          updated_at?: string
          url: string
          version?: number
          website_id: string
          word_count?: number
        }
        Update: {
          canonical_url?: string | null
          category?: string | null
          clean_content?: string | null
          content_hash?: string | null
          created_at?: string
          deleted_at?: string | null
          department?: string | null
          depth?: number
          description?: string | null
          document_id?: string | null
          duplicate_of?: string | null
          error?: string | null
          extracted_content?: string | null
          files?: Json
          headings?: Json
          http_status?: number | null
          id?: string
          is_duplicate?: boolean
          language?: string | null
          last_crawled_at?: string | null
          last_modified_at?: string | null
          links?: Json
          metadata?: Json
          page_type?: string
          raw_html?: string | null
          status?: string
          title?: string | null
          updated_at?: string
          url?: string
          version?: number
          website_id?: string
          word_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "website_pages_website_id_fkey"
            columns: ["website_id"]
            isOneToOne: false
            referencedRelation: "websites"
            referencedColumns: ["id"]
          },
        ]
      }
      website_versions: {
        Row: {
          clean_content: string | null
          content_hash: string | null
          created_at: string
          diff_summary: Json
          id: string
          metadata: Json
          page_id: string
          title: string | null
          version: number
        }
        Insert: {
          clean_content?: string | null
          content_hash?: string | null
          created_at?: string
          diff_summary?: Json
          id?: string
          metadata?: Json
          page_id: string
          title?: string | null
          version: number
        }
        Update: {
          clean_content?: string | null
          content_hash?: string | null
          created_at?: string
          diff_summary?: Json
          id?: string
          metadata?: Json
          page_id?: string
          title?: string | null
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "website_versions_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "website_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      websites: {
        Row: {
          base_url: string
          created_at: string
          cron_expression: string | null
          deleted_at: string | null
          description: string | null
          frequency: string
          id: string
          language: string
          last_crawl_at: string | null
          logo_url: string | null
          name: string
          next_crawl_at: string | null
          owner_id: string | null
          status: string
          total_pages: number
          updated_at: string
        }
        Insert: {
          base_url: string
          created_at?: string
          cron_expression?: string | null
          deleted_at?: string | null
          description?: string | null
          frequency?: string
          id?: string
          language?: string
          last_crawl_at?: string | null
          logo_url?: string | null
          name: string
          next_crawl_at?: string | null
          owner_id?: string | null
          status?: string
          total_pages?: number
          updated_at?: string
        }
        Update: {
          base_url?: string
          created_at?: string
          cron_expression?: string | null
          deleted_at?: string | null
          description?: string | null
          frequency?: string
          id?: string
          language?: string
          last_crawl_at?: string | null
          logo_url?: string | null
          name?: string
          next_crawl_at?: string | null
          owner_id?: string | null
          status?: string
          total_pages?: number
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_super_admin: { Args: never; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      match_knowledge_chunks: {
        Args: {
          filter_category?: string
          filter_language?: string
          match_count?: number
          min_score?: number
          query_embedding: string
        }
        Returns: {
          chunk_index: number
          content: string
          document_id: string
          document_title: string
          id: string
          language: string
          page_number: number
          score: number
          section: string
        }[]
      }
      search_knowledge_chunks_text: {
        Args: {
          filter_language?: string
          match_count?: number
          query_text: string
        }
        Returns: {
          chunk_index: number
          content: string
          document_id: string
          document_title: string
          id: string
          language: string
          page_number: number
          score: number
          section: string
        }[]
      }
    }
    Enums: {
      app_role: "super_admin" | "admin" | "moderator" | "staff" | "student"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["super_admin", "admin", "moderator", "staff", "student"],
    },
  },
} as const
